<?php if(!defined('__TYPECHO_ADMIN__')) exit; ?>
<!-- 底部版权等信息 -->
</div>
<footer class="footer">
	<div class="d-sm-flex justify-content-center justify-content-sm-between">
		<span class="text-muted text-center text-sm-left d-block d-sm-inline-block">
			 &bull;	<a href="https://lcy20.netlify.app/">归档-时光卷轴APP</a> &bull;
		<span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"><span class="年份检测" id="yearSpan"></span>  © 不见桃花不见秋</span>
			
	</div>
</footer>
<script>
// 获取当前年份并插入标签
document.getElementById("yearSpan").innerText = new Date().getFullYear();
</script>
