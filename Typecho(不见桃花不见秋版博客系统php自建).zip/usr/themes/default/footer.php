<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

        </div><!-- end .row -->
    </div>
</div><!-- end #body -->

<footer id="footer" role="contentinfo">
    &copy; <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>.
    <?php _e('由 <a href="https://lcy20.netlify.app/">归档-时光卷轴</a> 强力支持'); ?>.
</footer><!-- end #footer -->

<?php $this->footer(); ?>
</body>
</html>
