<?php
function themeConfig($form)
{?>
<link href="<?php echo theurl;?>assets/houtai.css" rel="stylesheet" type="text/css">
<script type='text/javascript'>
    /* <![CDATA[ */
    var sitedata = {
        "url": "<?php echo rooturl;?>"
    };
    /* ]]> */
</script>
<script type="text/javascript" src="<?php echo theurl;?>assets/js.js"></script>
<div class="card" style="margin: 0 10px 10px;text-align: center;">
    <h2 style="font-size: 2em;margin: 0;
    font-weight: bold;
    -webkit-background-clip: text;
    color: transparent;
    --tw-gradient-to: #ef4444;
    --tw-gradient-stops: #3b82f6, #ec4899, var(--tw-gradient-to, rgb(236 72 153 / 0));
    background-image: linear-gradient(to top right, var(--tw-gradient-stops));"><?php echo thename; ?></h2>
    <span style="font-size:14px">Design By 泽泽社长 Version:<?php echo get_theme_version();?></span>
</div>
<?php
//侧边导航
if(strpos($_SERVER['SCRIPT_NAME'], "options-theme.php")){
echo require_once("lib/backup.php");
}    
    $form->addItem(new EchoHtml('<div class="isok"><div class="col-mb-4 col-tb-2"><div class="tab">'));
        $form->addItem(new EchoHtml('<div data-item="index" class="tabLinks active">基础设置</div>'));
        $form->addItem(new EchoHtml('<div data-item="gongneng" class="tabLinks">功能设置</div>'));

        $form->addItem(new EchoHtml('<div data-item="ads" class="tabLinks">广告设置</div>'));
        
        $form->addItem(new EchoHtml('</div></div>'));
        $form->addItem(new EchoHtml('<div class="col-mb-8 col-tb-10"><div class="card">'));
    
    
        $form->addItem(new EchoHtml('<div id="index" class="hiddenx" style="display:block">'));
        

        $logo = new Typecho_Widget_Helper_Form_Element_Text('logo', NULL,NULL, _t('【浅色模式】Logo或头像设置'), _t('填写图片链接地址,推荐分辨率为：228 × 36 像素'));
        $form->addInput($logo); 

        $darklogo = new Typecho_Widget_Helper_Form_Element_Text('darklogo', NULL,NULL, _t('【深色模式】Logo或头像设置'), _t('填写图片链接地址,设置此项时需要设置下上方【浅色模式】logo，否则此项部分组件下会无效'));
        $form->addInput($darklogo);

        $ico = new Typecho_Widget_Helper_Form_Element_Text('ico', NULL,NULL, _t('网站ico图标设置'), _t('填写图片链接地址，不填则默认调用网站根目录下的favicon.ico作为图标'));
        $form->addInput($ico); 

   
        $headerbg = new Typecho_Widget_Helper_Form_Element_Text('headerbg', NULL,NULL, _t('头部背景图设置'), _t('头部背景图，不填则调用内置默认图片'));
        $form->addInput($headerbg); 

        $tx = new Typecho_Widget_Helper_Form_Element_Text('tx', NULL,NULL, _t('站长头像'), _t('用于侧栏显示，填写图片链接地址'));
        $form->addInput($tx);
    
        $subtitle = new Typecho_Widget_Helper_Form_Element_Text('subtitle', NULL,NULL, _t('副标题/描述'), _t('在首页时显示在浏览器标题右边，也会用于侧栏显示'));
        $form->addInput($subtitle); 


        $dashang = new Typecho_Widget_Helper_Form_Element_Text('dashang', NULL,NULL, _t('微信收款码'), _t('微信收款码图片链接地址'));
        $form->addInput($dashang);
        $dashangzfb = new Typecho_Widget_Helper_Form_Element_Text('dashangzfb', NULL,NULL, _t('支付宝收款码'), _t('支付宝收款码图片链接地址'));
        $form->addInput($dashangzfb);

        
        $refunction = new Typecho_Widget_Helper_Form_Element_Textarea('refunction', NULL,NULL, _t('Pjax重载函数'), _t(''));
        $form->addInput($refunction);
    
        $diycss = new Typecho_Widget_Helper_Form_Element_Textarea('diycss', NULL,NULL, _t('自定义css'), _t(''));
        $form->addInput($diycss);
    
        $diyjs = new Typecho_Widget_Helper_Form_Element_Textarea('diyjs', NULL,NULL, _t('自定义js'), _t(''));
        $form->addInput($diyjs);
    
        $header = new Typecho_Widget_Helper_Form_Element_Textarea('header', NULL,NULL, _t('头部信息'), _t('指html的<code>head</code>部分放置的内容，一般用来放置统计代码'));
        $form->addInput($header);
    
        $footer = new Typecho_Widget_Helper_Form_Element_Textarea('footer', NULL,NULL,'网站底部信息', _t('可用于填写备案号等内容'));
        $form->addInput($footer);
    
        $form->addItem(new EchoHtml('<button type="submit" class="btn primary">保存设置</button></div>'));
        
        $form->addItem(new EchoHtml('<div id="gongneng" class="hiddenx">'));

        $gravatars = new Typecho_Widget_Helper_Form_Element_Select('gravatars', array(
            'https://cravatar.cn/avatar/' =>_t('Cravatar[建议]'),
            'https://cdn.helingqi.com/avatar/' => _t('禾令奇[建议]'),
            'https://www.gravatar.com/avatar/' => _t('gravatar的www源'),
            'https://cn.gravatar.com/avatar/' => _t('gravatar的cn源'),
            'https://secure.gravatar.com/avatar/' => _t('gravatar的secure源'),
            'https://sdn.geekzu.org/avatar/' => _t('极客族'),
            'https://cdn.v2ex.com/gravatar/' => _t('v2ex源'),
            'https://dn-qiniu-avatar.qbox.me/avatar/' => _t('七牛源'),
            'https://gravatar.loli.net/avatar/' => _t('loli.net源[建议]'),
            ), 'https://cravatar.cn/avatar/',
            _t('gravatar头像源'), _t('默认使用https://cravatar.cn/avatar/')); 
            $form->addInput($gravatars->multiMode());


        // 文章页的侧边栏组件顺序
        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text('SidebarComponent', null, null, _t('网站侧边栏组件'), _t('这里可以单独设置侧边栏组件，组件会根据这里的组件名称排序。组件名称之间用英文逗号分隔，逗号和名称之间不需要空格，结尾不需要逗号。例如 <b style="color: #C7254E;">统计,分类列表,最新评论,标签云</b>，可以自行根据需要填写,不填则默认<b style="color: #C7254E;">统计,分类列表,标签云</b>')));

        $lunbo = new Typecho_Widget_Helper_Form_Element_Textarea('lunbo', NULL,NULL, _t('轮播图设置'), _t('格式为：标题$链接$图片地址，一行一个，如果想在新窗口打开则追加个：$1，如果要关闭轮播在这个输入框里输入：off即可，轮播图图片素材上不建议有文字如果有文字建议文字居中，避免显示时文字被截断'));
        $form->addInput($lunbo);

        if(defined('cms')){
        $cms = new \Typecho\Widget\Helper\Form\Element\Textarea('cms', null,null, _t('CMS首页布局设置'), _t('格式为：分类mid$标题，然后逗号输入下一个，如：1$标题1,2$标题2,3$标题3，不设置首页则显示最新文章列表'));
        $form->addInput($cms);
        }

        $tools = new Typecho_Widget_Helper_Form_Element_Checkbox('tools', 
        array(
        'ds' => _t('隐藏打赏点赞分享组件'),
        'tj'=> _t('隐藏猜你喜欢组件'),
        'cc'=> _t('显示文章版权声明'),
        'loginpl' => _t('开启评论强制登录'),
        'spam' => _t('开启评论验证码'),
        ),
        [], _t('拓展设置'));
        $form->addInput($tools->multiMode());
        

        $form->addItem(new EchoHtml('<button type="submit" class="btn primary">保存设置</button></div>'));

        $form->addItem(new EchoHtml('<div id="ads" class="hiddenx">'));
        //广告位1
        $ad1 = new Typecho_Widget_Helper_Form_Element_Textarea('ad1', NULL,NULL,'全站底部广告', _t('使用html语法自定义广告，例如谷歌登广告代码'));
        $form->addInput($ad1);

        //广告位4
        $ad4 = new Typecho_Widget_Helper_Form_Element_Textarea('ad4', NULL,NULL,'文章底部广告1', _t('使用html语法自定义广告，例如谷歌登广告代码'));
        $form->addInput($ad4);

        //广告位5
        $ad5 = new Typecho_Widget_Helper_Form_Element_Textarea('ad5', NULL,NULL,'文章底部广告2', _t('使用html语法自定义广告，例如谷歌登广告代码'));
        $form->addInput($ad5);
        
        $form->addItem(new EchoHtml('<button type="submit" class="btn primary">保存设置</button></div>'));
    }

    function get_theme_version()
{
 $info = Typecho_Plugin::parseInfo(__DIR__ . '/index.php');
 return $info['version'];
}



function getTemplate($obj,$template = 'post',$size='1x1')
    {
        if($template=='grid'){$size="16x9";}
        elseif($template=='photo'){$size="3x2";}
        elseif($template=='card'){$size="4x3";}
        elseif($template=='film'){$size="10x14";}
        
        $target='';

        
        $filePath = dirname(__FILE__) . '/template/list/' . $template.'.html';
        $content = file_get_contents($filePath);
        $catename='none';
        if(!empty($obj->categories)){
            $catename=$obj->categories[0]['name'];
        }

        $pattern = '/{{(.*?)}}/';
        $replacement = function ($matches) {
            \Widget\archive::alloc()->to($obj);
            // 这里$matches[1]包含了{{}}中间的内容
            $fields=$obj->fields->{$matches[1]};
            if($fields){return $fields;}else{return 'false';}
        };
        $content = preg_replace_callback($pattern, $replacement, $content);


        $search = array(
            '{sequence}',//序号
            '{cid}',//文章cid
            '{title}',//文章标题
            '{date}',//文章日期
            '{permalink}',//链接
            '{icon}',//封面
            '{size}',//封面比例
            '{description}',//描述
            '{categorty}',//分类
            '{author}',//文章作者
            '{commentsNum}',//评论数
            '{views}',//文章阅读数
            '{likes}',//点赞数
        );
        $replace = array(
            $obj->sequence,
            $obj->cid,
            $obj->title,
            date('Y年m月d日',$obj->created),
            $obj->permalink.$target,
            icon($obj,1),
            $size,
            excerpt($obj,150, '...',1),
            $catename,
            $obj->author->screenName,
            $obj->commentsNum,
            get_post_view($obj,1),
            likeup($obj->cid,"return"),
        );
        
        echo str_replace($search, $replace, $content);
    }

    function getTitleTemplate($title = '小标题',$more='')
    {   
    $style=1;
    if($style==1){
        if(!empty($more)){
        $more='<a href="'.$more.'" class="text-xs text-sky-500 pb-1" title="更多链接">更多</a>';
        }
        echo '<div class="flex items-center justify-between font-semibold text-gray-800 dark:text-gray-200  pb-2 mb-1"><div class="flex items-center"><span class="bg-[var(--primary)] h-4 w-1 rounded-full mr-2"></span>'.$title.'</div>'.$more.'</div>';
    }
    }
?>