<?php if(!defined('__TYPECHO_ADMIN__')) exit; ?>
<div class="typecho-foot" role="contentinfo">
    <div class="copyright">
        <a href="" >不见桃花不见秋</a>
        <p><?php _e('由 <a href="https://lcy20.netlify.app">归档-时光卷轴</a> 强力驱动, 版本 1.7.4', $options->software, $options->version); ?></p>
    </div>
    <nav class="resource">
        <a href=""><?php _e('帮助文档'); ?></a> &bull;
        <a href=""><?php _e('支持论坛'); ?></a> &bull;
        <a href=""><?php _e('报告错误'); ?></a> &bull;
        <a href=""><?php _e('资源下载'); ?></a>
    </nav>
</div>
