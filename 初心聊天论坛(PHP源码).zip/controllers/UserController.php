<?php
class UserController {
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';
            
            // 表单验证
            if (empty($username) || empty($password) || empty($confirm_password)) {
                $error = '请填写所有字段';
                include __DIR__ . '/../views/auth/register.php';
                return;
            }
            
            if ($password != $confirm_password) {
                $error = '两次密码输入不一致';
                include __DIR__ . '/../views/auth/register.php';
                return;
            }
            
            if (strlen($username) < 3 || strlen($username) > 20) {
                $error = '用户名长度应在3-20个字符之间';
                include __DIR__ . '/../views/auth/register.php';
                return;
            }
            
            if (strlen($password) < 6) {
                $error = '密码长度至少6个字符';
                include __DIR__ . '/../views/auth/register.php';
                return;
            }
            
            // 处理头像上传
            $avatar = 'default.jpg';
            if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
                $target_dir = __DIR__ . '/../assets/uploads/';
                $target_file = $target_dir . basename($_FILES['avatar']['name']);
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                
                // 检查文件类型
                $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
                if (in_array($imageFileType, $allowed_types)) {
                    // 生成唯一文件名
                    $unique_name = uniqid() . '.' . $imageFileType;
                    $target_file = $target_dir . $unique_name;
                    
                    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target_file)) {
                        $avatar = $unique_name;
                    }
                }
            }
            
            // 密码加密
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // 插入数据库
            $conn = db();
            $stmt = $conn->prepare('INSERT INTO users (username, password, avatar) VALUES (?, ?, ?)');
            $stmt->bind_param('sss', $username, $hashed_password, $avatar);
            
            if ($stmt->execute()) {
                // 注册成功，跳转到登录页
                header('Location: index.php?action=login');
            } else {
                $error = '注册失败，请稍后重试';
                include __DIR__ . '/../views/auth/register.php';
            }
        } else {
            include __DIR__ . '/../views/auth/register.php';
        }
    }
    
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            
            // 表单验证
            if (empty($username) || empty($password)) {
                $error = '请填写用户名和密码';
                include __DIR__ . '/../views/auth/login.php';
                return;
            }
            
            // 查询用户
            $conn = db();
            $stmt = $conn->prepare('SELECT id, password, avatar FROM users WHERE username = ?');
            $stmt->bind_param('s', $username);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows == 1) {
                $user = $result->fetch_assoc();
                
                // 验证密码
                if (password_verify($password, $user['password'])) {
                    // 登录成功，设置会话
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $username;
                    $_SESSION['avatar'] = $user['avatar'];
                    
                    // 跳转到聊天页面
                    header('Location: index.php?action=chat');
                } else {
                    $error = '密码错误';
                    include __DIR__ . '/../views/auth/login.php';
                }
            } else {
                $error = '用户名不存在';
                include __DIR__ . '/../views/auth/login.php';
            }
        } else {
            include __DIR__ . '/../views/auth/login.php';
        }
    }
    
    public function logout() {
        // 销毁会话
        session_destroy();
        // 跳转到登录页
        header('Location: index.php?action=login');
    }
    
    public function changePassword() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?action=login');
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $current_password = $_POST['current_password'] ?? '';
            $new_password = $_POST['new_password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';
            
            // 表单验证
            if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
                $error = '请填写所有字段';
                include __DIR__ . '/../views/auth/change_password.php';
                return;
            }
            
            if ($new_password != $confirm_password) {
                $error = '两次密码输入不一致';
                include __DIR__ . '/../views/auth/change_password.php';
                return;
            }
            
            if (strlen($new_password) < 6) {
                $error = '新密码长度至少6个字符';
                include __DIR__ . '/../views/auth/change_password.php';
                return;
            }
            
            // 验证当前密码
            $conn = db();
            $stmt = $conn->prepare('SELECT password FROM users WHERE id = ?');
            $stmt->bind_param('i', $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows == 1) {
                $user = $result->fetch_assoc();
                
                if (password_verify($current_password, $user['password'])) {
                    // 密码正确，更新密码
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    
                    $stmt = $conn->prepare('UPDATE users SET password = ? WHERE id = ?');
                    $stmt->bind_param('si', $hashed_password, $_SESSION['user_id']);
                    
                    if ($stmt->execute()) {
                        $success = '密码修改成功';
                        include __DIR__ . '/../views/auth/change_password.php';
                    } else {
                        $error = '密码修改失败，请稍后重试';
                        include __DIR__ . '/../views/auth/change_password.php';
                    }
                } else {
                    $error = '当前密码错误';
                    include __DIR__ . '/../views/auth/change_password.php';
                }
            } else {
                $error = '用户不存在';
                include __DIR__ . '/../views/auth/change_password.php';
            }
        } else {
            include __DIR__ . '/../views/auth/change_password.php';
        }
    }
}
?>