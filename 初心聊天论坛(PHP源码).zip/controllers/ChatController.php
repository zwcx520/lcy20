<?php
class ChatController {
    public function index() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?action=login');
            return;
        }
        
        // 获取所有用户信息
        $conn = db();
        $users_result = $conn->query('SELECT id, username, avatar FROM users');
        $users = [];
        while ($row = $users_result->fetch_assoc()) {
            $users[] = $row;
        }
        
        // 获取最近的消息
        $messages_result = $conn->query('SELECT m.id, m.user_id, m.content, m.created_at, u.username, u.avatar FROM messages m JOIN users u ON m.user_id = u.id ORDER BY m.created_at DESC LIMIT 50');
        $messages = [];
        while ($row = $messages_result->fetch_assoc()) {
            $messages[] = $row;
        }
        $messages = array_reverse($messages); // 按时间正序排列
        
        include __DIR__ . '/../views/chat/index.php';
    }
    
    public function send() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['status' => 'error', 'message' => '未登录']);
            return;
        }
        
        $content = $_POST['content'] ?? '';
        
        if (empty($content)) {
            echo json_encode(['status' => 'error', 'message' => '消息内容不能为空']);
            return;
        }
        
        // 插入消息
        $conn = db();
        $stmt = $conn->prepare('INSERT INTO messages (user_id, content) VALUES (?, ?)');
        $stmt->bind_param('is', $_SESSION['user_id'], $content);
        
        if ($stmt->execute()) {
            // 获取新消息信息
            $message_id = $conn->insert_id;
            $result = $conn->query("SELECT m.id, m.user_id, m.content, m.created_at, u.username, u.avatar FROM messages m JOIN users u ON m.user_id = u.id WHERE m.id = $message_id");
            $message = $result->fetch_assoc();
            
            echo json_encode(['status' => 'success', 'message' => $message]);
        } else {
            echo json_encode(['status' => 'error', 'message' => '发送失败']);
        }
    }
    
    public function getMessages() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['status' => 'error', 'message' => '未登录']);
            return;
        }
        
        $last_id = $_GET['last_id'] ?? 0;
        
        // 获取新消息
        $conn = db();
        $stmt = $conn->prepare('SELECT m.id, m.user_id, m.content, m.created_at, u.username, u.avatar FROM messages m JOIN users u ON m.user_id = u.id WHERE m.id > ? ORDER BY m.created_at ASC');
        $stmt->bind_param('i', $last_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $messages = [];
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }
        
        echo json_encode(['status' => 'success', 'messages' => $messages]);
    }
    
    public function sendPrivateMessage() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['status' => 'error', 'message' => '未登录']);
            return;
        }
        
        $content = $_POST['content'] ?? '';
        $receiver_id = $_POST['receiver_id'] ?? 0;
        
        if (empty($content) || empty($receiver_id)) {
            echo json_encode(['status' => 'error', 'message' => '消息内容和接收者不能为空']);
            return;
        }
        
        // 插入私聊消息
        $conn = db();
        $stmt = $conn->prepare('INSERT INTO private_messages (sender_id, receiver_id, content) VALUES (?, ?, ?)');
        $stmt->bind_param('iis', $_SESSION['user_id'], $receiver_id, $content);
        
        if ($stmt->execute()) {
            // 获取新消息信息
            $message_id = $conn->insert_id;
            $result = $conn->query("SELECT pm.id, pm.sender_id, pm.receiver_id, pm.content, pm.created_at, u.username, u.avatar FROM private_messages pm JOIN users u ON pm.sender_id = u.id WHERE pm.id = $message_id");
            $message = $result->fetch_assoc();
            
            echo json_encode(['status' => 'success', 'message' => $message]);
        } else {
            echo json_encode(['status' => 'error', 'message' => '发送失败']);
        }
    }
    
    public function getPrivateMessages() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['status' => 'error', 'message' => '未登录']);
            return;
        }
        
        $receiver_id = $_GET['receiver_id'] ?? 0;
        $last_id = $_GET['last_id'] ?? 0;
        
        if (empty($receiver_id)) {
            echo json_encode(['status' => 'error', 'message' => '接收者不能为空']);
            return;
        }
        
        // 获取私聊消息
        $conn = db();
        $stmt = $conn->prepare('SELECT pm.id, pm.sender_id, pm.receiver_id, pm.content, pm.created_at, u.username, u.avatar FROM private_messages pm JOIN users u ON pm.sender_id = u.id WHERE ((pm.sender_id = ? AND pm.receiver_id = ?) OR (pm.sender_id = ? AND pm.receiver_id = ?)) AND pm.id > ? ORDER BY pm.created_at ASC');
        $stmt->bind_param('iiiii', $_SESSION['user_id'], $receiver_id, $receiver_id, $_SESSION['user_id'], $last_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $messages = [];
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }
        
        echo json_encode(['status' => 'success', 'messages' => $messages]);
    }
}
?>