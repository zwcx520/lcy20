<?php
class AdminController {
    public function index() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?action=login');
            return;
        }
        
        // 检查是否为管理员（这里简单判断用户ID为1的是管理员）
        if ($_SESSION['user_id'] != 1) {
            header('Location: index.php?action=chat');
            return;
        }
        
        // 获取所有用户信息
        $conn = db();
        $users_result = $conn->query('SELECT id, username, avatar, created_at FROM users');
        $users = [];
        while ($row = $users_result->fetch_assoc()) {
            $users[] = $row;
        }
        
        include __DIR__ . '/../views/admin/index.php';
    }
    
    public function edit() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?action=login');
            return;
        }
        
        // 检查是否为管理员
        if ($_SESSION['user_id'] != 1) {
            header('Location: index.php?action=chat');
            return;
        }
        
        $user_id = $_GET['id'] ?? 0;
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'] ?? '';
            
            // 表单验证
            if (empty($username)) {
                $error = '用户名不能为空';
                include __DIR__ . '/../views/admin/edit.php';
                return;
            }
            
            if (strlen($username) < 3 || strlen($username) > 20) {
                $error = '用户名长度应在3-20个字符之间';
                include __DIR__ . '/../views/admin/edit.php';
                return;
            }
            
            // 处理头像上传
            $avatar = $_POST['current_avatar'] ?? 'default.jpg';
            if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
                $target_dir = __DIR__ . '/../assets/uploads/';
                $target_file = $target_dir . basename($_FILES['avatar']['name']);
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                
                // 检查文件类型
                $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
                if (in_array($imageFileType, $allowed_types)) {
                    // 生成唯一文件名
                    $unique_name = uniqid() . '.' . $imageFileType;
                    $target_file = $target_dir . $unique_name;
                    
                    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target_file)) {
                        $avatar = $unique_name;
                    }
                }
            }
            
            // 更新用户信息
            $conn = db();
            $stmt = $conn->prepare('UPDATE users SET username = ?, avatar = ? WHERE id = ?');
            $stmt->bind_param('ssi', $username, $avatar, $user_id);
            
            if ($stmt->execute()) {
                // 更新成功，跳转到管理员页面
                header('Location: index.php?action=admin');
            } else {
                $error = '更新失败，请稍后重试';
                include __DIR__ . '/../views/admin/edit.php';
            }
        } else {
            // 获取用户信息
            $conn = db();
            $stmt = $conn->prepare('SELECT id, username, avatar FROM users WHERE id = ?');
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows == 1) {
                $user = $result->fetch_assoc();
                include __DIR__ . '/../views/admin/edit.php';
            } else {
                header('Location: index.php?action=admin');
            }
        }
    }
    
    public function delete() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?action=login');
            return;
        }
        
        // 检查是否为管理员
        if ($_SESSION['user_id'] != 1) {
            header('Location: index.php?action=chat');
            return;
        }
        
        $user_id = $_GET['id'] ?? 0;
        
        // 不能删除自己
        if ($user_id == $_SESSION['user_id']) {
            header('Location: index.php?action=admin');
            return;
        }
        
        // 获取用户头像信息
        $conn = db();
        $stmt = $conn->prepare('SELECT avatar FROM users WHERE id = ?');
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $avatar = 'default.jpg';
        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            $avatar = $user['avatar'];
        }
        
        // 删除用户
        $stmt = $conn->prepare('DELETE FROM users WHERE id = ?');
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        
        // 删除用户头像（如果不是默认头像）
        if ($avatar != 'default.jpg') {
            $avatar_path = __DIR__ . '/../assets/uploads/' . $avatar;
            if (file_exists($avatar_path)) {
                unlink($avatar_path);
            }
        }
        
        header('Location: index.php?action=admin');
    }
    
    public function addUser() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?action=login');
            return;
        }
        
        // 检查是否为管理员
        if ($_SESSION['user_id'] != 1) {
            header('Location: index.php?action=chat');
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';
            
            // 表单验证
            if (empty($username) || empty($password) || empty($confirm_password)) {
                $error = '请填写所有字段';
                include __DIR__ . '/../views/admin/add.php';
                return;
            }
            
            if ($password != $confirm_password) {
                $error = '两次密码输入不一致';
                include __DIR__ . '/../views/admin/add.php';
                return;
            }
            
            if (strlen($username) < 3 || strlen($username) > 20) {
                $error = '用户名长度应在3-20个字符之间';
                include __DIR__ . '/../views/admin/add.php';
                return;
            }
            
            if (strlen($password) < 6) {
                $error = '密码长度至少6个字符';
                include __DIR__ . '/../views/admin/add.php';
                return;
            }
            
            // 处理头像上传
            $avatar = 'default.jpg';
            if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
                $target_dir = __DIR__ . '/../assets/uploads/';
                // 确保目录存在
                if (!is_dir($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }
                $target_file = $target_dir . basename($_FILES['avatar']['name']);
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                
                // 检查文件类型
                $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
                if (in_array($imageFileType, $allowed_types)) {
                    // 生成唯一文件名
                    $unique_name = uniqid() . '.' . $imageFileType;
                    $target_file = $target_dir . $unique_name;
                    
                    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target_file)) {
                        $avatar = $unique_name;
                    }
                }
            }
            
            // 密码加密
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // 插入数据库
            $conn = db();
            $stmt = $conn->prepare('INSERT INTO users (username, password, avatar) VALUES (?, ?, ?)');
            $stmt->bind_param('sss', $username, $hashed_password, $avatar);
            
            if ($stmt->execute()) {
                // 添加成功，跳转到管理员页面
                header('Location: index.php?action=admin');
            } else {
                $error = '添加失败，请稍后重试';
                include __DIR__ . '/../views/admin/add.php';
            }
        } else {
            include __DIR__ . '/../views/admin/add.php';
        }
    }
}
?>