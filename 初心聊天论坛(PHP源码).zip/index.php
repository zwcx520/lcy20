<?php
session_start();

// 自动加载
function autoload($class) {
    $file = __DIR__ . '/controllers/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
    } else {
        $file = __DIR__ . '/models/' . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
        }
    }
}

spl_autoload_register('autoload');

// 配置文件
require_once __DIR__ . '/config/database.php';

// 路由处理
$action = $_GET['action'] ?? 'index';

switch ($action) {
    case 'register':
        $controller = new UserController();
        $controller->register();
        break;
    case 'login':
        $controller = new UserController();
        $controller->login();
        break;
    case 'logout':
        $controller = new UserController();
        $controller->logout();
        break;
    case 'changePassword':
        $controller = new UserController();
        $controller->changePassword();
        break;
    case 'chat':
        $controller = new ChatController();
        $controller->index();
        break;
    case 'send':
        $controller = new ChatController();
        $controller->send();
        break;
    case 'getMessages':
        $controller = new ChatController();
        $controller->getMessages();
        break;
    case 'sendPrivateMessage':
        $controller = new ChatController();
        $controller->sendPrivateMessage();
        break;
    case 'getPrivateMessages':
        $controller = new ChatController();
        $controller->getPrivateMessages();
        break;
    case 'admin':
        $controller = new AdminController();
        $controller->index();
        break;
    case 'adminEdit':
        $controller = new AdminController();
        $controller->edit();
        break;
    case 'adminDelete':
        $controller = new AdminController();
        $controller->delete();
        break;
    case 'adminAdd':
        $controller = new AdminController();
        $controller->addUser();
        break;
    default:
        if (isset($_SESSION['user_id'])) {
            header('Location: index.php?action=chat');
        } else {
            header('Location: index.php?action=login');
        }
        break;
}
?>