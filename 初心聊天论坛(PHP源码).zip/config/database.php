<?php
// 数据库配置
$host = 'localhost';
$dbname = '聊天';
$username = 'root';
$password = 'lcy';

// 连接到MySQL服务器
$conn = mysqli_connect($host, $username, $password);
if (!$conn) {
    die('数据库连接失败: ' . mysqli_connect_error());
}

// 检查数据库是否存在，不存在则创建
if (!mysqli_select_db($conn, $dbname)) {
    $sql = "CREATE DATABASE `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
    if (!mysqli_query($conn, $sql)) {
        die('创建数据库失败: ' . mysqli_error($conn));
    }
    mysqli_select_db($conn, $dbname);
}

// 创建用户表
$users_table = "CREATE TABLE IF NOT EXISTS `users` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `avatar` VARCHAR(255) DEFAULT 'default.jpg',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (!mysqli_query($conn, $users_table)) {
    die('创建用户表失败: ' . mysqli_error($conn));
}

// 创建消息表（群聊）
$messages_table = "CREATE TABLE IF NOT EXISTS `messages` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) NOT NULL,
    `content` TEXT NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`),
    CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (!mysqli_query($conn, $messages_table)) {
    die('创建消息表失败: ' . mysqli_error($conn));
}

// 创建私聊消息表
$private_messages_table = "CREATE TABLE IF NOT EXISTS `private_messages` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `sender_id` INT(11) NOT NULL,
    `receiver_id` INT(11) NOT NULL,
    `content` TEXT NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `sender_id` (`sender_id`),
    KEY `receiver_id` (`receiver_id`),
    CONSTRAINT `private_messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `private_messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (!mysqli_query($conn, $private_messages_table)) {
    die('创建私聊消息表失败: ' . mysqli_error($conn));
}

// 关闭连接
mysqli_close($conn);

// 重新连接到指定数据库
$conn = mysqli_connect($host, $username, $password, $dbname);
if (!$conn) {
    die('数据库连接失败: ' . mysqli_connect_error());
}

// 设置字符集
mysqli_set_charset($conn, 'utf8mb4');

// 数据库连接函数
function db() {
    global $conn;
    return $conn;
}
?>