<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>聊天 - 初心聊天论坛</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f5f5f5;
            font-family: 'Microsoft YaHei', sans-serif;
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }
        .chat-container {
            width: 100%;
            height: 100vh;
            min-height: 100vh;
            background: white;
            display: flex;
            overflow: hidden;
            position: relative;
        }
        
        /* 侧边栏样式 */
        .sidebar {
            width: 300px;
            border-right: 1px solid #e0e0e0;
            display: flex;
            flex-direction: column;
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            background: white;
            z-index: 1003;
            transform: translateX(0);
            transition: transform 0.3s ease;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-footer {
            border-top: 1px solid #e0e0e0;
            margin-top: auto;
            background: #f8f9fa;
        }
        
        /* 侧边栏收起状态 */
        .sidebar.collapsed {
            transform: translateX(-100%);
        }
        
        /* 侧边栏切换按钮 */
        .sidebar-toggle {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: transparent;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 1001;
            color: white;
        }
        
        /* 聊天头部样式调整 */
        .chat-header {
            position: relative;
        }
        
        /* 移动设备上聊天头部样式调整 */
        @media (max-width: 768px) {
            .chat-header {
                padding-left: 50px;
            }
        }
        
        @media (min-width: 769px) {
            .sidebar-toggle {
                display: none;
            }
            .sidebar {
                position: relative !important;
                transform: translateX(0) !important;
                box-shadow: none !important;
                width: 300px;
                flex-shrink: 0;
            }
            .chat-container {
                display: flex;
            }
            .chat-main {
                flex: 1;
                margin-left: 0 !important;
            }
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 250px;
            }
        }
        
        @media (max-width: 480px) {
            .sidebar {
                width: 200px;
            }
            .message-content {
                max-width: 80%;
            }
            .sidebar-header {
                flex-direction: column;
                align-items: flex-start;
                padding: 10px;
            }
            .user-info {
                margin-bottom: 10px;
            }
            .dropdown {
                align-self: flex-start;
            }
        }
        .sidebar-header {
            padding: 15px;
            background: #f8f9fa;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .user-info {
            display: flex;
            align-items: center;
        }
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 10px;
        }
        .user-name {
            font-weight: bold;
            color: #333;
        }
        .logout-btn {
            color: #ff6b6b;
            text-decoration: none;
            font-size: 14px;
        }
        .logout-btn:hover {
            text-decoration: underline;
        }
        .user-list {
            flex: 1;
            overflow-y: auto;
        }
        .user-item {
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .user-item:hover {
            background: #f8f9fa;
        }
        .user-item.active {
            background: #e3f2fd;
        }
        .chat-main {
            flex: 1;
            display: flex;
            flex-direction: column;
            margin-left: 0;
            transition: margin-left 0.3s ease;
            position: relative;
            z-index: 1002;
        }
        
        .chat-header {
            padding: 15px;
            background: #f8f9fa;
            border-bottom: 1px solid #e0e0e0;
            text-align: center;
            position: relative;
        }
        .chat-header h3 {
            margin: 0;
            color: #333;
            font-size: 18px;
        }
        .chat-body {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #f0f2f5;
        }
        .message {
            margin-bottom: 15px;
            display: flex;
            align-items: flex-start;
        }
        .message.own {
            flex-direction: row-reverse;
        }
        .message-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin: 0 10px;
        }
        .message-content {
            max-width: 70%;
            padding: 10px 15px;
            border-radius: 18px;
            position: relative;
        }
        .message.other .message-content {
            background: white;
            border-bottom-left-radius: 4px;
        }
        .message.own .message-content {
            background: #dcf8c6;
            border-bottom-right-radius: 4px;
        }
        .message-text {
            word-break: break-word;
            line-height: 1.4;
        }
        .message-time {
            font-size: 12px;
            color: #999;
            margin-top: 5px;
            text-align: right;
        }
        .message-sender {
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
        }
        .chat-footer {
            padding: 10px;
            background: #f8f9fa;
            border-top: 1px solid #e0e0e0;
            display: flex;
            align-items: center;
            box-sizing: border-box;
        }
        .message-input {
            flex: 1;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            padding: 10px 15px;
            resize: none;
            outline: none;
            font-size: 14px;
            max-width: calc(100% - 70px);
        }
        .message-input:focus {
            border-color: #07C160;
        }
        .send-btn {
            background: #07C160;
            border: none;
            border-radius: 4px;
            width: 60px;
            height: 40px;
            margin-left: 10px;
            color: white;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            flex-shrink: 0;
        }
        .send-btn:hover {
            background: #06B158;
            transform: translateY(-2px);
        }
        .send-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        
        /* 移动设备适配 */
        @media (max-width: 480px) {
            .chat-footer {
                padding: 8px;
            }
            .message-input {
                padding: 8px 12px;
                font-size: 13px;
            }
            .send-btn {
                width: 50px;
                height: 36px;
                margin-left: 8px;
                font-size: 13px;
            }
            .message-input {
                max-width: calc(100% - 60px);
            }
        }
        /* 浪漫萌系风格 */
        .chat-header {
            background: linear-gradient(135deg, #ff9a9e 0%, #fad0c4 100%);
            color: white;
        }
        .chat-header h3 {
            color: white;
        }
        .sidebar-header {
            background: linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%);
        }
        .user-name {
            color: #000;
        }
        .logout-btn {
            color: white;
        }
        .message.other .message-content {
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 18px;
            border-bottom-left-radius: 4px;
        }
        .message.own .message-content {
            background: #dcf8c6;
            border: none;
            border-radius: 18px;
            border-bottom-right-radius: 4px;
        }
        .send-btn {
            background: #07C160;
        }
        .send-btn:hover {
            background: #06B158;
        }
        
    </style>
</head>
<body>
    <div class="chat-container">
            <!-- 侧边栏 -->
            <div class="sidebar" id="sidebar">
                <div class="sidebar-header">
                    <div class="user-info">
                        <img src="../assets/uploads/<?php echo $_SESSION['avatar']; ?>" alt="头像" class="user-avatar">
                        <span class="user-name"><?php echo $_SESSION['username']; ?></span>
                    </div>
                    <div class="dropdown">
                        <button class="btn btn-transparent text-white dropdown-toggle" type="button" id="userMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                            菜单
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userMenuButton">
                            <?php if ($_SESSION['user_id'] == 1): ?>
                                <li><a class="dropdown-item" href="index.php?action=admin">管理</a></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="index.php?action=changePassword">修改密码</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="index.php?action=logout">退出</a></li>
                        </ul>
                    </div>
                </div>
                <div class="user-list">
                    <div class="user-item active" data-user-id="0" data-username="初心聊天室">
                        <div class="user-info">
                            <img src="../assets/images/default.jpg" alt="头像" class="user-avatar">
                            <span class="user-name">初心聊天室</span>
                        </div>
                    </div>
                    <?php foreach ($users as $user): ?>
                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                            <div class="user-item" data-user-id="<?php echo $user['id']; ?>" data-username="<?php echo $user['username']; ?>">
                                <div class="user-info">
                                    <img src="../assets/uploads/<?php echo $user['avatar']; ?>" alt="头像" class="user-avatar">
                                    <span class="user-name"><?php echo $user['username']; ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
                <div class="sidebar-footer">
                    <p class="text-center text-muted" style="margin: 0; padding: 10px;">注册用户: <?php 
                        $conn = db();
                        $result = $conn->query('SELECT COUNT(*) as count FROM users');
                        $row = $result->fetch_assoc();
                        echo $row['count'];
                    ?></p>
                </div>
            </div>
            
            <!-- 聊天区域 -->
            <div class="chat-main">
                <div class="chat-header">
                    <div class="sidebar-toggle" id="sidebarToggle">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
                        </svg>
                    </div>
                    <h3 id="chat-title">初心聊天室</h3>
                </div>
                <div class="chat-body" id="chat-body">
                    <?php foreach ($messages as $message): ?>
                        <div class="message <?php echo $message['user_id'] == $_SESSION['user_id'] ? 'own' : 'other'; ?>">
                            <img src="../assets/uploads/<?php echo $message['avatar']; ?>" alt="头像" class="message-avatar">
                            <div class="message-content">
                                <?php if ($message['user_id'] != $_SESSION['user_id']): ?>
                                    <div class="message-sender"><?php echo $message['username']; ?></div>
                                <?php endif; ?>
                                <div class="message-text"><?php echo htmlspecialchars($message['content']); ?></div>
                                <div class="message-time"><?php echo date('H:i', strtotime($message['created_at'])); ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="chat-footer">
                    <textarea class="message-input" id="message-input" placeholder="输入消息..." rows="1"></textarea>
                    <button class="send-btn" id="send-btn">发送</button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // 自动调整文本域高度
        const messageInput = document.getElementById('message-input');
        messageInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 100) + 'px';
        });
        
        // 发送消息
        const sendBtn = document.getElementById('send-btn');
        const chatBody = document.getElementById('chat-body');
        const chatTitle = document.getElementById('chat-title');
        
        // 当前聊天模式：0 群聊，其他值为私聊用户ID
        let currentChatMode = 0;
        let currentChatUserId = 0;
        let currentChatUsername = '初心聊天室';
        
        // 消息ID追踪
        let lastMessageId = <?php echo count($messages) > 0 ? $messages[count($messages)-1]['id'] : 0; ?>;
        let lastPrivateMessageId = 0;
        
        // 发送消息
        sendBtn.addEventListener('click', sendMessage);
        messageInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
        
        function sendMessage() {
            const content = messageInput.value.trim();
            if (content) {
                // 显示发送中的消息
                const tempId = Date.now();
                addMessage(tempId, content, true);
                
                if (currentChatMode === 0) {
                    // 群聊消息
                    fetch('index.php?action=send', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: 'content=' + encodeURIComponent(content)
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            // 移除临时消息
                            document.getElementById('temp-' + tempId).remove();
                            // 添加服务器返回的消息
                            addMessage(data.message.id, data.message.content, true, data.message.username, data.message.avatar, data.message.created_at);
                            // 更新lastMessageId，避免轮询时重复获取
                            lastMessageId = data.message.id;
                        } else {
                            alert(data.message);
                            document.getElementById('temp-' + tempId).remove();
                        }
                    });
                } else {
                    // 私聊消息
                    fetch('index.php?action=sendPrivateMessage', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: 'content=' + encodeURIComponent(content) + '&receiver_id=' + currentChatUserId
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            // 移除临时消息
                            document.getElementById('temp-' + tempId).remove();
                            // 添加服务器返回的消息
                            addMessage(data.message.id, data.message.content, true, data.message.username, data.message.avatar, data.message.created_at);
                            // 更新lastPrivateMessageId，避免轮询时重复获取
                            lastPrivateMessageId = data.message.id;
                        } else {
                            alert(data.message);
                            document.getElementById('temp-' + tempId).remove();
                        }
                    });
                }
                
                // 清空输入框
                messageInput.value = '';
                messageInput.style.height = 'auto';
            }
        }
        
        function addMessage(id, content, isOwn, username = '', avatar = '', createdAt = new Date()) {
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message ' + (isOwn ? 'own' : 'other');
            messageDiv.id = isOwn && !username ? 'temp-' + id : 'message-' + id;
            
            const avatarUrl = isOwn ? '../assets/uploads/<?php echo $_SESSION['avatar']; ?>' : '../assets/uploads/' + avatar;
            const senderName = isOwn ? '<?php echo $_SESSION['username']; ?>' : username;
            const time = typeof createdAt === 'string' ? new Date(createdAt) : createdAt;
            
            messageDiv.innerHTML = `
                <img src="${avatarUrl}" alt="头像" class="message-avatar">
                <div class="message-content">
                    ${!isOwn ? '<div class="message-sender">' + senderName + '</div>' : ''}
                    <div class="message-text">${content}</div>
                    <div class="message-time">${time.getHours().toString().padStart(2, '0')}:${time.getMinutes().toString().padStart(2, '0')}</div>
                </div>
            `;
            
            chatBody.appendChild(messageDiv);
            chatBody.scrollTop = chatBody.scrollHeight;
        }
        
        // 轮询获取新消息
        setInterval(() => {
            if (currentChatMode === 0) {
                // 群聊消息
                fetch('index.php?action=getMessages&last_id=' + lastMessageId)
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success' && data.messages.length > 0) {
                            data.messages.forEach(message => {
                                if (message.id > lastMessageId) {
                                    lastMessageId = message.id;
                                    addMessage(message.id, message.content, message.user_id == <?php echo $_SESSION['user_id']; ?>, message.username, message.avatar, message.created_at);
                                }
                            });
                        }
                    });
            } else {
                // 私聊消息
                fetch('index.php?action=getPrivateMessages&receiver_id=' + currentChatUserId + '&last_id=' + lastPrivateMessageId)
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success' && data.messages.length > 0) {
                            data.messages.forEach(message => {
                                if (message.id > lastPrivateMessageId) {
                                    lastPrivateMessageId = message.id;
                                    addMessage(message.id, message.content, message.sender_id == <?php echo $_SESSION['user_id']; ?>, message.username, message.avatar, message.created_at);
                                }
                            });
                        }
                    });
            }
        }, 2000);
        
        // 点击用户切换聊天模式
        const userItems = document.querySelectorAll('.user-item');
        userItems.forEach(item => {
            item.addEventListener('click', function() {
                const userId = parseInt(this.dataset.userId);
                const username = this.dataset.username;
                
                // 更新用户项状态
                userItems.forEach(i => i.classList.remove('active'));
                this.classList.add('active');
                
                // 更新聊天模式
                currentChatMode = userId;
                currentChatUserId = userId;
                currentChatUsername = username;
                
                // 更新聊天标题
                chatTitle.textContent = username;
                
                // 清空聊天内容
                chatBody.innerHTML = '';
                
                // 加载聊天历史
                if (userId === 0) {
                    // 加载群聊历史
                    fetch('index.php?action=getMessages&last_id=0')
                        .then(response => response.json())
                        .then(data => {
                            if (data.status === 'success' && data.messages.length > 0) {
                                data.messages.forEach(message => {
                                    addMessage(message.id, message.content, message.user_id == <?php echo $_SESSION['user_id']; ?>, message.username, message.avatar, message.created_at);
                                    lastMessageId = message.id;
                                });
                            }
                        });
                } else {
                    // 加载私聊历史
                    lastPrivateMessageId = 0;
                    fetch('index.php?action=getPrivateMessages&receiver_id=' + userId + '&last_id=0')
                        .then(response => response.json())
                        .then(data => {
                            if (data.status === 'success' && data.messages.length > 0) {
                                data.messages.forEach(message => {
                                    addMessage(message.id, message.content, message.sender_id == <?php echo $_SESSION['user_id']; ?>, message.username, message.avatar, message.created_at);
                                    lastPrivateMessageId = message.id;
                                });
                            }
                        });
                }
            });
        });
        
        // 初始滚动到底部
        chatBody.scrollTop = chatBody.scrollHeight;
        
        // 侧边栏切换功能
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        
        sidebarToggle.addEventListener('click', function(e) {
            e.stopPropagation(); // 阻止事件冒泡
            sidebar.classList.toggle('collapsed');
        });
        
        // 点击聊天区域关闭侧边栏（仅在移动设备）
        const chatMain = document.querySelector('.chat-main');
        chatMain.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                sidebar.classList.add('collapsed');
            }
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>