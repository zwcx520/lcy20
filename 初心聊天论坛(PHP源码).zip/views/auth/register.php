<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>注册 - 初心聊天论坛</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
           background-image: url(../../bj.jpg);
                 background-size: cover; /* 修改为cover，使图片铺满满屏 */
                 background-attachment: fixed; /* 可选，使背景图片固定不随页面滚动 */
                 margin: 0; /* 去除默认边距 */
                 padding: 0; /* 去除默认内边距 */
            min-height: 100vh;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .register-card {
          
            max-width: 400px;
            width: 90%;
            margin: 20px;
            border: none;
        }
        
        @media (max-width: 480px) {
            .register-card {
                width: 95%;
                padding: 20px;
            }
        }
        .register-card h2 {
            color: #ff6b6b;
            text-align: center;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .form-label {
            font-weight: 500;
            color: #555;
        }
        .btn-primary {
            background: #ff6b6b;
            border: none;
            border-radius: 25px;
            padding: 10px 20px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background: #ee5a52;
            transform: translateY(-2px);
        }
        .login-link {
            text-align: center;
            margin-top: 20px;
        }
        .login-link a {
            color: #ff6b6b;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        .avatar-upload {
            text-align: center;
            margin-bottom: 20px;
        }
        .avatar-preview {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #ff6b6b;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="register-card">
      
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form action="index.php?action=register" method="POST" enctype="multipart/form-data">
            <div class="avatar-upload">
                <img id="avatar-preview" class="avatar-preview" src="../assets/images/default.jpg" alt="头像预览">
                <div class="mb-3">
                    <label for="avatar" class="form-label">上传头像</label>
                    <input type="file" class="form-control" id="avatar" name="avatar" accept="image/*" onchange="previewAvatar(this)">
                </div>
            </div>
            
            <div class="mb-3">
                <label for="username" class="form-label">用户名</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="请输入用户名" required>
            </div>
            
            <div class="mb-3">
                <label for="password" class="form-label">密码</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="请输入密码" required>
            </div>
            
            <div class="mb-3">
                <label for="confirm_password" class="form-label">确认密码</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="请再次输入密码" required>
            </div>
            
            <button type="submit" class="btn btn-primary w-100">注册</button>
        </form>
        
        <div class="login-link">
            已有账号？<a href="index.php?action=login">立即登录</a>
        </div>
    </div>
    
    <script>
        function previewAvatar(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('avatar-preview').src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>