<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录 - 初心聊天论坛</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url(../../bj.jpg);
                  background-size: cover; /* 修改为cover，使图片铺满满屏 */
                  background-attachment: fixed; /* 可选，使背景图片固定不随页面滚动 */
                  margin: 0; /* 去除默认边距 */
                  padding: 0; /* 去除默认内边距 */
            min-height: 100vh;
           
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
           
            
            max-width: 400px;
            width: 90%;
            margin: 20px;
            border: none;
        }
        
        @media (max-width: 480px) {
            .login-card {
                width: 95%;
                padding: 20px;
            }
        }
        .login-card h2 {
            color: #ff6b6b;
            text-align: center;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .form-label {
            font-weight: 500;
            color: #555;
        }
        .btn-primary {
            background: #ff6b6b;
            border: none;
            border-radius: 25px;
            padding: 10px 20px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background: #ee5a52;
            transform: translateY(-2px);
        }
        .register-link {
            text-align: center;
            margin-top: 20px;
        }
        .register-link a {
            color: #ffffff;
            text-decoration: none;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
        .logo {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="logo">
            <img src="../assets/images/default.jpg" alt="论坛Logo">
        </div>
       
        <h4 class="text-center mb-4">用户登录</h4>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form action="index.php?action=login" method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">用户名</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="请输入用户名" required>
            </div>
            
            <div class="mb-3">
                <label for="password" class="form-label">密码</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="请输入密码" required>
            </div>
            
            <button type="submit" class="btn btn-primary w-100">登录</button>
        </form>
        
        <div class="register-link">
            没有账号？<a href="index.php?action=register">立即注册</a>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>