<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员页面 - 浪漫萌系聊天论坛</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f5f5f5;
            font-family: 'Microsoft YaHei', sans-serif;
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }
        .container {
            padding: 20px;
        }
        .header {
            background: linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%);
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }
        .header a:hover {
            text-decoration: underline;
        }
        .user-table {
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .user-table th {
            background: #f8f9fa;
            font-weight: bold;
        }
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        .btn-edit {
            background: #07C160;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 5px 10px;
            font-size: 12px;
            cursor: pointer;
        }
        .btn-edit:hover {
            background: #06B158;
        }
        .btn-delete {
            background: #ff6b6b;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 5px 10px;
            font-size: 12px;
            cursor: pointer;
        }
        .btn-delete:hover {
            background: #ee5a52;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1>管理员面板</h1>
                <a href="index.php?action=adminAdd" class="btn btn-primary btn-sm" style="margin-top: 10px; display: inline-block;">添加用户</a>
            </div>
            <div>
                <a href="index.php?action=chat">返回聊天</a> | 
                <a href="index.php?action=logout">退出登录</a>
            </div>
        </div>
        
        <div class="user-table">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>头像</th>
                        <th>用户名</th>
                        <th>创建时间</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td><img src="../assets/uploads/<?php echo $user['avatar']; ?>" alt="头像" class="user-avatar"></td>
                            <td><?php echo $user['username']; ?></td>
                            <td><?php echo $user['created_at']; ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="index.php?action=adminEdit&id=<?php echo $user['id']; ?>" class="btn-edit">编辑</a>
                                    <?php if ($user['id'] != 1): ?>
                                        <a href="index.php?action=adminDelete&id=<?php echo $user['id']; ?>" class="btn-delete" onclick="return confirm('确定要删除这个用户吗？');">删除</a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>