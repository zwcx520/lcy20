<?php
require_once 'config/database.php';
echo "数据库连接和创建功能测试成功！";
?>