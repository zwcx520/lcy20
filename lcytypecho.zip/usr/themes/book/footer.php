<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php 
$url = explode('=',$_SERVER["QUERY_STRING"],2);
$t=date("H");
if ($url[0] =="music") {
	$this->need('music.php');
	exit;
  }
?>
</div>
<!-- end #mians -->
</div>
<!-- end #body -->
<div id="fullScreen">全屏显示</div>

<footer id="footer" role="contentinfo">
<div class="closed_txt">
		<p>双击木桌，</p>
		<p>打开或合上这本书。</p>
	</div>
<a target="_blank" href="<?php $this->options->siteUrl(); ?>admin" id="footer-admin">登陆</a>

  <?php echo date('Y'); ?> 
    &copy;
  <a href="<?php $this->options->siteUrl(); ?>">
    <?php $this->author(); ?>
  </a> &nbsp;
  <?php _e('支持 <a target="_blank" href="https://lcy20.netlify.app/login">归-档时光卷轴</a> &nbsp; '); ?>
</footer>
<!-- end #footer -->

</div>
<!-- end #body-bg -->
</body>
</html>
<?php $this->footer(); ?>