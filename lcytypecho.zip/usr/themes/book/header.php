<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE HTML>
<html>
<style>
body,html{
	padding:0;
	margin:0;
	outline: 0;
	border: 0;
}
#loading{
	transition: all 1s;
	outline: 0;
	background: #444 url(<?php $this->options->themeUrl('img/loading.apng'); ?>) center no-repeat;
	width: 100%;
	height: 100%;
	position: fixed;
	z-index: 999;
	padding:0;
	margin:0;
}</style>
<div id="loading"></div>
<head>
	<meta charset="<?php $this->options->charset(); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
	<meta name="renderer" content="webkit">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>
		<?php $this->archiveTitle(array(
			'category'  =>  _t('分类 %s 下的文章'),
			'search'    =>  _t('包含关键字 %s 的文章'),
			'tag'       =>  _t('标签 %s 下的文章'),
			'author'    =>  _t('%s 发布的文章')
		), '', ' - '); ?>
		<?php $this->options->title(); ?>
	</title>
	<?php if (!empty($this->options->BookSet) && in_array('usecdn', $this->options->BookSet)): ?>
	<script type="text/javascript" src="https://cdn.staticfile.org/jquery/3.3.1/jquery.min.js"></script>
	<script type="text/javascript" src="https://cdn.staticfile.org/jquery.pjax/2.0.1/jquery.pjax.min.js"></script>
	<link rel="stylesheet" href="https://cdn.staticfile.org/jquery.perfect-scrollbar/1.4.0/css/perfect-scrollbar.min.css">
	<script type="text/javascript" src="https://cdn.staticfile.org/jquery.perfect-scrollbar/1.4.0/perfect-scrollbar.min.js"></script>
	<script type="text/javascript" src="https://cdn.staticfile.org/nprogress/0.2.0/nprogress.min.js"></script>
	<link rel="stylesheet" href="https://cdn.staticfile.org/nprogress/0.2.0/nprogress.min.css">
	<script type="text/javascript" src="https://cdn.staticfile.org/prism/9000.0.1/prism.min.js"></script>
	<script type="text/javascript" src="https://cdn.staticfile.org/jquery-mousewheel/3.1.13/jquery.mousewheel.min.js"></script>
	<script type="text/javascript" src="https://cdn.staticfile.org/jquery.form/4.2.2/jquery.form.min.js"></script>
	<?php else:?>
	<script type="text/javascript" src="<?php $this->options->themeUrl('css-js/jquery.min.js'); ?>"></script>
	<script type="text/javascript" src="<?php $this->options->themeUrl('css-js/jquery.pjax.min.js'); ?>"></script>
	<link rel="stylesheet" href="<?php $this->options->themeUrl('css-js/perfect-scrollbar.min.css'); ?>">
	<script type="text/javascript" src="<?php $this->options->themeUrl('css-js/perfect-scrollbar.min.js'); ?>"></script>
	<script type="text/javascript" src="<?php $this->options->themeUrl('css-js/nprogress.min.js'); ?>"></script>
	<link rel="stylesheet" href="<?php $this->options->themeUrl('css-js/nprogress.min.css'); ?>">
	<script type="text/javascript" src="<?php $this->options->themeUrl('css-js/prism.min.js'); ?>"></script>
	<script type="text/javascript" src="<?php $this->options->themeUrl('css-js/jquery.mousewheel.min.js'); ?>"></script>
	<script type="text/javascript" src="<?php $this->options->themeUrl('css-js/jquery.form.min.js'); ?>"></script>
	<?php endif;?>
	<script type="text/javascript" src="<?php $this->options->themeUrl('css-js/main.js'); ?>"></script>
	<link rel="stylesheet" href="<?php $this->options->themeUrl('css-js/prism.css'); ?>">
	<link rel="shortcut icon" href="<?php $this->options->themeUrl('img/favicon.ico'); ?>" type="image/x-icon" />
	<link rel="stylesheet" href="<?php $this->options->themeUrl('style.css'); ?>">
	<link rel="stylesheet" href="<?php $this->options->themeUrl('Book-cover.css'); ?>">
	<!-- 通过自有函数输出HTML头部信息 -->
	<?php $this->header('commentReply='); ?>
</head>
<body>
	<!--[if lt IE 9]>
    <div class="browsehappy" role="dialog"><?php _e('当前网页 <strong>不支持</strong> 你正在使用的浏览器. 为了正常的访问, 请 <a href="https://browsehappy.com/">升级你的浏览器</a>'); ?>.</div>
<![endif]-->
<div id="body-bg">
	<div id="music_rod"></div>
	<div title="没有唱片" id="music_box">	
		<audio loop id="music" src=""></audio>
	</div>
	<div id="music_box_bj"></div>
	<div id="music_volume"><div id="music_v_box"></div><div id="music_volume_c"></div></div>
	<div id="muisc-ku">
	<?php $this->need('desk-music.php'); ?>
	</div>
	<div id="chiji_box"></div>
	<div id="tea_box"></div>
	<div id='img_top_box_bg' onclick='imgClosed()'></div>
	<div id="closed"></div>
	<div id="body">
		<div class="mains">
