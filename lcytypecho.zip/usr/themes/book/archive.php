<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<div id="book-left">
	<?php $this->need('book-cover.php'); ?>
	<div class="book-left-z">
		<div id="postbox-2">
			<h3 class="archive-title">
				<?php $this->archiveTitle(array(
					'category'  =>  _t('分类 %s 下的文章'),
					'search'    =>  _t('包含关键字 %s 的文章'),
					'tag'       =>  _t('标签 %s 下的文章'),
					'author'    =>  _t('%s 发布的文章')
        		), '', ''); ?> </h3>
			<a class="back-catalog" pajx-left href="<?php $this->options->siteUrl(); ?>">
				<--返回目录</a>
					<?php if ($this->have()): ?>
					<?php while($this->next()): ?>
					<article class="post-2" itemscope itemtype="http://schema.org/BlogPosting">
						<h2 class="post-title-2" itemprop="name headline">
							<a pajx-right itemtype="url" href="<?php $this->permalink() ?>">
								<?php $this->title() ?>
							</a>
							<ul class="post-meta">
								<li>
									<time>
										<?php $this->date(' Y年n月j号'); ?>
									</time>
								</li>
							</ul>
						</h2>
					</article>
					<?php endwhile; ?>
					<?php else: ?>
					<article class="post">
						<h2 class="post-title">
							<?php _e('没有找到内容'); ?>
						</h2>
					</article>
					<?php endif; ?>
					<?php $this->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>
		</div>
		<script>
			openBook("withOutAnimat");
			var ps = new PerfectScrollbar('#postbox-2', {wheelSpeed: 0.5,swipeEasing: false});
			if ($(".page-navigator").length > 0) {$(".page-navigator").find('a').attr("pajx-left", "");}
		</script>
	</div>
	<div class="book-shadow"></div>
</div>
<div id="book-right">
	<?php if (!empty($this->options->BookSet) && in_array('Hidebookmarks', $this->options->BookSet)): ?>
	<?php $this->need('nav.php'); ?>
	<?php endif; ?>
	<div id="axjx_box">
		<div id="postbox">
			<div class="site-name">
				<div id="logo">
					<?php $this->author(); ?>
				</div>
				<p class="description"> -
					<?php $this->options->description() ?> - </p>
			</div>
		</div>
	</div>
	<div class="book-shadow"></div>
</div>
<!-- end #main -->
<?php $this->need('footer.php'); ?>