<?php
/**
 * 理念：每个人，都是一本书。
 * 目的：创造优秀的文字阅读体验。                                            
 * 适用：文字为主的博客、博主。
 * Book-cover.css 调整书本封面样式。
 * 
 * @package 书籍主题
 * @author 不见桃花不见秋
 * @version 0.9
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;?>
<?php $this->need('header.php');?>
	<div id="book-left">
		<?php $this->need('book-cover.php'); ?>
		<div class="book-left-z">
			<?php $this->need('catalog.php'); ?>
		</div>
		<div class="book-shadow"></div>
	</div>
	<div id="book-right">
		<?php if (!empty($this->options->BookSet) && in_array('Hidebookmarks', $this->options->BookSet)): ?>
		<?php $this->need('nav.php'); ?>
		<?php endif; ?>
		<div id="axjx_box">
			<div id="postbox">
				<div class="site-name">
					<div id="logo">
						<?php $this->author(); ?>
					</div>
					<p class="description"> -
						<?php $this->options->description() ?> - </p>
				</div>
			</div>
		</div>
		<div class="book-shadow"></div>
	</div>
	<!-- end #main-->
	<script>
		<?php if (!empty($this->options->BookSet) && in_array('autoOpenBooks', $this->options->BookSet)): ?>
		var openbooktime = 1000; //自动打开书本延迟。单位为毫秒。
		var openbookset = setTimeout(function () {
			openBook();
		}, openbooktime);
		<?php endif; ?>
	</script>
	<?php $this->need('footer.php'); ?>