<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div class="kit-hidden-tb" id="secondary" role="complementary">
	<article class="post">
		<div class="post-content-pages">
			<?php $this->widget('Widget_Contents_Post_Recent', 'pageSize=10000')->to($archives);   
	$year=0; $mon=0; $i=0; $j=0; 
	if($this->options->age){$agecs = $this->options->age;};
	$age = NULL;
	$output = '<div id="archives">';  
	while($archives->next()):
		$year_tmp = date('Y',$archives->created);   
		$mon_tmp = date('m',$archives->created);      
		$y=$year; $m=$mon;
             if ($mon != $mon_tmp && $mon > 0) $output .= '</ul></li>';   
             if ($year != $year_tmp && $year > 0) $output .= '</ul>';   
             if ($year != $year_tmp) {   
                 $year = $year_tmp;
                 $output .= '<div class="al_year">'. $year . ' 年<br/><span class="al_age"> '; //输出年份   
				 if($this->options->age){
					$age = $year - $agecs;
					$output .='' . $age.'岁';};
				 $output .= '&nbsp;<span></div><ul class="al_mon_list">';
             }   
             $output .= '<li><a href="'.$archives->permalink .'">'. $archives->title .'</a>
			 <span>'.date('m - d',$archives->created).'</span></li>'; //输出文章日期和标题   
        endwhile;   
        $output .= '</ul></li></ul></div>';   
        echo $output;   
        ?>
		</div>
	</article>
	<script>
		if(ismMobile()){
			$(".al_mon_list").find("a").click(function () {$("#book-left").css({"margin-left":"-100%"})})
		}else{
			$("#archives").find("a").attr("pajx-right", "");
			var ps = new PerfectScrollbar('#secondary', {wheelSpeed: 0.5,swipeEasing: false,suppressScrollX :false});
			$(".al_mon_list").find("a").click(function () {catalogClickList(this)})
		}
		
	</script>
</div>
<!-- end #catalog -->