<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
function themeConfig($form) {
    $bookCover = new Typecho_Widget_Helper_Form_Element_Text('bookCover', NULL, NULL, _t('书本封面图片'), _t('在这里填入一个图片 URL 地址, 以用于书本封面图片。<br/>默认为模板 <b>img</b> 文件夹下的 <b>book.png</b> ，路径 <b>“usr\themes\book\img\book.png”</b>，也可直接替换 <b>book.jpg</b><br/>书本名称、作者、腰封等样式，可以在-编辑当前外观->Book-cover.css 中设置 '));
    $form->addInput($bookCover);

	$age = new Typecho_Widget_Helper_Form_Element_Text('age', NULL ,NULL, _t('出生年份（用于显示年龄）'), _t('填入出生年份，如“1988”（不带引号），留空将不会显示年龄。'));
    $form->addInput($age);
	
	$BookSet = new Typecho_Widget_Helper_Form_Element_Checkbox('BookSet', 
    array('autoOpenBooks' => _t('载入主页后，自动打开书本'),
    'Hidebookmarks' => _t('显示右侧书签（导航栏）'),
    'usecdn' => _t("使用 <a href='http://staticfile.org/'>staticfile.org</a> CDN加速加载部分 CSS-JS 资源（推荐国外/香港主机使用）")
	),
    array('Hidebookmarks'), _t('一些设置'));
    $form->addInput($BookSet->multiMode());
}
// function themeFields($layout) {
    // $logoUrl = new Typecho_Widget_Helper_Form_Element_Text('logoUrl', NULL, NULL, _t('站点LOGO地址'), _t('在这里填入一个图片URL地址, 以在网站标题前加上一个LOGO'));
    // $layout->addItem($logoUrl);
// }