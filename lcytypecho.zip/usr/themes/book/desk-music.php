<style>
.rawm{
	top: 300px;
	right: 30px;
}
.pt{
	top: 430px;
	right: 50px;
}
.aaaa{
	top: 230px;
	right: 100px;
}
</style>
<a musicdesk class="rawm" server="netease" songid="1371353582" ></a>
<a musicdesk class="aaaa" server="netease" songid="569213220" ></a>
<!-- <a musicdesk class="gpqq" server="kugou" songid="0A62227CAAB66F54D43EC084B4BDD81F" ></a> -->
<!-- <a musicdesk class="pt" title="告白气球" cover="https://artcg-1254234392.cossh.myqcloud.com/book/gbqq.jpg" url="https://artcg-1254234392.cossh.myqcloud.com/book/M800003OUlho2HcRHC.mp3"></a> -->
