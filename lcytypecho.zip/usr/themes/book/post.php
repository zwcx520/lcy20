<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div id="book-left">
	<?php $this->need('book-cover.php'); ?>
	<div class="book-left-z">
		<?php $this->need('catalog.php'); ?>
	</div>
	<div class="book-shadow"></div>
</div>
<div id="book-right">
	<?php if (!empty($this->options->BookSet) && in_array('Hidebookmarks', $this->options->BookSet)): ?>
	<?php $this->need('nav.php'); ?>
	<?php endif; ?>
	<div id="axjx_box">
		<div id="axjx_box2">
			<div id="postbox">
				<article class="post" id="post_box" itemscope itemtype="http://schema.org/BlogPosting">
					<h1 class="post-title" itemprop="name headline">
						<a pajx-right itemtype="url" href="<?php $this->permalink() ?>">
							<?php $this->title() ?>
						</a>
					</h1>
					<ul class="post-meta">
						<li itemprop="author" itemscope itemtype="http://schema.org/Person">
							<?php $this->author(); ?>
						</li>
						<li id="alage">
							<?php 
							if($this->options->age){
								$time_1 = $this->created ;
								$Mybirthyear = $this->options->age;
								$ageNmb = date('Y',$time_1) - $Mybirthyear ;
								echo ''.$ageNmb."岁";}?>
						</li>
						<li>
							<?php _e('写于'); ?>
							<time datetime="<?php $this->date('c'); ?>" itemprop="datePublished">
								<?php $this->date('Y年n月j日'); ?>
							</time>
						</li>
						<li id="category">
							<?php _e(' 分类: '); ?>
							<?php $this->category(',');?>
						</li>
					</ul>
					<div class="post-content" itemprop="articleBody">
						<?php $this->content(); ?>
					</div>
					<p itemprop="keywords" class="tags">
						<?php _e('标签: '); ?>
						<?php $this->tags('', true, '没有标签'); ?>
					</p>
				</article>
				<?php $this->need('comments.php'); ?>
			</div>
			<?php if($this->user->hasLogin()): ?>
						<div id="editpost">
							<a target="_blank" href="<?php $this->options->adminUrl('write-post.php'.'?cid='.$this->cid); ?>" >编辑文章</a>
							</div>
						<?php endif; ?>
			<div id="rightSchedule"></div>
			<script>
			if(ismMobile()){
				$("#book-left").css({"margin-left":"-100%"})
			}else{
				if($("a[music]").length>0){
				$("a[music]").each(function () {
					$(this).addClass("music-link");
					loadMusic($(this));
				  })
				$(".music-link").click(function () {musicPlay(this);});
				};
				$("#category").children("a").attr("pajx-left", "");
				$(".tags").children("a").attr("pajx-left", "");
				openBook("withOutAnimat");
				var ps = new PerfectScrollbar('#postbox', {wheelSpeed: 0.5,swipeEasing: false,suppressScrollX: false});
			}
			if (($("#post_box").height() + $("#comments").height()) > 800) {rightSchedule();};
			var img = $(".post-content").find("img");
			if (img.length > 0) {imgStyle(img);img.click(function () {imgbig(this);});};
			if ($(".post-content").find("pre").length > 0){Prism.highlightAll();};
			
			
		</script>
		</div>
	</div>
	<div class="book-shadow"></div>
</div>

<!-- end #main-->
<?php $this->need('footer.php'); ?>
<div id="shoujizhuye"><a href="<?php $this->options->siteUrl(); ?>">文章<br>列表</a></div>