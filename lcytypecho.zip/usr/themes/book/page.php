<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<div id="book-left">
	<?php $this->need('book-cover.php'); ?>
	<div class="book-left-z">
		<?php $this->need('catalog.php'); ?>
	</div>
	<div class="book-shadow"></div>
</div>
<div id="book-right">
	<?php if (!empty($this->options->BookSet) && in_array('Hidebookmarks', $this->options->BookSet)): ?>
	<?php $this->need('nav.php'); ?>
	<?php endif; ?>
	<div id="axjx_box">
		<div id="postbox">
			<article class="post" itemscope itemtype="http://schema.org/BlogPosting">
				<h1 class="post-title" itemprop="name headline">
					<a pajx-right itemtype="url" href="<?php $this->permalink() ?>">
						<?php $this->title() ?>
					</a>
				</h1>
				<div class="post-content" itemprop="articleBody">
					<?php $this->content(); ?>
				</div>
			</article>
			<?php $this->need('comments.php'); ?>
		</div>
		<div id="rightSchedule"></div>
		<script>
			var ps = new PerfectScrollbar('#postbox', {wheelSpeed: 0.5,swipeEasing: false,suppressScrollX: false});
			if (($("#post_box").height() + $("#comments").height()) > 800) {rightSchedule();};
			var img = $(".post-content").find("img");
			if (img.length > 0) {imgStyle(img);img.click(function () {imgbig(this);});};
			if ($(".post-content").find("pre").length > 0){Prism.highlightAll();};
			$("#category").children("a").attr("pajx-left", "");
			$(".tags").children("a").attr("pajx-left", "");
			openBook("withOutAnimat");
			if($("a[music]").length>0){
				$("a[music]").addClass("music-link");
				$(".music-link").click(function () {musicPlay(this);});
			};
		</script>
	</div>
	<div class="book-shadow"></div>
</div>
<!-- end #main-->
<?php $this->need('footer.php'); ?>