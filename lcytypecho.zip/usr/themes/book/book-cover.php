<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div id="Book-cover" <?php 
			if($this->options->bookCover){
                $bookurl = $this->options->bookCover;
                echo "style='background-image:url(".$bookurl.")!important'";
			};
        ?>>
        <div class="Book-cover-c"></div>
		<div id="Book-cover-name">
			<?php $this->options->title()?>
		</div>
		<div id="Book-cover-author">
			<?php echo $this->author()?>◎著</div>
		<div id="Book-cover-girdle">
			<div class="Book-cover-description"> -
				<?php $this->options->description() ?> - </div>
        </div>
        <div id="Publishing-house"></div>
        <div class="Book-cover-customize-01"></div>
        <div class="Book-cover-customize-02"></div>
        <div class="Book-cover-customize-02"></div>
</div>