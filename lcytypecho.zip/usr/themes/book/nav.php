<div class="nav-box">
	<div class="nav-z"></div>
	<nav id="nav-menu" class="clearfix" role="navigation">
		<a pajx-right <?php if($this->is('index')): ?> class="current"
			<?php endif; ?> href="
			<?php $this->options->siteUrl(); ?>">
			<?php _e('首页'); ?>
			<span></span>
		</a>
		<div class="page-s"></div>
		<?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
		<?php while($pages->next()): ?>
		<a pajx-right <?php if($this->is('page', $pages->slug)): ?> class="current"
			<?php endif; ?> href="
			<?php $pages->permalink(); ?>" title="
			<?php $pages->title(); ?>">
			<?php $pages->title(); ?>
			<span></span>
		</a>
		<div class="page-s"></div>
		<?php endwhile; ?>
	</nav>
</div>