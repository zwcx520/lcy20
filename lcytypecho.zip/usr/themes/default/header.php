<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
if($this->request->get('type')=='comments'){$this->need('comments.php');exit;}?>
<!DOCTYPE HTML>
<html lang="zh-CN" x-data="{dark:<?php if(isset($_COOKIE['dark'])&&$_COOKIE['dark']=='dark'){echo 'true';}else{echo 'false';} ?>,search:false,login:false,register:false,top:'top-0',footer:false,hue:<?php echo hue;?>,colornum:0}" :class="{'dark':dark}"
x-init="
if (main.getCookie('colornum')) {colornum=main.getCookie('colornum');}else{colornum=hue;}
if (document.cookie.indexOf('dark') < 0) {
darkModeQuery = window.matchMedia('(prefers-color-scheme: dark)');
darkModeQuery.addListener(handleColorSchemeChange);
handleColorSchemeChange(darkModeQuery); 
function handleColorSchemeChange(event) {
if (event.matches) {dark=true;document.cookie = 'dark=dark;path=/';}else{dark=false;document.cookie = 'dark=light;path=/';}
}
}
" class="<?php if(isset($_COOKIE['dark'])&&$_COOKIE['dark']=='dark'){echo 'dark';} ?>"
:style="'--hue: '+colornum+';'"
>
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="format-detection" content="telephone=no,email=no"/>
    <title><?php if($this->_currentPage>1) echo '第'.$this->_currentPage.'页 - '; ?><?php $this->archiveTitle([
            'category' => _t('分类 %s 下的文章'),
            'search'   => _t('包含关键字 %s 的文章'),
            'tag'      => _t('标签 %s 下的文章'),
            'author'   => _t('%s 发布的文章')
        ], '', ' - ');if($this->is('post')){subtitle($this,' - ');} ?><?php $this->options->title(); ?><?php if($this->options->subtitle&&$this->is('index')){echo ' - '.$this->options->subtitle;} ?></title>

    <?php if($this->options->ico): ?><link rel="icon" href="<?php $this->options->ico(); ?>"><?php endif; ?>
    <!-- 使用url函数转换相关路径 -->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('style.css?202504'); ?>">
    <link rel="stylesheet" href="<?php $this->options->themeUrl('src/tw.min.css?20250329'); ?>">
<?php $this->need('assets/head.php');?>
    <!-- 通过自有函数输出HTML头部信息 -->
    <?php $this->header('generator=&template=&commentReply='); ?>
    <?php $this->options->header(); ?><?php if($this->options->diycss){echo '<style>'.$this->options->diycss.'</style>';} ?>
    <script type='text/javascript'>/* <![CDATA[ */
var ze = {"url":"<?php $this->options->siteUrl(); ?>","theme_url":"<?php echo theurl; ?>","domain":"<?php echo getDomain; ?>","biaoqing":"","rewrite":"<?php if(!$this->options->rewrite){echo 'index.php/';} ?>"};
/* ]]> */</script>


<?php $image=$this->options->logo ? $this->options->logo : $this->options->themeUrl.'img/logo.png';?>
<meta property="og:type" content="blog"/>
<meta property="og:release_date" content="<?php if($this->is('single')){ $this->date('Y年m月d日');}else{echo date("Y年m月d日", getAuthor()['created']); } ?>"/>
<meta property="og:author" content="@<?php if($this->is('single')){$this->author();}else{echo getAuthor()['screenName'];} ?>"/>

<!-- Primary Meta Tags -->
<meta name="title" content="<?php if($this->is('index')){$this->options->title();}else{$this->archiveTitle('','','');} ?>">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="<?php $this->options->SiteUrl(); ?>">
<meta property="og:title" content="<?php if($this->is('index')){$this->options->title();}else{$this->archiveTitle('','','');} ?>"/>
<meta property="og:description" content="<?php echo $this->getDescription(); ?>" />
<meta property="og:image" content="<?php if($this->is('single')){ showThumbnail($this);}else{echo $image; } ?>"/>

<!-- Twitter -->
<meta property="twitter:card" content="summary">
<meta property="twitter:url" content="<?php $this->options->SiteUrl(); ?>">
<meta property="twitter:title" content="<?php if($this->is('index')){$this->options->title();}else{$this->archiveTitle('','','');} ?>">
<meta property="twitter:description" content="<?php echo $this->getDescription(); ?>">
<meta property="twitter:image" content="<?php if($this->is('single')){ showThumbnail($this);}else{echo $image; } ?>">


</head>

<body class=" scroll-smooth bg-[var(--page-bg)] text-black dark:text-white">
<div id="main">
<header class="header" x-data="{menu:false}">
    <?php include('navbars.php'); ?>
</header>
<main class="main" x-init="search=false;top='top-10';<?php if($this->is('single')):?>top='top-28';<?php endif;?>">

<div class="h-[47vh] lg:h-[65vh] w-full overflow-hidden -z-10 relative -top-5 <?php if($this->is('single')){ echo ' animate-headerbgup';}else{echo ' animate-headerbgdown'; } ?>
">
<img alt="Banner image of the blog" class="object-cover h-full w-full" src="<?php if($this->options->headerbg){$this->options->headerbg();}else{$this->options->themeUrl('img/headerbg.webp');} ?>" style="object-position:center" loading="lazy">
</div>


<?php include('order.php'); ?>

