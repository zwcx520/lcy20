<?php if($this->is('post')): ?>
<?php if(empty($this->options->tools)||!in_array('tj', $this->options->tools)): ?>
<div class="bg-white dark:bg-gray-900 mt-8 p-5 rounded-lg shadow">
<?php $this->widget('Widget_Post_tongleisuiji@suiji', 'mid=0&pageSize=4&cid='.$this->cid)->to($new); ?>
<div class="text-xl mb-3 font-medium">
<?php getTitleTemplate('猜你喜欢');?>
</div>
<div class="grid sm:grid-cols-2 gap-4 text-sm text-gray-500 dark:text-gray-300">
<?php while ($new->next()): ?>

<div class="flex items-center mb-3">
<a href="<?php $new->permalink(); ?>" class="flex-none media size-10 sm:size-16 rounded-lg overflow-hidden mr-3 shadow-lg">
    <img class="transition-transform duration-200 group-hover:scale-110 media-content h-full w-full object-cover" src="<?php  showThumbnail($new); ?>" alt="<?php $new->title() ?>">
</a>
<div class="flex-1 border-b-2 border-gray-200/80 pb-2 dark:border-white/20">
                    <a href="<?php $new->permalink(); ?>">
                        <h2 class="font-medium line-clamp-1 text-black dark:text-white mb-1"><?php $new->title(); ?></h2>
                        <p class="text-sm line-clamp-1"><?php echo excerpt($new,90, '...'); ?></p>
                    </a>
</div>
</div>
<?php endwhile; ?>
</div>
</div>
<?php endif;?>
<?php endif;?>



