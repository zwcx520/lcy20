<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
$this->need('list.php');
?>
<?php $this->need('footer.php');
?>