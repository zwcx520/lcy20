<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
?>



<h2 class="flex flex-wrap items-center bg-white dark:bg-gray-900 rounded-lg mb-6 p-3 lg:px-5 text-sm text-black dark:text-gray-200">
<svg class="size-6 mr-0.5" aria-hidden="true"><use xlink:href="#quill_pen_line"></use></svg>找到
<span class="text-[var(--primary)] mx-0.5"><?php echo $this->getTotal();?></span>
篇与 <span class="text-[var(--primary)] mx-0.5"><?php $this->archiveTitle('', '', ''); ?></span> 相关的结果</h2>


<?php $this->need('list.php'); ?>


<?php $this->need('footer.php'); ?>