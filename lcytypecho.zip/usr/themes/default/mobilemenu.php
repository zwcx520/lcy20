<aside class="z-60 flex flex-col w-64 fixed left-0 h-full bg-gray-100 dark:bg-gray-800 duration-300 -translate-x-full" :class="{'translate-x-0':menu,'-translate-x-full':!menu}">
<div class="m-2">
<button @click="menu=!menu">
<svg class="size-8" aria-hidden="true"><use xlink:href="#close_fill"></use></svg>
</button>
</div>

<div class="flex flex-col bg-white dark:bg-gray-600 p-3 mx-5 rounded-lg text-sm">

<?php
if (array_key_exists('ZeMenu', Typecho_Plugin::export()['activated'])&&!empty(ZeMenu_Plugin::zemenu())):
    $result=ZeMenu_Plugin::zemenu();
    $thisPageUrl=$this->request->getRequestUrl();
 ?>
<?php 
foreach ($result as $val){
$blank='';if($val['blank']==1){$blank=' target="_blank"';}
if(empty($val['son'])){
?>

<a href="<?php echo $val['a'];?>" <?php echo $blank;?> class="p-2 flex items-center duration-300 rounded-lg hover:text-[var(--primary)]">
<svg class="-rotate-90 size-2 mr-2" aria-hidden="true"><use xlink:href="#down_small_fill"></use></svg><span><?php echo $val['name'];?></span></a>


<?php }else{?>
    <li x-data="{open:false}" class="flex flex-col items-center list-none relative p-2" :class="{'!pb-0':open}">
<div @click="open=!open" class="flex items-center justify-between  duration-300 w-full" :class="{'text-[var(--primary)]':open}">

<div class="flex items-center"><svg class="-rotate-90 size-2 mr-2" aria-hidden="true"><use xlink:href="#down_small_fill"></use></svg><span><?php echo $val['name'];?></span></div>
<svg class="ml-0.5 size-1.5" aria-hidden="true"><use xlink:href="#down_small_fill"></use></svg>
</div>

<ul x-cloak x-show="open" class="w-full flex flex-col" x-collapse>


                <?php  foreach ($val['son'] as $xval){$blank='';if($xval['blank']==1){$blank=' target="_blank"';} ?>
<li class="list-none block mt-3 transition-colors duration-300 transform rounded-lg mx-5 hover:text-[var(--primary)]">
<a href="<?php echo $xval['a'] ?>" <?php echo $blank;?> title="<?php echo $xval['name'] ?>"><?php echo $xval['name'] ?>
</a>
</li>
<?php } ?>
            </ul>
        </li>
<?php }} ?>
<?php else: ?>






<?php $this->widget('Widget_Metas_Category_List')->to($categorys); ?>
<?php while($categorys->next()): ?>
<?php if ($categorys->levels === 0): ?>
<?php $children = $categorys->getAllChildren($categorys->mid); ?>
<?php if (empty($children)) { ?>
<li class="list-none p-2 duration-300 hover:text-[var(--primary)]">
<a class="flex items-center" href="<?php $categorys->permalink(); ?>" title="<?php $categorys->name(); ?>">
<svg class="-rotate-90 size-2 mr-2" aria-hidden="true"><use xlink:href="#down_small_fill"></use></svg><span><?php $categorys->name(); ?></span></a>
</li>
<?php } else { ?>
<li x-data="{open:false}" class="flex flex-col items-center list-none relative p-2">
<div @click="open=!open" class="flex items-center justify-between  duration-300 w-full" :class="{'text-[var(--primary)]':open}">

<div class="flex items-center"><svg class="-rotate-90 size-2 mr-2" aria-hidden="true"><use xlink:href="#down_small_fill"></use></svg><span><?php $categorys->name(); ?></span></div>
<svg class="ml-0.5 size-1.5" aria-hidden="true"><use xlink:href="#down_small_fill"></use></svg>
</div>


<ul x-cloak x-show="open" class="w-full flex flex-col" x-collapse.duration.200ms>
<?php foreach ($children as $mid) { ?>
<?php $child = $categorys->getCategory($mid); ?>
<li class="list-none block mt-3 transition-colors duration-300 transform rounded-lg mx-5 hover:text-[var(--primary)]">
    <a href="<?php echo $child['permalink'] ?>" title="<?php echo $child['name']; ?>"><?php echo $child['name']; ?></a>
</li>
<?php } ?>
</ul></li>
<?php } ?><?php endif; ?><?php endwhile; ?>





                <li x-data="{open:false}" class="flex flex-col items-center list-none relative p-2" :class="{'!pb-0':open}">
<div @click="open=!open" class="flex items-center justify-between  duration-300 w-full" :class="{'text-[var(--primary)]':open}">

<div class="flex items-center">
<svg class="-rotate-90 size-2 mr-2" aria-hidden="true"><use xlink:href="#down_small_fill"></use></svg>
<span>其他</span></div>
<svg class="ml-0.5 size-1.5" aria-hidden="true"><use xlink:href="#down_small_fill"></use></svg>
</div>

<ul x-cloak x-show="open" class="w-full flex flex-col"  x-collapse.duration.200ms>
                <?php \Widget\Contents\Page\Rows::alloc()->to($pages); ?>
                    <?php if($pages->have()): ?>
                    <?php while ($pages->next()): ?>
                    <li class="list-none block mt-3 transition-colors duration-300 transform rounded-lg mx-5 hover:text-[var(--primary)]">
                    <a href="<?php if($pages->fields->url){$pages->fields->url();}else{$pages->permalink();} ?>"
                        <?php if($pages->fields->url){echo 'target="_blank"';}?>
                        ><?php $pages->title(); ?></a>
                    </li>
                    <?php endwhile; ?>
                    <?php endif; ?>
                </ul>
                 </li>
</div>



<?php endif;?>









</aside>


<div class="fixed inset-0 z-50 w-full h-screen transition duration-300 origin-top bg-white/70 backdrop-blur-2xl dark:bg-gray-900/70 -translate-x-full"
    :class="{'-translate-x-full':!menu}"
    @click="menu=false">
</div>