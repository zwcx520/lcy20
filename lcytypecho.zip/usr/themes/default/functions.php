<?php

define("rooturl",Helper::options()->rootUrl.'/');//获取首页地址
define("thename",Helper::options()->theme);//定义模板名字
define("theurl",Helper::options()->rootUrl.__TYPECHO_THEME_DIR__ . '/' . Helper::options()->theme.'/');//多域名跨域问题解决方案
define("getDomain",str_replace(array("https:","http:","/"),"",Helper::options()->rootUrl));


include("lib/shortcode.php");
include("lib/buju.php");
include("lib/pagination.php");
include("config.php");
include("setting.php");

if(!defined('hue')){define('hue',250);}

$Pluginactivated =Typecho_Plugin::export()['activated'];
if(array_key_exists('TePass', $Pluginactivated)){
    define("tepassok",true);
    define("tepasssignin",Helper::options()->rootUrl.'/tepass/signin');
    define("tepasssignup",Helper::options()->rootUrl.'/tepass/signup');
}else{define("tepassok",false);}

function themeFields($layout) {

}

function themeInit($archive)
{
\Widget\User::alloc()->to($user);
\Widget\Options::alloc()->to($options);
\Widget\Security::alloc()->to($security);
$db = Typecho_Db::get();
$prefix = $db->getPrefix();
$request = $options->request;
$response = $options->response;

// 强制用户文章最新评论显示在文章首页
 $options->commentsPageDisplay = 'first';
// 将较新的评论显示在前面
 $options->commentsOrder= 'DESC';
// 突破评论回复楼层限制
 $options->commentsMaxNestingLevels = 999;
 
 $options->commentsAntiSpam = false;
 
 Helper::options()->commentsMarkdown=true;

 Helper::options()->commentsHTMLTagAllowed= Helper::options()->commentsHTMLTagAllowed.'<img class="" src="" title="">';

 if($archive->is('single')&&$archive->hidden){
    $archive->response->setStatus(200);
}


 if(($archive->is('post')||$archive->is('page'))&&$archive->request->get('cid')&&$archive->request->get('api')=='like'){
    $sj['likenum']=likeup($archive->request->get('cid'),"return");
    $sj['comnum']=$archive->commentsNum;
    $sj['view']=get_post_view($archive,1);
    
    $write=0;$post='post';if($archive->is('page')){$post='page';}
    if($user->hasLogin()&&($user->uid==$archive->authorId||$user->pass('editor',true))){
    $write=  $options->adminUrl.'write-'.$post.'.php?cid='.$archive->cid;
    }


    $sj['write']=$write;
    echo json_encode($sj);exit;
    }
    
 if($archive->request->get('api')=='info'){
    $data['login']=0;
    $data['register']=0;

    if($options->allowRegister){
    $data['register']=1;
    }

    if ($user->hasLogin()){
    $url=$user->permalink;
    $ucenter='false';
    if(array_key_exists('Ucenter', Typecho_Plugin::export()['activated'])){
    $ucenter=$options->siteUrl.'ucenter';
    }
    $data['login']=1;
    $data['user']=array(
        'uid'=>$user->uid,
        'name'=>$user->screenName,
        'img'=>tx($user->mail,'blank',$user->uid),
        'wztx'=>letter_avatarx($user->screenName),
        'mail'=>$user->mail,
        'url'=>$url,
        'group'=>$user->group,
        'adminUrl'=>$options->adminUrl,
        'logoutUrl'=>$options->siteUrl.'?api=logout',
        'ucenter'=>$ucenter,
        );
    }
    echo json_encode($data);exit; 
 }
 if($archive->request->get('api')=='cateicon'&&$archive->request->get('mid')&&$archive->request->get('type')){
$data['img']=cateicon($archive->request->get('mid'),$archive->request->get('type'));
echo json_encode($data);
exit; 
 }
 
 if($archive->request->get('api')=='upload'&&$archive->request->get('type')=='cate'){
    if($user->pass('administrator', true)){
    $path = \Typecho\Common::url(
        defined('__TYPECHO_UPLOAD_DIR__') ? __TYPECHO_UPLOAD_DIR__ : \Widget\Upload::UPLOAD_DIR,
        defined('__TYPECHO_UPLOAD_ROOT_DIR__') ? __TYPECHO_UPLOAD_ROOT_DIR__ : __TYPECHO_ROOT_DIR__
    ) . '/category/';
    upload(md5($archive->request->get('name')),$path);
    }else{
        $response->throwJson(array('status'=>0,'msg'=> '权限不够'));
    }
    exit;
 }

 if($archive->request->get('api')=='upload'&&$archive->request->get('type')=='author'){
    if($user->pass('administrator', true)||$user->uid==$archive->request->get('name')){
    $path = \Typecho\Common::url(
        defined('__TYPECHO_UPLOAD_DIR__') ? __TYPECHO_UPLOAD_DIR__ : \Widget\Upload::UPLOAD_DIR,
        defined('__TYPECHO_UPLOAD_ROOT_DIR__') ? __TYPECHO_UPLOAD_ROOT_DIR__ : __TYPECHO_ROOT_DIR__
    ) . '/author/';
    upload(md5($archive->request->get('name')),$path);
    }else{

        $response->throwJson(array('status'=>0,'msg'=> '仅限不够'));
    }
    exit;
 }

 if($archive->request->get('api')=='upload'&&$archive->request->get('type')=='avatar'){
    if($user->pass('administrator', true)||$user->uid==$archive->request->get('name')){
    $path = \Typecho\Common::url(
        defined('__TYPECHO_UPLOAD_DIR__') ? __TYPECHO_UPLOAD_DIR__ : \Widget\Upload::UPLOAD_DIR,
        defined('__TYPECHO_UPLOAD_ROOT_DIR__') ? __TYPECHO_UPLOAD_ROOT_DIR__ : __TYPECHO_ROOT_DIR__
    ) . '/avatar/';
    upload(md5($archive->request->get('name')),$path);
    }else{

        $response->throwJson(array('status'=>0,'msg'=> '仅限不够'));
    }
    exit;
 }

 if($archive->request->get('api')=='author'&&$archive->request->get('uid')){
    $author=Helper::widgetById('Users',$archive->request->get('uid'));
    $data['screenName']=$author->screenName;
    $data['mail']=$author->mail; 
    $data['url']=$author->url; 
    $data['tx']=tx($author->mail,"blank",$archive->request->get('uid'));
    $data['txx']=letter_avatarx($author->screenName);
    if (!$user->hasLogin()||$user->uid!=$archive->request->get('uid')){
    $data['mail']=maskEmail($author->mail); 
    }
    echo json_encode($data);exit; 
 }

 if($archive->request->get('api')=='register'){
    //$security->protect();



    /** 如果已经登录 */
    if ($user->hasLogin()) {
        $response->throwJson(array('status'=>0,'msg'=> '您已登录，无需注册！'));
    }
    if(!$options->allowRegister){
        $response->throwJson(array('status'=>0,'msg'=> '网站注册功能已关闭！'));
    }

    $obj = \Typecho\Widget::widget('Widget\Base\Users');
    /** 初始化验证类 */
    $validator = new Typecho_Validate();
    $validator->addRule('name', 'required', _t('必须填写用户名称'));
    $validator->addRule('name', 'minLength', _t('用户名至少包含2个字符'), 2);
    $validator->addRule('name', 'maxLength', _t('用户名最多包含32个字符'), 32);
    $validator->addRule('name', 'xssCheck', _t('请不要在用户名中使用特殊字符'));
    $validator->addRule('name', [$obj, 'nameExists'], _t('用户名已经存在'));
    $validator->addRule('mail', 'required', _t('必须填写电子邮箱'));
    $validator->addRule('mail', [$obj, 'mailExists'], _t('电子邮箱地址已经存在'));
    $validator->addRule('mail', 'email', _t('电子邮箱格式错误'));
    $validator->addRule('mail', 'maxLength', _t('电子邮箱最多包含64个字符'), 64);

        $validator->addRule('password', 'required', _t('必须填写密码'));
        $validator->addRule('password', 'minLength', _t('为了保证账户安全, 请输入至少六位的密码'), 6);
        $validator->addRule('password', 'maxLength', _t('为了便于记忆, 密码长度请不要超过十八位'), 18);
        $validator->addRule('confirm', 'confirm', _t('两次输入的密码不一致'), 'password');

    /** 截获验证异常 */
    if ($error = $validator->run($request->from('name', 'password', 'mail', 'confirm'))) {
        $response->throwJson(array('status'=>0,'msg'=> implode(';',$error)));
    }

    $hasher = new \Utils\PasswordHash(8, true);
    $generatedPassword = $request->password;

    $dataStruct = [
        'name' => $request->name,
        'mail' => $request->mail,
        'screenName' => $request->name,
        'password' => $hasher->hashPassword($generatedPassword),
        'created' => $options->time,
        'group' => 'subscriber'
    ];

    $dataStruct = $obj->pluginHandle()->register($dataStruct);

    $insertId = $obj->insert($dataStruct);
    $db->fetchRow($obj->select()->where('uid = ?', $insertId)
        ->limit(1), [$obj, 'push']);
    $obj->pluginHandle()->finishRegister($obj);

        $user->login($request->name, $generatedPassword);
     $response->throwJson(array('status'=>1,'msg'=> '注册成功！'));


 }



  if($archive->request->get('api')=='login'){
    $expire=24 * 3600;
    $status=0;
    if($user->login($archive->request->name, $archive->request->password,false,$expire)){
    $status=1;
    }

    if($status==1){
    $response->throwJson(array('status'=>1,'msg'=> '登录成功！'));
}else{
    $response->throwJson(array('status'=>0,'msg'=> '登录失败！'));
    }


 }
   if($archive->request->get('api')=='logout'){
       $user->logout();
       $options->response->redirect($options->siteUrl);
       exit;
   }
       
//修改资料
if($archive->request->get('api')=='ziliao'){

    if($archive->request->get('authorid')!=$user->uid){
        $response->throwJson(array('status'=>0,'msg'=> '非法请求'));
    }

    $validator = new Typecho_Validate();
    $validator->addRule('screenName','xssCheck', _t('请不要在昵称中使用特殊字符'));

    $validator->addRule('mail','required', _t('必须填写电子邮箱'));
    $validator->addRule('mail','email', _t('电子邮箱格式错误'));
    //$validator->addRule('tel','required', _t('必须填写手机号'));
    //$validator->addRule('tel','isInteger', _t('手机号格式错误'));
    //$validator->addRule('tel','minLength', _t('手机号码要11位哦'), 11);

    
    $uinfo['screenName']=$request->get('screenName');
    $uinfo['mail']=$request->get('mail');
    //$uinfo['tel']=$request->get('tel');
    $uinfo['url']=$request->get('url');
    if ($error = $validator->run($uinfo)) {
        $response->throwJson(array('status'=>0,'msg'=> implode(';',$error)));
    }

    $db->query($db->update('table.users')->rows(
        array(
            'screenName' => $uinfo['screenName'],
            'mail' => $uinfo['mail'],
            'url' => $uinfo['url'],
        ))->where('uid = ?', $user->uid));


    $response->throwJson(array('status'=>1,'msg'=> '修改完成'));
 } 
 //修改密码  
 if($archive->request->get('api')=='mima'){

    if($archive->request->get('authorid')!=$user->uid){
        $response->throwJson(array('status'=>0,'msg'=> '非法请求'));
    }

  $validator = new Typecho_Validate();
  $validator->addRule('password','minLength', _t('为了保证账户安全, 请输入至少六位的密码'), 6);
  $validator->addRule('password','required', _t('必须填写密码'));
  $validator->addRule('confirm','confirm', _t('两次输入的密码不一致'), 'password');

  
  $uinfo['password']=$request->get('password');
  $uinfo['confirm']=$request->get('confirm');

  if ($error = $validator->run($uinfo)) {
      $response->throwJson(array('status'=>0,'msg'=> implode(';',$error)));
  }
  $hasher = new PasswordHash(8, true);
  $uinfo['password'] = $hasher->hashPassword(  $uinfo['password']);
  $db->query($db->update('table.users')->rows(
      array(
          'password' => $uinfo['password'],
      ))->where('uid = ?', $user->uid));


          $response->throwJson(array('status'=>1,'msg'=> '修改完成'));
} 
   


  if($archive->request->get('api')=='comment'){
    $archive->need('comments.php');
    exit;
 }

 if($archive->request->isPost() && $archive->request->get('likeup') && $archive->request->get('do_action')){
    likeup($archive->request->get('likeup'),$archive->request->get('do_action'));
    exit;
    }
// 为文章或页面、post操作，且包含参数`themeAction=comment`(自定义)
if($archive->is('single') && $archive->request->isPost() && $archive->request->is('themeAction=comment')){
    ajaxComment($archive);
    }

if($archive->is('single')){


if($archive->fields->mp4){
    $tv="{video title=\"剧集\"}".$archive->fields->mp4."{/video}";
    $archive->content=$tv.$archive->content;
}

}

}

//邮箱隐私保护
function maskEmail($email) {
    $parts = explode('@', $email);
    $masked = str_replace(substr($parts[0], 1), str_repeat('*', strlen($parts[0]) - 1), $parts[0]);
    return $masked . '@' . $parts[1];
}

function makeUploadDir(string $path): bool
    {
        $path = preg_replace("/\\\+/", '/', $path);
        $current = rtrim($path, '/');
        $last = $current;

        while (!is_dir($current) && false !== strpos($path, '/')) {
            $last = $current;
            $current = dirname($current);
        }

        if ($last == $current) {
            return true;
        }

        if (!@mkdir($last, 0755)) {
            return false;
        }

        return makeUploadDir($path);
    }
function upload($name,$path){
    \Widget\Options::alloc()->to($options);
    $response = $options->response;
            //创建上传目录
            if (!is_dir($path)) {
                if (!makeUploadDir($path)) {
                    echo 'false';exit;
                }
            }

    $target_file = $path . basename($_FILES["image"]["name"]);
    $save_file = $path.$name;
    $uploadOk = 1;
    $tip = '上传成功！';
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    // 检查文件是否为真实图片
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    $mimeMap = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/gif'  => 'gif',
        'image/webp' => 'webp',
        'image/bmp'  => 'bmp'
    ];
    $imageFileType = $mimeMap[$check['mime']] ?? 'jpg';
        if($check === false) {
            $tip =  "文件不是一个图片.";
            $uploadOk = 0;
        }

    // 检查文件是否已存在，不用检测直接覆盖即可
    //if (file_exists($target_file)) {
    //    echo "文件名已存在.";
    //    $uploadOk = 0;
    //}

    // 限制文件大小
    if ($_FILES["image"]["size"] > 5242880) {
        $tip =  "文件过大.请控制在5M以下";
        $uploadOk = 0;
    }

    // 限制文件类型
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" && $imageFileType != "webp" ) {
        $tip =  "只允许上传 JPG, JPEG, PNG, WEBP和 GIF 格式的图片.";
        $uploadOk = 0;
    }

    // 如果所有检查都通过，将文件从临时目录移动到目标目录
    if ($uploadOk != 0) {
   
        $ext=$imageFileType;

        if ($ext!='webp'){
           
            $save_file = $path.$name.'.webp';
            // 创建一个新的GD图像对象
            if($ext=='png'){
            $image = imagecreatefrompng($_FILES["image"]["tmp_name"]);
            }elseif($ext=='gif'){
            $image = imagecreatefromgif($_FILES["image"]["tmp_name"]);
            }
            else{
            $image = imagecreatefromjpeg($_FILES["image"]["tmp_name"]);
            }

            // 创建一个新的真彩色图像对象
            //$trueColorImage = imagecreatetruecolor(imagesx($image), imagesy($image));
            $w=imagesx($image);
            $h=imagesy($image);

            if($w>1920){
                $h=intval($h*1920/$w);
                $w=1920;
            }
            // 创建一个新的水印图片，并保留透明度
            $trueColorImage = imagecreatetruecolor($w, $h);
            imagesavealpha($trueColorImage, true); // 启用透明度保存
            $transparentColor = imagecolorallocatealpha($trueColorImage, 0, 0, 0, 127); // 分配一个透明的颜色
            imagefill($trueColorImage, 0, 0, $transparentColor); // 用透明颜色填充背景
                                    
            // 重新采样缩放水印图片
            imagecopyresampled($trueColorImage, $image, 0, 0, 0, 0,$w,$h, imagesx($image), imagesy($image));

            // 释放原始图像的内
            imagedestroy($image);
            // 将真彩色图像保存为WebP格
            if(imagewebp($trueColorImage, $save_file, 80)){ // 第三个参数是图像质量，可根据需要进行调整
            //echo "上传成功";
            } else {
            $tip =  "图片格式转换失败，可能是图片体积过大服务器内存不够，建议缩小图片体积再次尝试！";
            $uploadOk = 0;
            }
            // 释放真彩色图像的内
            imagedestroy($trueColorImage);
            // 释放内存
            imagedestroy($image);
            //echo "上传成功";
    }else{
        $save_file = $path.$name.'.jpg';
        if($ext=='webp'){
        $save_file = $path.$name.'.webp';
        }
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $save_file)) {
        //echo "上传成功";
    } else {
        $tip = "文件上传失败，可能是文件夹权限不够";
        $uploadOk = 0;
    }
}
}

if($uploadOk == 0){
$response->throwJson(array('status'=>0,'msg'=> $tip));
}else{
$response->throwJson(array('status'=>1,'msg'=> '上传成功'));
}


}

function getAuthor(){
    $db = Typecho_Db::get();
    $info=$db->fetchRow($db->select()->from('table.users')
                ->where('table.users.group = ?', 'administrator'));
    return $info;
    }
function reslug($mid){
    $db = Typecho_Db::get();
    $info=$db->fetchRow($db->select('slug')->from('table.metas')
                ->where('table.metas.mid = ?', $mid));
    if(empty($info['slug'])){
    return '';  
    }else{
    return $info['slug'];}
    }
function remid($slug){
        $db = Typecho_Db::get();
        $info=$db->fetchRow($db->select('mid')->from('table.metas')
                    ->where('table.metas.slug = ?', $slug));
        return $info['mid'];
    }
function cateicon($mid,$type){
    $name=md5($mid);
    if($type=='cate'){
        $type='category';
    }
    $path = \Typecho\Common::url(defined('__TYPECHO_UPLOAD_DIR__') ? __TYPECHO_UPLOAD_DIR__ : \Widget\Upload::UPLOAD_DIR,
    defined('__TYPECHO_UPLOAD_ROOT_DIR__') ? __TYPECHO_UPLOAD_ROOT_DIR__ : __TYPECHO_ROOT_DIR__) . '/'.$type.'/';
    


    if(defined('__TYPECHO_UPLOAD_DIR__')){$udir= __TYPECHO_UPLOAD_DIR__ ;}else{ $udir= \Widget\Upload::UPLOAD_DIR;}
    $file1=$path.$name.'.webp';
    $file2=$path.$name.'.jpg';
    if(file_exists($file1)){
        $img=Helper::options()->rootUrl.$udir."/".$type."/".$name.'.webp?'.filemtime($file1);
    }elseif(file_exists($file2)){
        $img=Helper::options()->rootUrl.$udir."/".$type."/".$name.'.jpg?'.filemtime($file2);
    }else{
        $img=theurl.'img/none.svg';
        if($type=='avatar'){
            $db = Typecho\Db::get();
            $mail = $db->fetchRow($db->select()->from('table.users')->where('table.users.uid=?', $mid))['mail'];
            $img=tx($mail,'blank');
        }
    }
    return $img;
}
/**
 * ajaxComment
 * 实现Ajax评论的方法(实现feedback中的comment功能)
 * @param Widget_Archive $archive
 * @return void
 */
function ajaxComment($archive){
    $options = Helper::options();
    $user = \Typecho\Widget::widget('\Widget\User');
    $db = Typecho_Db::get();
    // Security 验证不通过时会直接跳转，所以需要自己进行判断
    // 需要开启反垃圾保护，此时将不验证来源
//if($archive->request->get('_') != Helper::security()->getToken($archive->request->getReferer())){
//   $archive->response->throwJson(array('status'=>0,'msg'=>_t('请求出现问题，请刷新重试！')));
//}
    /** 评论关闭 */
    if(!$archive->allow('comment')){
        $archive->response->throwJson(array('status'=>0,'msg'=>_t('评论已关闭')));
    }

    /** 检查ip评论间隔 */
    if (!$user->pass('editor', true) && $archive->authorId != $user->uid &&
    $options->commentsPostIntervalEnable){
        $latestComment = $db->fetchRow($db->select('created')->from('table.comments')
                    ->where('cid = ?', $archive->cid)
                    ->where('ip = ?', $archive->request->getIp())
                    ->order('created', Typecho_Db::SORT_DESC)
                    ->limit(1));

        if ($latestComment && ($options->gmtTime - $latestComment['created'] > 0 &&
        $options->gmtTime - $latestComment['created'] < $options->commentsPostInterval)) {
            $archive->response->throwJson(array('status'=>0,'msg'=>_t('对不起, 您的发言过于频繁, 请稍侯再次发布')));
        }        
    }

$getAgent=$archive->request->getAgent();
if(isset($_COOKIE['win11'])){
$getAgent=str_replace("Windows NT 10.0","Windows NT 11.0",$archive->request->getAgent());
}

    $comment = array(
        'cid'       =>  $archive->cid,
        'created'   =>  $options->gmtTime,
        'agent'     =>  $getAgent,
        'ip'        =>  $archive->request->getIp(),
        'ownerId'   =>  $archive->author->uid,
        'type'      =>  'comment',
        'status'    =>  !$archive->allow('edit') && $options->commentsRequireModeration ? 'waiting' : 'approved'
    );

    /** 判断父节点 */
    if ($parentId = $archive->request->filter('int')->get('parent')) {
        if ($options->commentsThreaded && ($parent = $db->fetchRow($db->select('coid', 'cid')->from('table.comments')
        ->where('coid = ?', $parentId))) && $archive->cid == $parent['cid']) {
            $comment['parent'] = $parentId;
        } else {
            $archive->response->throwJson(array('status'=>0,'msg'=>_t('父级评论不存在')));
        }
    }
    $feedback = \Typecho\Widget::widget('\Widget\Feedback');
    //检验格式
    $validator = new Typecho_Validate();
    $validator->addRule('author', 'required', _t('必须填写用户名'));
    $validator->addRule('author', 'xssCheck', _t('请不要在用户名中使用特殊字符'));
    $validator->addRule('author', array($feedback, 'requireUserLogin'), _t('您所使用的用户名已经被注册,请登录或更换昵称再次提交'));
    $validator->addRule('author', 'maxLength', _t('用户名最多包含200个字符'), 200);

    if ($options->commentsRequireMail && !$user->hasLogin()) {
        $validator->addRule('mail', 'required', _t('必须填写电子邮箱地址'));
    }

    $validator->addRule('mail', 'email', _t('邮箱地址不合法'));
    $validator->addRule('mail', 'maxLength', _t('电子邮箱最多包含200个字符'), 200);

    if ($options->commentsRequireUrl && !$user->hasLogin()) {
        $validator->addRule('url', 'required', _t('必须填写个人主页'));
    }
    $validator->addRule('url', 'url', _t('个人主页地址格式错误'));
    $validator->addRule('url', 'maxLength', _t('个人主页地址最多包含200个字符'), 200);

    $validator->addRule('text', 'required', _t('必须填写评论内容'));
    
    
    if(strpos($archive->request->text,'script>')!==false){
       $archive->response->throwJson(array('status'=>0,'msg'=>_t('请不要输入js相关代码！'))); 
    }
    
    
    $comment['text'] = $archive->request->text;


    if(!$user->hasLogin()&&!empty($options->tools)&&in_array('loginpl', $options->tools)){
        $archive->response->throwJson(array('status'=>0,'msg'=>_t('禁止游客评论，请登录后进行评论')));
    }


if (!empty(Helper::options()->tools) && in_array('spam', Helper::options()->tools)&&!$user->hasLogin()){
if($archive->request->sum){
if($archive->request->sum!=($archive->request->num1+$archive->request->num2)){
 $archive->response->throwJson(array('status'=>0,'msg'=>_t('验证码输入错误，请您重新输入！')));
}
}else{
 $archive->response->throwJson(array('status'=>0,'msg'=>_t('检测到您没有输入验证码，请您输入验证码！')));
}
}



    /** 对一般匿名访问者,将用户数据保存一个月 */
    if (!$user->hasLogin()) {
        /** Anti-XSS */
        $comment['author'] = $archive->request->filter('trim')->author;
        $comment['mail'] = $archive->request->filter('trim')->mail;
        $comment['url'] = $archive->request->filter('trim', 'url')->url;

        /** 修正用户提交的url */
        if (!empty($comment['url'])) {
            $urlParams = parse_url($comment['url']);
            if (!isset($urlParams['scheme'])) {
                $comment['url'] = 'http://' . $comment['url'];
            }
        }

        $expire = $options->gmtTime + $options->timezone + 30*24*3600;
        Typecho_Cookie::set('__typecho_remember_author', $comment['author'], $expire);
        Typecho_Cookie::set('__typecho_remember_mail', $comment['mail'], $expire);
        Typecho_Cookie::set('__typecho_remember_url', $comment['url'], $expire);
    } else {
        $comment['author'] = $user->screenName;
        $comment['mail'] = $user->mail;
        $comment['url'] = $user->url;

        /** 记录登录用户的id */
        $comment['authorId'] = $user->uid;
    }



    /** 评论者之前须有评论通过了审核 */
    if (!$options->commentsRequireModeration && $options->commentsWhitelist) {
        if ($feedback->size($feedback->select()->where('author = ? AND mail = ? AND status = ?', $comment['author'], $comment['mail'], 'approved'))) {
            $comment['status'] = 'approved';
        } else {
            $comment['status'] = 'waiting';
        }
    }

    if ($error = $validator->run($comment)) {
        $archive->response->throwJson(array('status'=>0,'msg'=> implode(';',$error)));
    }


if($archive->hidden){
        $archive->response->throwJson(array('status'=>0,'msg'=>_t('加密文章！输入正确密码后方可进行评论！')));
}

/** 生成过滤器 */
try {
     $comment = $feedback->pluginHandle()->comment($comment, $feedback->_content);
} catch (Typecho_Exception $e) {
     Typecho_Cookie::set('__typecho_remember_text', $comment['text']);
     $archive->response->throwJson(array('status'=>0,'msg'=>_t($e->getMessage())));
     throw $e;
}


 $status="";
if ('waiting' == $comment['status']){ $status='您的评论需管理员审核后才能显示！';} 

$sf="";$shenfen=0;
if($user->uid>0){if($user->uid == $archive->authorId){$sf='<svg class="text-sky-500 size-5 ml-0.5" aria-hidden="true"><use xlink:href="#certificate_fill"></use></svg>';$shenfen=1;}}

 
    /** 添加评论 */
    $commentId = $feedback->insert($comment);

    Typecho_Cookie::delete('__typecho_remember_text');
    $db->fetchRow($feedback->select()->where('coid = ?', $commentId)
    ->limit(1), array($feedback, 'push'));

$feedback->text=parseBiaoQing($feedback->text);//尝试让表情进入邮件

$feedback->pluginHandle()->finishComment($feedback);

    // 返回评论数据
    $data = array(
        'cid' => $feedback->cid,
        'coid' => $feedback->coid,
        'parent' => $feedback->parent,
        'mail' => $feedback->mail,
        'url' => $feedback->url,
        'ip' => $feedback->ip,
        'agent' => $feedback->agent,
        'author' => $feedback->author,
        'authorId' => $feedback->authorId,
        'permalink' => $feedback->permalink,
        'created' => timesince($feedback->created),
        'datetime' => $feedback->date->format('Y-m-d H:i:s'),
        'content'=> $feedback->content,
        'status' => $status,
        'sf' => $sf,
    );
    $data['avatar'] = tx($data['mail'],'blank',$data['authorId']);
    $data['tx'] = letter_avatarx($feedback->author);
    $archive->response->throwJson(array('status'=>1,'comment'=>$data));
}


function spam_protection_math(){
    $num1=rand(1,38);
    $num2=rand(1,38);
    echo "<div>";
    echo "<input type=\"text\" name=\"sum\" class=\"w-full rounded py-1.5 px-1 text-sm comment-form-body text-gray-900 border-gray-100 bg-slate-100 dark:bg-gray-700 dark:text-gray-100\" value=\"\" size=\"25\" tabindex=\"4\" placeholder=\"$num1+$num2=？\" required>\n";
    echo "<input type=\"hidden\" name=\"num1\" value=\"$num1\">\n";
    echo "<input type=\"hidden\" name=\"num2\" value=\"$num2\"></div>";
}

function getCNWeek($date){
    $weekarray=array("日","一","二","三","四","五","六");
    return "星期".$weekarray[date("w",$date)];
}
function timesince($time,$type = false) {
    if (!empty(Helper::options()->tools) && in_array('dateformat', Helper::options()->tools)){
    return date('Y年m月d日' , $time);
    }else{
    $text = '';
        $time = $time === NULL || $time > time() ? time() : intval($time);
        $t = time() - $time; //时间差 （秒）
        $y = date('Y', $time)-date('Y', time());//是否跨年
        if($type=="day"){
        switch($t){
         case $t == 0:
           $text = '刚刚';
           break;
         case $t < 60:
          $text = $t . '秒前'; // 一分钟内
          break;
         case $t < 60 * 60:
          $text = floor($t / 60) . '分钟前'; //一小时内
          break;
         case $t < 60 * 60 * 24:
          $text = floor($t / (60 * 60)) . '小时前'; // 一天内
          break;
         case $t < 60 * 60 * 24 * 3:
          $text = floor($time/(60*60*24)) ==1 ?'昨天 ' : '前天 '; //昨天和前天
          break;
         default:
          $text = floor($t/(60*60*24)).'天前'; //一个月内
          break;
        }
        }else{
        switch($t){
         case $t == 0:
           $text = '刚刚';
           break;
         case $t < 60:
          $text = $t . '秒前'; // 一分钟内
          break;
         case $t < 60 * 60:
          $text = floor($t / 60) . '分钟前'; //一小时内
          break;
         case $t < 60 * 60 * 24:
          $text = floor($t / (60 * 60)) . '小时前'; // 一天内
          break;
         case $t < 60 * 60 * 24 * 3:
          $text = floor($time/(60*60*24)) ==1 ?'昨天 ' : '前天 '; //昨天和前天
          break;
         case $t < 60 * 60 * 24 * 30:
          $text = floor($t/(60*60*24)).'天前'; //一个月内
          break;
         case $t < 60 * 60 * 24 * 365&&$y==0:
          $text = date('m月d日', $time); //一年内
          break;
         default:
          $text = date('Y年m月d日', $time); //一年以前
          break;
        }
    }
    return $text;}
    }
    
//评论@函数
function get_comment_at($coid)
{
    $db   = Typecho_Db::get();
    $prow = $db->fetchRow($db->select('parent')->from('table.comments')
                                 ->where('coid = ?', $coid));
    $parent = $prow['parent'];
    if (!empty($parent)) {
        $arow = $db->fetchRow($db->select('author')->from('table.comments')
                                     ->where('coid = ? AND status = ?', $parent, 'approved'));
if(!empty($arow['author'])){ $author = $arow['author'];
        $href   = '<a href="#comment-' . $parent . '">@' . $author . '</a> ';
        return $href;
}else { return '';}
    } else {
        return '';
    }
}
    function parsePaopaoBiaoqingCallback($match)
    {
        return '<img class="biaoqing" no-view src="'.theurl.'/assets/owo/paopao/'. str_replace('%', '', urlencode($match[1])) . '_2x.webp">';
    }
function parseAruBiaoqingCallback($match)
    {
        return '<img class="biaoqing" no-view src="'.theurl.'/assets/owo/aru/'. str_replace('%', '', urlencode($match[1])) . '_2x.webp">';
    }
function parseBiaoqingCallback($match)
    {
        if(file_exists(__TYPECHO_ROOT_DIR__.'/Plain/biaoqing/'.$match[1]. '.png'))

{
        return '<img class="biaoqing" no-view alt="'.$match[1].'" src="'.rooturl.'Plain/biaoqing/'. urlencode($match[1]) . '.png">';
}else{
 return ':('.$match[1].')';   
}
    }
function parseBiaoQing($content)
    {
        $content = preg_replace_callback('/\:\:\(\s*(呵呵|哈哈|吐舌|太开心|笑眼|花心|小乖|乖|捂嘴笑|滑稽|你懂的|不高兴|怒|汗|黑线|泪|真棒|喷|惊哭|阴险|鄙视|酷|啊|狂汗|what|疑问|酸爽|呀咩爹|委屈|惊讶|睡觉|笑尿|挖鼻|吐|犀利|小红脸|懒得理|勉强|爱心|心碎|玫瑰|礼物|彩虹|太阳|星星月亮|钱币|茶杯|蛋糕|大拇指|胜利|haha|OK|沙发|手纸|香蕉|便便|药丸|红领巾|蜡烛|音乐|灯泡|开心|钱|咦|呼|冷|生气|弱|吐血|狗头)\s*\)/is',
'parsePaopaoBiaoqingCallback', $content);
        $content = preg_replace_callback('/\:\@\(\s*(高兴|小怒|脸红|内伤|装大款|赞一个|害羞|汗|吐血倒地|深思|不高兴|无语|亲亲|口水|尴尬|中指|想一想|哭泣|便便|献花|皱眉|傻笑|狂汗|吐|喷水|看不见|鼓掌|阴暗|长草|献黄瓜|邪恶|期待|得意|吐舌|喷血|无所谓|观察|暗地观察|肿包|中枪|大囧|呲牙|抠鼻|不说话|咽气|欢呼|锁眉|蜡烛|坐等|击掌|惊喜|喜极而泣|抽烟|不出所料|愤怒|无奈|黑线|投降|看热闹|扇耳光|小眼睛|中刀)\s*\)/is',
'parseAruBiaoqingCallback', $content);
        $content = preg_replace_callback('/\:\((.*?)\)/','parseBiaoqingCallback', $content);
        return $content;
    }
        
/**
 * 首字母头像
 * @param $text
 * @return string
 */
function letter_avatarx($text)
{
    $total = unpack('L', hash('adler32', $text, true))[1];
    $hue = $total % 360;
    list($r, $g, $b) = hsv2rgbx($hue / 360, 0.3, 0.9);
    $bg = "rgb({$r},{$g},{$b})";
    $color = "#ffffff";
    $first = mb_strtoupper(mb_substr($text, 0, 1));
    $src = base64_encode('<svg xmlns="http://www.w3.org/2000/svg" version="1.1" height="100" width="100"><rect fill="' . $bg . '" x="0" y="0" width="100" height="100"></rect><text x="50" y="50" font-size="50" text-copy="fast" fill="' . $color . '" text-anchor="middle" text-rights="admin" alignment-baseline="central">' . $first . '</text></svg>');
    return 'data:image/svg+xml;base64,' . $src;
}
function hsv2rgbx($h, $s, $v)
{
    $r = $g = $b = 0;
    $i = floor($h * 6);
    $f = $h * 6 - $i;
    $p = $v * (1 - $s);
    $q = $v * (1 - $f * $s);
    $t = $v * (1 - (1 - $f) * $s);
    switch ($i % 6) {
        case 0:
            $r = $v;
            $g = $t;
            $b = $p;
            break;
        case 1:
            $r = $q;
            $g = $v;
            $b = $p;
            break;
        case 2:
            $r = $p;
            $g = $v;
            $b = $t;
            break;
        case 3:
            $r = $p;
            $g = $q;
            $b = $v;
            break;
        case 4:
            $r = $t;
            $g = $p;
            $b = $v;
            break;
        case 5:
            $r = $v;
            $g = $p;
            $b = $q;
            break;
    }
    return [
        floor($r * 255),
        floor($g * 255),
        floor($b * 255)
    ];
}  

//归档函数
function archives($widget, $excerpt = false) {
    $db = Typecho_Db::get();
    $rows = $db->fetchAll($db->select()
                        ->from('table.contents')
                        ->order('table.contents.created', Typecho_Db::SORT_DESC)
                        ->where('table.contents.type = ?', 'post')
                        ->where('table.contents.status = ?', 'publish')
                        ->where('table.contents.created < ?', time()));
    $stat = array();
    foreach ($rows as $row) {
        $row = $widget->filter($row);
        $arr = array(
                        'title' => $row['title'],
                        'permalink' => $row['permalink'],
                        'commentsNum' => $row['commentsNum'],
                        'views' => $row['views'],
                    );
        if($excerpt) {
            $arr['excerpt'] = substr($row['content'], 30);
        }
        $stat[date('Y', $row['created'])][$row['created']] = $arr;
    }
    return $stat;
}

function subtitle($obj,$txt=""){
if ($obj->fields->subtitle){echo $obj->fields->subtitle.$txt;}
}

function icon($obj,$type=0){
    $random = theurl.'img/none.svg';
    $icon=showThumbnail($obj,1);
    if($type==1){if($icon==$random){return false;}else{return true;}}else{
        echo $icon;
    }
}


//文章缩略图函数
function showThumbnail($widget,$type=0)
{ 
    $random = theurl.'img/none.svg';//这里时默认缩略图
    $pattern = '/\<img.*?\ssrc\=\"(.*?)\"[^>]*>/i';
    $attach = $widget->widget('Widget_Contents_Attachment_Related@' . $widget->cid . '-' . uniqid(), array(
            'parentId'  => $widget->cid,'limit'     => 1,'offset'    => 0))->attachment;
    $t=@preg_match_all($pattern, $widget->markdown($widget->text), $thumbUrl);
   $img=$random;
    

   $name = md5($widget->cid);
   $file1 = ".".__TYPECHO_PLUGIN_DIR__."/Thumb/uploads/".$name.'.webp';
   $file2 = ".".__TYPECHO_PLUGIN_DIR__."/Thumb/uploads/".$name.'.jpg';
   if(file_exists($file1)){
        $img=Helper::options()->rootUrl.__TYPECHO_PLUGIN_DIR__."/Thumb/uploads/".$name.'.webp?'.filemtime($file1);
    }
   elseif(file_exists($file2)){
        $img=Helper::options()->rootUrl.__TYPECHO_PLUGIN_DIR__."/Thumb/uploads/".$name.'.jpg?'.filemtime($file2);
    }
    
    
elseif($widget->fields->img){$img=$widget->fields->img;}

elseif($widget->fields->thumb){$img=$widget->fields->thumb;}//自定义字段设置封面
    
elseif ($t && strpos($thumbUrl[1][0],'icon.png') == false && strpos($thumbUrl[1][0],'alipay') == false && strpos($thumbUrl[1][0],'wechat') == false) {$img = $thumbUrl[1][0];}//从文章中获取封面
  elseif (@$attach->isImage) {$img=$attach->url;}//从附件中获取封面

  if($type==0){
  if($img==$random){echo $img;}else{echo $img.Helper::options()->thumbnail;}//输出封面图
  }else{
   if($img==$random){return $img;}else{return $img.Helper::options()->thumbnail;}//输出封面图     
  }
  
}

//头像源
function tx($mail,$type="mm",$uid=0){
    if($uid>0){
        $name = md5($uid);
        $path = \Typecho\Common::url(defined('__TYPECHO_UPLOAD_DIR__') ? __TYPECHO_UPLOAD_DIR__ : \Widget\Upload::UPLOAD_DIR,
        defined('__TYPECHO_UPLOAD_ROOT_DIR__') ? __TYPECHO_UPLOAD_ROOT_DIR__ : __TYPECHO_ROOT_DIR__) . '/avatar/';
    
        if(defined('__TYPECHO_UPLOAD_DIR__')){$udir= __TYPECHO_UPLOAD_DIR__ ;}else{ $udir= \Widget\Upload::UPLOAD_DIR;}
        $file1=$path.$name.'.webp';
        $file2=$path.$name.'.jpg';
        if(file_exists($file1)){
            $img=Helper::options()->rootUrl.$udir."/avatar/".$name.'.webp?'.filemtime($file1);
            return $img;
        }elseif(file_exists($file2)){
            $img=Helper::options()->rootUrl.$udir."/avatar/".$name.'.jpg?'.filemtime($file2);
            return $img;
        }else{
            tx($mail,$type);
        }
    }

    if (defined('__TYPECHO_GRAVATAR_PREFIX__')) {
        $url = __TYPECHO_GRAVATAR_PREFIX__;} 
        elseif(Helper::options()->gravatars) {
        $url= Helper::options()->gravatars;
        }else{
        $url = 'https://cravatar.cn/avatar/';
        }
    return $url.md5($mail).'?s=80&d='.$type;
}

//自定义缩略内容
function excerpt($obj,int $length = 100, string $trim = '...',$type='echo')
    {
    if ($obj->fields->subtitle){
    if($type=='echo'){
        echo $obj->fields->subtitle;
    }else{return $obj->fields->subtitle;}
    }else{
    $text=$obj->excerpt;
    $text=preg_replace('#\{video(.*?)?}(.*?){\/video}#', '', $text);
    $text=preg_replace('#\{login}(.*?){\/login}#', '', $text);
    $text=preg_replace('#\{(.*?)\}#', '', $text);
    $text=preg_replace('#　#', '', $text);

    if($type=='echo'){
    echo Typecho_Common::subStr(strip_tags($text), 0, $length, $trim);
    }else{
    return Typecho_Common::subStr(strip_tags($text), 0, $length, $trim);
    }
    }
}
//文章阅读数
function get_post_view($archive,$r=0)
{
    $cid    = $archive->cid;
    $db     = Typecho_Db::get();
    $prefix = $db->getPrefix();
    $type = explode('_', $db->getAdapterName());
    $type = strtolower(array_pop($type));

    if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')->page(1,1)))) {

        if($type == 'pgsql' || $type == 'sqlite'){
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD COLUMN `views` INTEGER DEFAULT 0;');
        }
        else{
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT(10) DEFAULT 0;');
        }
    }
    $row = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid));
    if ($archive->is('single')) {
        $views = Typecho_Cookie::get('extend_contents_views');
        if(empty($views)){
            $views = array();
        }else{
            $views = explode(',', $views);
        }
        
        if(!in_array($cid,$views)||$row['views']<1000){//小于1000阅读数时，不进行去重验证以免阅读数过于寒蝉(丢人)
       $db->query($db->update('table.contents')->rows(array('views' => (int) $row['views'] + 1))->where('cid = ?', $cid));

       array_push($views, $cid);
       $views = implode(',', $views);
       $time = time() + 120;//只设置120秒后可以再加一次
       Typecho_Cookie::set('extend_contents_views', $views,$time); //记录查看cookie

        }
    }
if($r==0){
    echo $row['views'];
}else{
    return $row['views'];
}
}


function likeup($ccid,$kg='') {
    $cid = $ccid;
    $db = Typecho_Db::get();
    $prefix = $db->getPrefix();
    $type = explode('_', $db->getAdapterName());
    $type = strtolower(array_pop($type));
    if (!array_key_exists('likes', $db->fetchRow($db->select()->from('table.contents')->page(1,1)))) {
        if($type == 'pgsql' || $type == 'sqlite'){
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD COLUMN `likes` INTEGER DEFAULT 0;');
        }
        else{
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `likes` INT(10) DEFAULT 0;');
        }


    }
 $row = $db->fetchRow($db->select('likes')->from('table.contents')->where('cid = ?', $cid));
$num=$row['likes'];


if (!session_id()){session_start();}

if($kg=="do"){

if(isset($_SESSION['likes-'.$cid])){echo $num;exit;}$_SESSION['likes-'.$cid]=$num+1;
unset($_SESSION['likesx-'.$cid]);

 $db->query($db->update('table.contents')->rows(array('likes' => (int)$row['likes']+1))->where('cid = ?', $cid));
$num=$num+1;
}
if($kg=="undo"){

if(isset($_SESSION['likesx-'.$cid])){
    if($num>=1000){$num='999+';}else{$num=$num;}
    echo $num;exit;}$_SESSION['likesx-'.$cid]=$num-1;unset($_SESSION['likes-'.$cid]);


$db->query($db->update('table.contents')->rows(array('likes' => (int)$row['likes']-1))->where('cid = ?', $cid));
$num=$num-1;

}

if($num<0){
$db->query($db->update('table.contents')->rows(array('likes' => '1'))->where('cid = ?', $cid));
}//防止恶意请求导致点赞数为负值

if($num>1000){
$db->query($db->update('table.contents')->rows(array('likes' => '1000'))->where('cid = ?', $cid));
}
if($num>=1000){
$num='999+';
}else{
$num=$num;
}

if($kg=="return"){
  return $num;  
}else{
  echo $num;
}
}


function linkpage() {
    $db = Typecho_Db::get();
    $result = $db->fetchRow($db->select()->from('table.contents')->where('type=?', 'page')->where('status=?', 'publish')->where('template=?', 'link.php')->limit(1));
    if($result) {
        $f=Helper::widgetById('Contents',$result['cid']);
        $permalink = $f->permalink;
        return $permalink;
    } else {
        return false;
    }
}

//下一篇
function theNext($widget)
{
$t = \Typecho\Widget::widget('Widget_Archive@next');//@的作用我之前也有讲过，就是用来区分的，这里的$t就是定义的$this
$db = Typecho_Db::get();
$sql = $db->select()->from('table.contents')
->where('table.contents.created > ? AND table.contents.created < ?',
            $widget->created, time())
->where('table.contents.status = ?', 'publish')
->where('table.contents.type = ?', $widget->type)
//->where("table.contents.password IS NULL OR table.contents.password = ''")
->order('table.contents.created', Typecho_Db::SORT_ASC)
->limit(1);//sql查询下一篇文章
$db->fetchAll($sql, array($t, 'push'));//这个代码就是如何将查询结果封到$this里的
return $t;//返回变量
}
//上一篇 
function thePrev($widget)
{
$t = \Typecho\Widget::widget('Widget_Archive@prev');//@的作用我之前也有讲过，就是用来区分的，@后面参数随便只要和上边的不一样就行
$db = Typecho_Db::get();
$sql = $db->select()->from('table.contents')
->where('table.contents.created < ?', $widget->created)
->where('table.contents.status = ?', 'publish')
->where('table.contents.type = ?', $widget->type)
//->where("table.contents.password IS NULL OR table.contents.password = ''")
->order('table.contents.created', Typecho_Db::SORT_DESC)
->limit(1);//sql查询上一篇文章
$db->fetchAll($sql, array($t, 'push'));
return $t;//返回变量
}

//随便看看
function randomPost($t='echo') {
	$db = Typecho_Db::get();
    $type = explode('_', $db->getAdapterName());//兼容非MySQL数据库
    $type = strtolower(array_pop($type));
    if($type == 'pgsql' || $type == 'sqlite'){
        $order_by = 'RANDOM()';
    }else{
        $order_by = 'RAND()';
    } 
	$result = $db->fetchRow($db->select()->from('table.contents')->where('type=?', 'post')->where('status=?', 'publish')->limit(1)->order($order_by));
	if($result) {
	    $f=Helper::widgetById('Contents',$result['cid']);
		$permalink = $f->permalink;
		if($t=="return"){return $permalink;}else{echo $permalink;}
	} else {
		echo "没有文章可随机";
	}
}
//判断无刷新加载
function is_ajax()
{
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
        if ('xmlhttprequest' == strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])||'instantclick' == strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])) {
            return true;
        }
    }
    return false;
}
//随机文章
class Widget_Post_tongleisuiji extends Widget_Abstract_Contents
{
    public function execute()
    {
    $type = explode('_', $this->db->getAdapterName());//兼容非MySQL数据库
    $type = strtolower(array_pop($type));
    if($type == 'pgsql' || $type == 'sqlite'){
        $order_by = 'RANDOM()';
    }else{
        $order_by = 'RAND()';
    }   
$select  = $this->select()->from('table.contents');

if($this->parameter->mid>0){
$select->join('table.relationships', 'table.contents.cid = table.relationships.cid');
}

$select->where('table.contents.cid <> ?', $this->parameter->cid)
->where("table.contents.password IS NULL OR table.contents.password = ''")
->where('table.contents.status = ?','publish')
->where('table.contents.type = ?', 'post');

if($this->parameter->mid>0){
    $select->where('table.relationships.mid = ?', $this->parameter->mid)->group('cid');
    }
$select->limit($this->parameter->pageSize)
->order($order_by);


$this->db->fetchAll($select, [$this, 'push']);
    }
}

//热评文章
class Widget_Post_Hot extends Widget_Abstract_Contents
{
    public function __construct($request, $response, $params = NULL)
    {
        parent::__construct($request, $response, $params);
        $this->parameter->setDefault(array('pageSize' => $this->options->commentsListSize,));
    }
    public function execute()
    {
        $select  = $this->select()->from('table.contents')
->where("table.contents.password IS NULL OR table.contents.password = ''")
->where('table.contents.status = ?','publish')
->where('table.contents.created <= ?', time())
->where('table.contents.type = ?', 'post')
->limit($this->parameter->pageSize)
->order('table.contents.commentsNum', Typecho_Db::SORT_DESC);
$this->db->fetchAll($select, [$this, 'push']);
    }
}

//热门文章
class Widget_View_Hot extends Widget_Abstract_Contents
{
    public function __construct($request, $response, $params = NULL)
    {
        parent::__construct($request, $response, $params);
        $this->parameter->setDefault(array('pageSize' => $this->options->commentsListSize,));
    }
    public function execute()
    {
        $select  = $this->select()->from('table.contents')
->where("table.contents.password IS NULL OR table.contents.password = ''")
->where('table.contents.status = ?','publish')
->where('table.contents.created <= ?', time())
->where('table.contents.type = ?', 'post')
->limit($this->parameter->pageSize)
->order('table.contents.views', Typecho_Db::SORT_DESC);
$this->db->fetchAll($select, [$this, 'push']);
    }
}

class Widget_Cat extends Widget_Abstract_Metas
{
    public function __construct($request, $response, $params = NULL)
    {
        parent::__construct($request, $response, $params);
        $this->parameter->setDefault(array('pageSize' => $this->options->commentsListSize, 'parentId' => 0, 'ignoreAuthor' => false));
    }
    public function execute()
    {
$po  = $this->select()->from('table.metas')
->where('table.metas.slug = ?',$this->parameter->slug)
->where('table.metas.type = ?','category')
->order('table.metas.order', Typecho_Db::SORT_DESC);
$po = $this->db->fetchRow($po);

$select  = $this->select()->from('table.metas')
->where('table.metas.parent = ?',$po['mid'])
->where('table.metas.type = ?','category')
->order('table.metas.order', Typecho_Db::SORT_ASC);

$this->db->fetchAll($select, [$this, 'push']);
    }
}

\Typecho\Plugin::factory('Widget_Abstract_Contents')->excerptEx = array('ze','one');
\Typecho\Plugin::factory('Widget_Abstract_Contents')->contentEx = array('ze','one');
class ze {
        public static function one($con,$obj,$text)
    {
      $text = empty($text)?$con:$text;
      if(!$obj->is('single')){
      $text=preg_replace('#\{login\}(.*?)\{\/login\}#', '(抱歉，隐藏内容登陆后可见)', $text);
      $text=preg_replace('#\{hide\}(.*?)\{\/hide\}#', '(抱歉，隐藏内容评论后可见)', $text); 
      $text=preg_replace('#(<p>)?\{file(.*)\}(.*?)\{\/file\}(<\/p>)?#', '', $text);
      $text=preg_replace('#(<p>)?\{center\}(.*?)\{\/center\}(<\/p>)?#', '<center class="mb-3">$2</center>', $text); 
      $text=preg_replace('#(\{grid(.*?)?\})#', '', $text);
      $text=preg_replace('#(\{\/grid\})#', '', $text);
      $text=preg_replace('#(\{card\})#', '', $text);
      $text=preg_replace('#(\{\/card\})#', '', $text);
      $text= preg_replace('#\{div(.*?)\}#', '<div$1>', $text);
      $text= preg_replace('#\{\/div\}#', '</div>', $text);
      $text= preg_replace('#\{br\}#', '<br>', $text);
      }
               return $text;
    }
}