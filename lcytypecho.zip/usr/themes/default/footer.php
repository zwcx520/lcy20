<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$activated=Typecho_Plugin::export()['activated'];
?>




<?php if(!$this->is('search')&&$this->options->ad1): ?>
<div class="w-full break-all my-4 mx-auto">
<div class="flex overflow-hidden">
<div class="flex-1 shadow rounded overflow-hidden">
<?php $this->options->ad1(); ?>
</div>  
</div></div>
<?php endif;?>


</div>
</div>
<?php
if($this->is('post')||$this->is('page')){
    if (strpos($this->content,"{postindex}") !== false) {
        echo getCatalog();
    }
}
?>

</main>
<footer class="pt-6 lg:pt-12 ">



<?php $this->need('foot.php');?>


<div class="relative z-50" aria-labelledby="modal-title" role="dialog" aria-modal="true" aria-label="dialog">
    <div id="tczhezhao" class="fixed inset-0 transition-opacity bg-gray-600/50 backdrop-blur-sm" x-cloak
        x-show="search||login||register"></div>
    <div class="fixed inset-x-2 sm:inset-x-0 z-50 overflow-hidden overflow-y-auto rounded-lg top-[15vh] sm:top-[20vh] flex justify-center" x-cloak x-show="search||login||register">

        <div x-cloak x-transition x-show="search" @click.outside="search=false" class="w-[28rem] max-w-full">
            <div class="relative overflow-hidden transition-all bg-white dark:bg-gray-800 rounded-lg">
                <form class="search-form" method="post" action="<?php $this->options->siteUrl(); ?>" role="search">

                <?php
if (array_key_exists('Soso', Typecho_Plugin::export()['activated'])): ?>
                        <div class="flex items-center p-3 text-sm dark:text-white border-b border-black/20 dark:border-white/20">
                            <span>搜索：</span>
                            <div class="flex-1 relative rounded-lg border border-black/20 dark:border-white/20 overflow-hidden">
                            <select id="search-type" name="type"
                                class="appearance-none w-full  p-2 dark:bg-gray-700"
                                x-model="$store.info.searchtype">
                                <option value=" ">全部文章</option>
                                <?php $this->widget('Widget_Metas_Category_List@cate')->to($pages); ?>
                                <?php while($pages->next()): ?>
                                <option value="<?php $pages->mid(); ?>"><?php $pages->name(); ?></option>
                                <?php endwhile; ?>
                            </select>
                        
                            <div class="pointer-events-none absolute right-2 inset-y-0 flex items-center text-gray-500 dark:text-gray-300">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-3"><path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" /></svg>
                            </div>
                        </div>
                        </div>
                        <?php endif; ?>


                    <div class="relative flex items-center">
                        <span class="absolute text-gray-400 left-3">
<svg class="size-6" aria-hidden="true"><use xlink:href="#search_line"></use></svg>
</span>
                        <input type="text" name="s" x-model="$store.info.search" placeholder="Search..." class="w-full dark:text-white py-4 pl-10 pr-4 text-blue-950 placeholder-gray-400/70" required>
                    </div>
                </form>
            </div>
        </div>
        <div x-cloak x-transition x-show="login" @click.outside="login=false" class="relative overflow-hidden transition-all rounded-lg">
            <div class="w-96 max-w-full mx-auto">
                <div class="bg-white dark:bg-gray-800 rounded-lg p-8 mx-4">
                <form id="login" method="post" name="login"
                    rold="form">
                    <input type="hidden" name="referer" value="<?php $this->options->siteUrl(); ?>">
                    <div>
                        <label for="name" class="block mb-2 text-sm text-gray-600 dark:text-gray-200">用户名</label>
                        <input type="text" name="name" id="name" placeholder="请输入用户名" autocomplete="name"
                            class="text-black w-full px-3 py-2 bg-gray-200 placeholder-gray-500 dark:bg-gray-700 dark:text-white rounded-md">
                    </div>

                    <div class="mt-6">
                        <div class="flex justify-between mb-2">
                            <label for="password" class="text-sm text-gray-600 dark:text-gray-200">密码</label>
                        </div>
                        <input type="password" name="password" id="password" placeholder="请输入密码" autocomplete="off"
                            class="text-black w-full px-3 py-2 bg-gray-200 placeholder-gray-500 dark:bg-gray-700 dark:text-white rounded-md">
                    </div>

                    <?php if(array_key_exists('LoginCode', $activated)): ?>
                    <div class="mt-6">
                        <div class="flex justify-between mb-0.5">
                            <label for="yanzhengma" class="text-sm text-gray-600 dark:text-gray-200">验证码</label>
                        </div>
                        <div class="flex items-center">
                        <input type="text" name="yanzhengma" id="yanzhengma" placeholder="请输入验证码" autocomplete="off"
                            class="text-black w-3/5 px-3 py-2 bg-gray-200 placeholder-gray-500 dark:bg-gray-700 dark:text-white rounded-md">
                        <img class="w-2/5 ml-0.5 rounded-md" src="<?php $captcha=Helper::options()->pluginUrl.'/LoginCode/captcha.php';echo $captcha; ?>" onclick="this.src='<?php echo $captcha; ?>?'+Math.random();" title="点击刷新">
                    </div>
                    </div>
                    <?php endif;?>

                    <div class="mt-6">
                        <button id="loginbtn" type="submit"
                            class="w-full px-4 py-2 tracking-wide text-white transition-colors duration-200 transform bg-indigo-500 rounded-md hover:bg-indigo-400">
                            登录
                        </button>
                    </div>
                </form>
                
                <?php if(array_key_exists('Passkey', $activated)): ?>
                <div class="mt-6">
                <button class="w-full text-center px-4 py-2 tracking-wide text-white transition-colors duration-200 transform bg-teal-600 rounded-md hover:bg-teal-500" onclick="if(!navigator.credentials) {alert('您的设备或浏览器可能不支持Passkey功能');}else{validate.a()}">使用通行密钥登录</button>
                <?php $this->passkeybtn();?>
                </div>
                <?php endif; ?>
                
                <?php if(Helper::options()->allowRegister): ?>
                <p class="text-xs text-gray-900 dark:text-white mt-5">没有账号？<button @click="login=false;setTimeout(function() {register=true;}, 200);" class="text-red-400" >注册账号</button></p>
                <?php endif; ?>
                </div>
            </div>
        </div>

<template x-if="$store.user.register">
        <div x-cloak x-transition x-show="register" @click.outside="register=false" class="relative overflow-hidden transition-all rounded-lg" x-init="main.register()">
            <div class="w-96 max-w-full mx-auto">
                <div class="bg-white dark:bg-gray-800 rounded-lg p-8 mx-4">
                <form id="register" method="post" name="register"
                    rold="form">
                    <input type="hidden" name="referer" value="<?php $this->options->siteUrl(); ?>">
            <h2 class="text-gray-900 dark:text-white text-lg font-medium title-font mb-5">注册账号 ✨</h2>
            <div class="relative mb-4">
                <label for="username" class="leading-7 text-sm text-gray-600 dark:text-gray-200">用户名</label>
                <input type="text" id="username" name="name" placeholder="请输入用户名" autocomplete="off"
                    class="text-black w-full px-3 py-2 bg-gray-200 placeholder-gray-500 dark:bg-gray-700 dark:text-white rounded-md" required>
            </div>
            <div class="relative mb-4">
                <label for="email" class="leading-7 text-sm text-gray-600 dark:text-gray-200">邮箱</label>
                <input type="email" id="email" name="mail" placeholder="请输入邮箱" autocomplete="off"
                    class="text-black w-full px-3 py-2 bg-gray-200 placeholder-gray-500 dark:bg-gray-700 dark:text-white rounded-md" required>
            </div>
            <div class="relative mb-4">
                <label for="xpassword" class="leading-7 text-sm text-gray-600 dark:text-gray-200">密码</label>
                <input type="password" id="xpassword" name="password" placeholder="请输入密码" autocomplete="off"
                    class="text-black w-full px-3 py-2 bg-gray-200 placeholder-gray-500 dark:bg-gray-700 dark:text-white rounded-md" required>
            </div>
            <div class="relative mb-4">
                <label for="confirm-password" class="leading-7 text-sm text-gray-600 dark:text-gray-200">确认密码</label>
                <input type="password" id="confirm-password" name="confirm" placeholder="请确认密码" autocomplete="off"
                    class="text-black w-full px-3 py-2 bg-gray-200 placeholder-gray-500 dark:bg-gray-700 dark:text-white rounded-md" required>
            </div>
<?php if(array_key_exists('LoginCode', $activated)): ?>
<div class="mb-4">
    <div class="flex justify-between mb-0.5">
        <label for="reyanzhengma" class="text-sm text-gray-600 dark:text-gray-200">验证码</label>
    </div>
    <div class="flex items-center">
    <input type="text" name="yanzhengma" id="reyanzhengma" placeholder="请输入验证码" autocomplete="off"
        class="text-black w-3/5 px-3 py-2 bg-gray-200 placeholder-gray-500 dark:bg-gray-700 dark:text-white rounded-md">
    <img class="w-2/5 ml-0.5 rounded-md" src="<?php $captcha=$captcha.'?type=register';echo $captcha; ?>" onclick="this.src='<?php echo $captcha; ?>&'+Math.random();" title="点击刷新">
</div>
</div>
<?php endif;?>

            <?php if(array_key_exists('InvitationCode', $activated)): ?>
            <div class="relative mb-3">
                <label for="code_cxa" class="leading-7 text-sm text-gray-600 dark:text-gray-200">邀请码</label>
                <input id="code_cxa" name="code_cxa" placeholder="邀请码" autocomplete="off"
                    class="text-black w-full px-3 py-2 bg-gray-200 placeholder-gray-500 dark:bg-gray-700 dark:text-white rounded-md" required>
            </div>
            <?php endif;?>
            <div>
            <button id="registerbtn" type="submit"
                            class="w-full px-4 py-2 tracking-wide text-white transition-colors duration-200 transform bg-indigo-500 rounded-md hover:bg-indigo-400">确认注册</button>
                </div>
            <p class="text-xs text-gray-900 dark:text-white mt-5">已有账号？<button @click="register=false;setTimeout(function() {login=true;}, 200);" class="text-red-400" >登录账号</button></p>
                </form>
                </div>
            </div>
        </div>
</template>

    </div>
</div>









</footer>
</div>



<div class="fixed z-40 flex flex-col -my-1.5 transform transition ease-out duration-150 bottom-4 right-2 md:bottom-8 md:right-4 text-lg">
<button id="widget-to-top" @click="main.top()" class="text-[var(--primary)] shadow cursor-pointer hidden text-xs size-12 my-1.5 rounded-lg p-2 bg-[var(--card-bg)] hover:bg-[var(--btn-card-bg-hover)] duration-300 transform" aria-label="返回顶部" title="返回顶部">
    <span class="num"></span>
    <span class="hidden up text-lg font-bold">↑</span>
</button>



</div>


</div>


<?php $this->need('assets/foot.php'); ?>
<script src="<?php $this->options->themeUrl('assets/OwO.min.js?2024'); ?>" data-no-instant></script>
<script src="<?php $this->options->themeUrl('assets/iconlist.js?2025'); ?>"></script>
<script src="<?php $this->options->themeUrl('main.js?20250329'); ?>" data-no-instant></script>
<script data-no-instant>
    InstantClick.on('change', function(isInitialLoad) {
        if (isInitialLoad === false) {

            if (typeof MathJax !== 'undefined') {
                MathJax.Hub.Queue(["Typeset", MathJax.Hub]);
            }
            if (typeof prettyPrint !== 'undefined') {
                prettyPrint();
            }
            if (typeof _hmt !== 'undefined') {
                _hmt.push(['_trackPageview', location.pathname + location.search]);
            }
            if (typeof ga !== 'undefined') {
                ga('send', 'pageview', location.pathname + location.search);
            }
            const livePhotos = document.querySelectorAll("[data-live-photo]");
            if (window.LivePhotosKit) {
                /*兼容苹果livephoto*/
                livePhotos.forEach((livePhoto) => {
                    if (!livePhoto.classList.contains("lpk-live-photo-player")) {
                        LivePhotosKit.augmentElementAsPlayer(livePhoto);
                    }
                });
            }
            main.alpine();
            main.all();
            <?php $this->options->refunction(); ?>
        }
    });
<?php if(defined('InstantClick')&&InstantClick>0){
    echo "InstantClick.init('#main');";
}else{
    echo "InstantClick.init('mousedown','#main');";
}?>
   
</script>

<?php $this->options->diyjs(); ?>
<?php $this->footer(); ?>
</body>

</html>