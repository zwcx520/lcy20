window.onload = function (){ 
    $(".tabLinks").click(function(){
        $('.tabLinks').removeClass('active');
        $(this).addClass('active');
        $('.hiddenx').hide();
        const obj=$(this).data("item");
        $('#'+obj).show();
    });
}  