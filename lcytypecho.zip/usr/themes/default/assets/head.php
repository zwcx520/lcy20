<link href="<?php $this->options->themeUrl('assets/bendi/fancybox.min.css'); ?>" rel="stylesheet">
<link href="<?php $this->options->themeUrl('assets/bendi/swiper.min.css'); ?>" rel="stylesheet">
<script src="<?php $this->options->themeUrl('assets/bendi/swiper.min.js'); ?>"></script>
<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js"></script>
-->