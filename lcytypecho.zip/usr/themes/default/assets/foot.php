<script src="<?php $this->options->themeUrl('assets/bendi/collapse.min.js'); ?>" data-no-instant></script>
<script src="<?php $this->options->themeUrl('assets/bendi/intersect.min.js'); ?>" data-no-instant></script>
<script src="<?php $this->options->themeUrl('assets/bendi/alpinejs3.14.3.min.js'); ?>" defer data-no-instant></script>
<script src="<?php $this->options->themeUrl('assets/bendi/fancybox.umd.min.js'); ?>" data-no-instant></script>
<script src="<?php $this->options->themeUrl('assets/bendi/highlight.min.js'); ?>" data-no-instant></script>
<script src="<?php $this->options->themeUrl('assets/bendi/clipboard.min.js'); ?>" data-no-instant></script>
<script src="<?php $this->options->themeUrl('assets/bendi/jr-qrcode.min.js'); ?>" data-no-instant></script>
<script src="<?php $this->options->themeUrl('assets/bendi/instantclick.min.js?202503'); ?>" data-no-instant></script>