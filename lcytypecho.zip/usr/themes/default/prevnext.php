<?php if($this->is('post')): ?>

<div class="my-5 text-gray-900 dark:text-gray-100 grid grid-cols-1 sm:grid-cols-2 gap-4">
  
<?php 
$prev=thePrev($this);//调用函数并将函数值给变量
$next=theNext($this);//调用函数并将函数值给变量
if($this->fields->tcid){$this->widget('Widget_Archive@tcid', 'pageSize=1&type=post', 'cid='.$this->fields->tcid)->to($prev);}
if($this->fields->bcid){$this->widget('Widget_Archive@bcid', 'pageSize=1&type=post', 'cid='.$this->fields->bcid)->to($next);}
 ?>
 <?php if($prev->created<$this->created): ?>
<a href="<?php $prev->permalink(); ?>" class="relative cursor-pointer p-3 lg:p-5 duration-300 text-white rounded-lg overflow-hidden shadow before:absolute before:inset-0 before:bg-black/40 bg-cover bg-no-repeat bg-center before:backdrop-blur-sm hover:before:backdrop-blur-2xl" style="background-image: url(<?php echo showThumbnail($prev); ?>)">

<div class="relative z-10 flex justify-between items-center ">
<svg class="size-6" aria-hidden="true"><use xlink:href="#arrow_left_fill"></use></svg>
<div class="flex-1 text-right">
<div class="font-semibold mb-1">上一篇</div>
<div class="text-sm line-1"><?php $prev->title(); ?></div>
</div></div>
</a>
<?php else: ?>

<a href="<?php randomPost(); ?>" class="relative cursor-pointer p-3 lg:p-5 duration-300 bg-gray-500 dark:bg-gray-700 text-white rounded-lg overflow-hidden shadow">
<div class="relative z-10 flex justify-between items-center ">
<svg class="size-6" aria-hidden="true"><use xlink:href="#arrow_left_fill"></use></svg>
<div class="flex-1 text-right">
<div class="font-semibold mb-1">随便逛逛</div>
<div class="text-sm line-1">在博客范围内随机进入一篇文章</div>
</div></div>
</a>

<?php endif; ?>
<!--
讲解一下，$prev=thePrev($this);调用后，$prev->permalink就是上一篇文章的链接，$prev->title就是标题，showThumbnail($prev)就是缩略图，就跟正常调用文章的语法一致，只是$this换成了$prev。
-->
<!--判断下一篇文章是否存在-->
<?php if($next->created>$this->created): ?>
  <a href="<?php $next->permalink(); ?>" class="relative cursor-pointer p-3 lg:p-5 duration-300 text-white rounded-lg overflow-hidden shadow before:absolute before:inset-0 before:bg-black/40 bg-cover bg-no-repeat bg-center before:backdrop-blur-sm hover:before:backdrop-blur-2xl" style="background-image: url(<?php echo showThumbnail($next); ?>)">
<div class="relative z-10 flex justify-between items-center ">
<div class="flex-1">
<div class="font-semibold mb-1">下一篇</div>
<div class="text-sm line-1"><?php $next->title(); ?></div>
</div>
<svg class="size-6 rotate-180" aria-hidden="true"><use xlink:href="#arrow_left_fill"></use></svg>
</div>
</a>
<?php else: ?>
<a href="<?php randomPost(); ?>" class="relative cursor-pointer p-3 lg:p-5 duration-300 bg-gray-500 dark:bg-gray-700 text-white rounded-lg overflow-hidden shadow">
<div class="relative z-10 flex justify-between items-center ">
<div class="flex-1">
<div class="font-semibold mb-1">随便逛逛</div>
<div class="text-sm line-1">在博客范围内随机进入一篇文章</div>
</div>
<svg class="size-6 rotate-180" aria-hidden="true"><use xlink:href="#arrow_left_fill"></use></svg>
</div>
</a>
<?php endif; ?>


</div>
<?php endif;?>

