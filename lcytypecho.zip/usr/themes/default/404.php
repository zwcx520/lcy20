<?php
/**
 * 由Hani主题生成而来，Hani名字由honey音译。
 *
 * @package {{Hani}}
 * @author 泽泽社长
 * @version 0.8.0
 * @link https://store.typecho.work/
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
?>

<article class="break-all bg-white dark:bg-gray-900 p-3 lg:p-5 rounded-lg shadow w-full flex flex-col">

<img class="w-72 mx-auto mb-5" src="<?php $this->options->themeUrl('img/404.svg'); ?>" alt="">

<p class="text-xl text-center">嗯。。。此页面不存在或已被管理员删除！</p>
</article>
<?php $this->need('footer.php');
?>