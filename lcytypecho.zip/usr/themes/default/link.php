<?php 
/**
 * 友情链接
 * 
 * @package custom 
 * 
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
?>
<script type='text/javascript'>/* <![CDATA[ */
var globals = {"post_id":"<?php $this->cid(); ?>","post_url":"<?php $this->permalink(); ?>","respondId":"<?php $this->respondId(); ?>"};
/* ]]> */</script>

<article id="post"
 class="w-full break-all overflow-hidden">
 <div class="bg-white dark:bg-gray-900 px-5 py-8 rounded-lg shadow shadow-blue-100 dark:shadow-gray-500">

 <div class="flex items-center mb-6">

                       <h1 class="font-medium text-lg lg:text-2xl text-black dark:text-white mb-1"><?php $this->title(); ?></h1>

                        <a :href="$store.info.write" class="ml-2 text-xs flex items-center text-[var(--primary)]"  target="_blank" x-show="$store.info.write" x-cloak><svg class="size-4 mr-0.5" aria-hidden="true"><use xlink:href="#edit_3_fill"></use></svg>
编辑</a>

                   
</div>

<div class="grid grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-4">
<?php 
echo Links_Plugin::output('<div class="flex items-center p-4 bg-black text-white shadow rounded-md transition-all duration-300 transform hover:shadow-xl hover:-translate-y-1 relative overflow-hidden">
<a href="{url}" title="{name}" target="_blank" rel="noopener" class="flex flex-shrink-0 z-10"><img class="size-11 lg:size-14 object-cover rounded-full scrollLoading" src="{image}"></a>
<div class="w-full mt-0 pl-2 z-10"><p class="text-base font-medium line-1 dark:text-gray-50"><a href="{url}" target="_blank" rel="noopener" title="{name}" class="block">{name}</a></p><p class="text-xs text-gray-100 line-1 mt-1">{description}</p>
</div>
<div class="rounded-md absolute inset-0 bg-cover bg-no-repeat opacity-70" style="background-image:url({image});background-size: 20000%;
background-position: center 30%;"></div>
</div>','','','','HTML'); ?>

</div>

</div>


<?php if($this->content):?>
<div class="bg-white dark:bg-gray-900 mt-8 p-5 rounded-lg shadow shadow-blue-100 dark:shadow-gray-500">
<div class="fancycon break-all markdown-section"> 
<?php
$this->content=buju($this->content);
$this->content=createCatalog($this->content);
$this->content=setshortcode($this->content,$this);
$this->content();
?>
</div>
</div>
<?php endif; ?>

<div id="comments-qu" class="bg-white dark:bg-gray-900 mt-8 p-5 rounded-lg shadow shadow-blue-100 dark:shadow-gray-500">


<div class="text-center bg-[#d4dbdf] dark:bg-[#242d34] rounded-lg p-8" x-show="!$store.info.comment">
<svg class="size-10 mx-auto animate-spin" aria-hidden="true"><use xlink:href="#icon_loading"></use></svg>
</div>
<div x-html="$store.info.comment" x-show="$store.info.comment" x-cloak></div>
</div>
</article>



<?php $this->need('footer.php'); ?>
