<?php $this->need('swiper.php');?>
<?php if ($this->have()): ?> 
<div id="ajax-list" class="grid grid-cols-1 gap-4 lg:gap-6 text-base text-gray-600 dark:text-gray-300 mb-5 sm:mb-8" role="main">

<?php while ($this->next()): ?>
    
    

    <article class="break-all bg-white dark:bg-gray-900 p-3 lg:p-5 rounded-lg shadow w-full flex flex-col">
        


<div class="w-full flex items-center mb-3">
    <span class="text-[var(--primary)] "><?php echo getCNWeek($this->created); ?></span>
    <span class="ml-1 sm:ml-2 text-[var(--primary)] text-xs"><?php $this->date('Y年m月d日'); ?></span>
    <div class="flex-1 relative ml-1 sm:ml-2">
    <hr class="w-full border border-gray-200/80 dark:border-gray-600/80">
    <hr class="w-12 border border-gray-400/80 absolute top-1/2 transform -translate-y-1/2">
</div>
</div>

<div class="flex">

<div class="text-xs hidden md:block mr-3">
<div class="w-11 text-center bg-[var(--card-bg)] duration-500 hover:text-[var(--primary)] hover:bg-[var(--btn-plain-bg-hover)] border border-gray-200/80 dark:border-gray-600/80 rounded-md p-2">
<svg class="size-4 mx-auto" aria-hidden="true"><use xlink:href="#up_line"></use></svg>
<span><?php if(get_post_view($this,1)>99){echo '99+';}else{echo get_post_view($this,1);}?></span>
</div></div>

<a href="<?php $this->permalink();?>" class="size-25 media rounded"  title="<?php $this->title();?>">
<img class="rounded-lg duration-500 hover:scale-125 media-content h-full w-full object-cover" src="<?php icon($this); ?>" alt="<?php $this->title();?>">
</a>

<div class="flex-1 flex ml-2 sm:ml-4">
<div class="flex-1">
    <a href="<?php $this->permalink();?>" class="dark:hover:text-[var(--primary)] hover:text-[var(--primary)] duration-300 text-base font-bold line-clamp-2 mb-2 flex items-center"><?php $this->title();?></a>

    <p class="text-sm text-gray-400 w-full line-clamp-3 mb-3"><?php $this->excerpt(200, '...'); ?></p>
</div>

<div class="flex-none relative w-9 ml-2 sm:ml-4">
<svg class="absolute top-0 right-2 text-gray-200 dark:text-gray-600/80 size-9" aria-hidden="true"><use xlink:href="#icon_comment"></use></svg>
<span class="flex items-center justify-center text-xs text-white rounded-full size-7 bg-[var(--btn-regular-bg-active)] absolute right-0 top-1"><?php if($this->commentsNum>9){echo '9+';}else{$this->commentsNum();}?></span>
</div>


</div>
</div>



    </article>


    
<?php endwhile; ?>

</div>


<!-- #pagination -->
<div class="flex items-center justify-center my-5 border-t pt-10 border-black/10 dark:border-white/10">
<?php $this->need('pagination.php'); ?>
</div>
<!-- end #pagination -->
<?php else: ?>

<div class="bg-white dark:bg-gray-900 rounded-lg p-20 mx-auto text-center text-gray-400">
    <img class="w-16 mx-auto mb-3" src="<?php $this->options->themeUrl('img/null.svg'); ?>">
    <p class="text-sm">「没有找到文章」</p>
</div> 
    
    
<?php endif; ?>
