
<?php if($this->is('index')&&($this->options->lunbo!='off')&&(!$this->currentPage||$this->currentPage==1)): ?>
        <div class="swiper-container rounded-lg !mb-3 lg:!mb-6">
  <!-- 如果需要关闭手动控制滑动 把标签swiper-no-swiping添加进去-->
        <div class="swiper-wrapper">
        <!-- 这里放轮播的东西 图片文字都可以 -->

<?php 
$lunbo="归档-时光卷轴\$https://lcy20.netlify.app/\$".$this->options->themeUrl."/img/banner/1.png$1\r\n追吻辰星软件平台\$https://zwcx.netlify.app/\$".$this->options->themeUrl."/img/banner/2.png$1";
if($this->options->lunbo){$lunbo=$this->options->lunbo;}
$lunbo = @explode("\r\n", $lunbo);
foreach ($lunbo as $val){
$set=@explode("$",$val);
$bt=$set[0];$lj=$set[1];$tplj=$set[2];
$blank='';
if(isset($set[3])){$blank='target="_blank"';}
?>
        <div class="swiper-slide group rounded-lg overflow-hidden Carouselbig">
            <a href="<?php echo $lj;?>" class="item block relative" <?php echo $blank;?>>
            <div class="flex-none media media-16x9 w-full">
                    <img class="transition-transform duration-200 group-hover:scale-110 media-content h-full w-full object-cover" 
                    src="<?php echo $tplj;?>" alt="<?php echo $bt;?>">
            </div><div class="title"><?php echo $bt;?></div></a>
            </div>

 <?php } ?>      
        </div>

 <!-- 如果需要分页器 -->
 <div class="swiper-pagination"></div>
        <!-- 如果需要导航按钮 -->
        <div class="swiper-button-prev flex items-center"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
  <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
</svg>
</div>
        <div class="swiper-button-next flex items-center"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
</svg>
</div>
    </div>
<?php endif;?>