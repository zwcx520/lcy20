<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;
?>
<?php
    \Widget\Contents\Attachment\Related::alloc(['parentId' => $this->cid])->to($attachment);
    \Widget\Security::alloc()->to($security);
$shenfen=0;
if($this->user->uid==$this->authorId){
$shenfen=1;
}
define("shenfen",$shenfen);

if(!$this->is('attachment')): ?>
<div class="w-full text-gray-900 dark:text-gray-200"
x-data="{allow:<?php if($this->allow('comment')){echo 'true';}else{echo 'false';} ?>}"
    >
<div class="text-xl mb-3 font-medium">
<div class="flex items-center mb-3"><span class="bg-[var(--primary)] h-4 w-1 rounded-full mr-2"></span>评论区</div>
</div>
<?php function threadedComments($comments, $options) {
    $commentClass = '';$sf="";
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {$sf='<svg class="text-sky-500 size-5 ml-0.5" aria-hidden="true"><use xlink:href="#certificate_fill"></use></svg>';
            $commentClass .= '';  //如果是文章作者
        } else {
            $commentClass .= '';  //如果是评论作者
$sf="";
        }
    } 
   if ($comments->url) {
        $author = '<a href="' . $comments->url . '" target="_blank" rel="external nofollow" class="'.$commentClass.'" data-ajax="false">' . $comments->author . '</a>';
    } else {
                $author = '<span class="'.$commentClass.'">' . $comments->author . '</span>';
    }
    
    $commentLevelClass = $comments->levels > 0 ? ' comment-child children' : ' comment-parent';  //评论层数大于0为子级，否则是父级
?>

<li id="li-<?php $comments->theId(); ?>" class="comment-body<?php echo $commentLevelClass; ?>">
<div id="<?php $comments->theId(); ?>"><div class="h-20 -mt-20 block invisible"></div>
 <article id="div-<?php $comments->theId(); ?>" class="group flex comment-body my-2">
        <div class="flex-none mr-1"
 x-data="{k:[],imgurl:'<?php echo tx($comments->mail,"blank",$comments->authorId); ?>',tx:'<?php echo letter_avatarx($comments->author); ?>'}">
            
        <div class="relative">
        <img no-view class="relative z-10 size-12 object-cover border-2 border-gray-200 rounded-full scrollLoading mr-1" :src="imgurl" alt="<?php echo $comments->author; ?>" x-cloak>
        <img no-view class="absolute top-0 left-0 size-12 object-cover border-2 border-gray-200 rounded-full scrollLoading mr-1" :src="tx" alt="<?php echo $comments->author; ?>" x-cloak>
        </div>
        
        </div>
        <!-- .comment-author -->
<div class="flex-initial w-full text-sm">
            <div class="comment-author mb-1">
                <div class="flex items-center">
                    <?php echo $author.$sf;
                    echo $options['afterAuthor']; ?><span class="mx-1"></span><?php if ('waiting' == $comments->status) { ?><span class="text-muted">您的评论需管理员审核后才能显示！</span><?php } ?> </div>
            </div>
            <div class="relative comment-content px-4 py-2 rounded bg-slate-100 text-gray-900 dark:bg-gray-700 dark:text-gray-100">
                <?php 

$cos=$comments->content;
$cos=parseBiaoQing($comments->content);
$cos = preg_replace('#<a(.*?) href="([^"]*/)?(([^"/]*)\.[^"]*)"(.*?)>#',
        '<a$1 href="$2$3"$5 class="text-sky-500" target="_blank" rel="nofollow" data-ajax="false">', $cos);    

echo get_comment_at($comments->coid).$cos;
 ?>
                            </div><!-- .comment-content -->
            <div class="flex items-center comment-meta text-xs text-gray-500 mt-1" data-no-instant>
                <time class="mr-1"><?php echo timesince($comments->created); ?></time>

                <?php if($options['replyWord']!='hidden'):?>
                <template x-if="allow">
                <div>
                <button class="flex items-center comment-reply cp-<?php $comments->theId(); ?> text-muted comment-reply-link hover:text-blue-500" onclick="return TypechoComment.reply('<?php $comments->theId(); ?>', <?php $comments->coid(); ?>);"><svg class="size-3.5 mr-0.5" transform="scale(-1, 1)" aria-hidden="true"><use xlink:href="#chat_4_line"></use></svg><span>回复</span></button>

                <button id="cancel-comment-reply" onclick="return TypechoComment.cancelReply();" class="flex items-center cancel-comment-reply cl-<?php $comments->theId(); ?> text-muted comment-reply-link text-red-500" style="display:none"><svg class="size-3.5 mr-0.5" aria-hidden="true"><use xlink:href="#close_fill"></use></svg><span>取消</span></button>
                </div>
                </template>
                <?php endif;?>

            </div>
        </div><!-- .comment-text -->
    </article><!-- .comment-body -->
</div>



<?php if ($comments->children) { ?>
<?php $comments->threadedComments(); ?>
<?php } ?>
</li>
<?php } ?>




<div id="comments" class="break-all post-comment">


<?php if($this->allow('comment')): ?> 
 <div id="<?php $this->respondId(); ?>" class="comment-respond"  data-no-instant>


<form method="post" action="<?php $this->commentUrl() ?>" id="commentform" class="comment-form"
    >
<div class="flex text-sm">

<div class="flex-initial hidden mr-2 mr-avatar md:block">
<?php if($this->user->hasLogin()): ?>
<div class="relative">
        <img no-view class="relative z-10 size-12 object-cover border-2 border-gray-200 rounded-full scrollLoading mr-1" src="<?php echo tx($this->user->mail,"blank",$this->user->uid); ?>" alt="<?php $this->user->screenName(); ?>">
        <img no-view class="absolute top-0 left-0 size-12 object-cover border-2 border-gray-200 rounded-full scrollLoading mr-1" src="<?php echo letter_avatarx($this->user->screenName); ?>" alt="<?php $this->user->screenName(); ?>">
</div>
<?php else: ?>
<?php if($this->remember('mail',true)): ?>
<div class="relative">
        <img no-view class="relative z-10 size-12 object-cover border-2 border-gray-200 rounded-full scrollLoading mr-1" src="<?php echo tx($this->remember('mail',true),"blank"); ?>" alt="<?php $this->remember('author'); ?>的头像">
        <img no-view class="absolute top-0 left-0 size-12 object-cover border-2 border-gray-200 rounded-full scrollLoading mr-1" src="<?php echo letter_avatarx($this->remember('author',true)); ?>" alt="<?php $this->remember('author'); ?>">
</div>
<?php else: ?>

<img src="<?php $this->options->themeUrl('img/tx.png'); ?>" class="relative z-10 size-12 object-cover border-2 border-gray-200 rounded-full scrollLoading mr-1" alt="头像">
<?php endif; ?>

<?php endif; ?>
</div>

<div class="flex-initial w-full">
<div class="comment-form-body flex align-items-center rounded relative bg-slate-100 dark:bg-gray-700 dark:text-gray-100">

<textarea id="comment" name="text" class="resize-none py-2 px-1.5 OwO-textarea flex-1 w-full text-sm bg-transparent border-gray-600" rows="3" placeholder="说点什么吧" required><?php $this->remember('text'); ?></textarea>

    
<div class="form-submit comment-form-action flex flex-none justify-center px-2.5">
<button name="submit" type="submit" id="submit" class="flex items-center justify-center m-auto size-9 rounded-full p-2 text-lg transition duration-300 transform hover:rotate-30 text-white bg-[var(--primary)] hover:bg-[var(--primary)]" value="发布评论" aria-label="提交评论"><svg class="size-5" aria-hidden="true"><use xlink:href="#send_plane_fill"></use></svg>
</button>
</div>

<?php if(!$this->user->hasLogin()&&!empty($this->options->tools)&&in_array('loginpl', $this->options->tools)): ?>
<div class="absolute inset-0 p-4 flex justify-center items-center bg-slate-100 dark:bg-gray-700"  >请先<button @click="login=true" class="px-2 py-1 mx-0.5 text-white duration-100 bg-blue-500 hover:bg-blue-800 rounded-md">登录</button>后发布评论(°∀°)ﾉ</div>
<?php endif; ?>
</div>
<?php if(!$this->user->hasLogin()): ?>
<?php if(empty($this->options->tools)||!in_array('loginpl', $this->options->tools)): ?>
<div class="comment-form-info mt-3">
<div class="grid grid-cols-1 md:grid-cols-<?php if (!empty($this->options->tools) && in_array('spam', $this->options->tools)){echo '2'; }else{echo '3'; } ?> gap-4">
<div>
<input class="w-full rounded py-1.5 px-1 text-sm comment-form-body text-gray-900 border-gray-100 bg-slate-100 dark:bg-gray-700 dark:text-gray-100" id="mail" placeholder="Email" name="mail" type="email" value="<?php $this->remember('mail'); ?>"<?php if ($this->options->commentsRequireMail): ?> required<?php endif; ?>>
</div>
<div>
<input class="w-full rounded py-1.5 px-1 text-sm comment-form-body text-gray-900 border-gray-100 bg-slate-100 dark:bg-gray-700 dark:text-gray-100" id="author" placeholder="昵称" name="author" type="text" value="<?php $this->remember('author'); ?>" required>
</div>
<div>
<input class="w-full rounded py-1.5 px-1 text-sm comment-form-body text-gray-900 border-gray-100 bg-slate-100 dark:bg-gray-700 dark:text-gray-100" id="url" placeholder="站点" name="url" type="url" value="<?php $this->remember('url'); ?>">
</div>
<?php if (!empty($this->options->tools) && in_array('spam', $this->options->tools)): ?>
<?php spam_protection_math(); ?>
<?php endif; ?>
</div>
</div>     
<?php endif; ?><?php endif; ?>
 
<div class="flex items-center mt-1 text-gray-600 dark:text-gray-400">
<label class="inline-flex items-center">
 <?php
$owo=array("ヾ(≧∇≦*)ゝ","OωO","(｡•ˇ‸ˇ•｡)","(°∀°)ﾉ","（/TДT)/","Σ(ﾟдﾟ;)","ヽ(`Д´)ﾉ");
$owo='<button type="button" class="OwO-logo mr-3" rel="external nofollow" data-no-instant><small class="text-xs">'.$owo[array_rand($owo,1)].'</small></button>';  
echo $owo;
?>
</label>



<?php $all = Typecho_Plugin::export();?><?php if (array_key_exists('SecretComments', $all['activated'])) : ?>
    <input type="checkbox" name="is-private" id="PrivateComments" class="hidden">
    <label for="PrivateComments" class="relative rounded-full bg-gray-200 cursor-pointer mr-1 dark:bg-gray-700"></label><span>隐私评论</span>
<?php endif; ?>       

      

        
</div>   
  
    
    
<div class="OwO mt-2"></div>
    
    
    
    
    
</div></div>
</form>
</div>
<?php else: ?>
<!--评论已关闭-->
<div id="nocomment" class="w-full text-center text-gray-500 text-xs pt-2 pb-6">

<div class="mb-2">
<svg class="mx-auto size-10" aria-hidden="true"><use xlink:href="#comment_2_line"></use></svg>
</div>
评论已关闭
    
</div>
<?php endif; ?>





<?php $this->comments()->to($comments); ?>
<?php if ($comments->have()): ?>


<?php if($this->fields->CommentSticky){
$coid=$this->fields->CommentSticky;
?>
<style>
ol.comment-list #li-comment-<?php echo $coid;?> {
    display: none;
}
</style>
<?php 
$ji=Helper::widgetById('Comments', $coid); echo '<ol>'; threadedComments($ji,[
            'afterAuthor'   => '<svg class="size-5 ml-0.5" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="16263"><path d="M847.030961 65.290005 176.966992 65.290005c-61.683874 0-111.677499 49.992601-111.677499 111.677499l0 670.063969c0 61.684898 49.992601 111.678522 111.677499 111.678522l670.063969 0c61.683874 0 111.678522-49.992601 111.678522-111.678522L958.709483 176.967504C958.709483 115.282606 908.715859 65.290005 847.030961 65.290005zM434.99365 228.704842l363.875404 0 0 73.131601L641.614521 301.836443l-10.69662 57.060577 151.34187 0 0 271.715425-79.710436 0L702.549336 430.247045 518.857686 430.247045l0 204.527187-79.675644 0L439.182043 358.89702l102.272291 0 10.679223-57.060577L434.99365 301.836443 434.99365 228.704842zM373.188003 683.528632c0 24.167422-4.223185 43.293015-12.651135 57.365522-8.42795 14.07353-19.839861 22.903639-34.323737 26.462698-14.44806 3.576455-46.991244 5.339612-97.508801 5.339612-2.791579-23.774473-7.328919-49.539276-13.644765-77.284177 18.216897 1.989307 36.016285 2.966565 53.465702 2.966565 15.879666 0 23.783683-8.699126 23.783683-26.148543L292.308951 316.694849l-76.079746 0 0-81.445964 209.865775 0 0 81.445964-52.906977 0L373.188003 683.528632zM758.475066 792.921088c-39.663348-32.893154-89.289606-70.654176-148.933007-113.248274-26.786063 44.583404-82.361823 83.122139-166.81733 115.620297-12.267395-23.382547-28.14706-49.13814-47.550992-77.283154 42.787502-11.691273 78.435397-26.960025 106.879216-45.778626 28.442796-18.819624 47.254234-44.627407 56.501852-77.432557 9.195429-32.806173 13.820774-75.364455 13.820774-127.687124l78.486562 0c0 58.063417-4.674463 106.328677-13.95892 144.770198 55.874565 35.282574 113.24725 74.221422 172.087357 116.825752L758.475066 792.921088z" fill="#FF6700" p-id="16264"></path></svg>',
            'replyWord'=> 'hidden',
        ]); echo '</ol>';
}
?>

<?php $comments->listComments(); ?>


<?php 
$npattern = '/\<li.*?class=\"next\"><a.*?\shref\=\"(.*?)\"[^>]*>/i';
ob_start();
$comments->pageNav();
$con = ob_get_clean();
$n=preg_match_all($npattern, $con, $nextlink);
if($n){
$nextlink=$nextlink[1][0];
}else{
$nextlink=false;
}
$nextlink=str_replace("#comments","?type=comments",$nextlink);
?>
<?php if($nextlink): ?>
<div class="flex items-center justify-center mt-5">

<button id="loadMoreBtn" x-data="{load:false}" @click="load=true;main.LoadCommentList('<?php echo $nextlink; ?>');" class="rounded-full px-10 py-2 shadow mx-3 mb-3 text-center text-sm duration-150 bg-[var(--btn-regular-bg-hover)] hover:text-[var(--btn-content)] hover:bg-[var(--btn-regular-bg-active)]"
            >
            <span x-show="load" class="inline-flex items-center">
                <svg class="animate-spin -ml-1 mr-2 size-5" aria-hidden="true"><use xlink:href="#icon_load"></use></svg>
                加载中...
            </span>
            <span x-show="!load">加载更多</span>
</button>

</div>
<?php endif; ?>
<?php else: ?>
    <?php if($this->allow('comment')): ?> 
<div id="nocomment" class="w-full text-center text-gray-500 text-xs pt-2 pb-6">

<div class="mb-2">
<svg class="mx-auto size-10" aria-hidden="true"><use xlink:href="#comment_2_line"></use></svg>
</div>
    暂无评论，快来抢沙发
    
</div>
<?php endif; ?>
<?php endif; ?>








</div>


</div>
<?php endif; ?>