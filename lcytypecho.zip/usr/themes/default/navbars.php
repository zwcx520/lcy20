<?php 
$loginbtn=<<<HTML
            <button @click="dropdownOpen=!dropdownOpen" class="relative overflow-hidden">
            <img src="{$this->options->themeUrl}/img/tx.png" alt="登录"
                    class="rounded-full size-6 lg:size-8 object-cover" loading="lazy">
            </button>
HTML;
            
if(tepassok){
$loginurl=tepasssignin;
$loginbtn=<<<HTML
            <a href="{$loginurl}" target="_blank" class="relative overflow-hidden">
            <img src="{$this->options->themeUrl}/img/tx.png" alt="登录"
                    class="rounded-full size-6 lg:size-8 object-cover" loading="lazy">
            </a>
HTML;
    
}
$right=<<<HTML
           <!-- right -->
            <div class="flex ml-2 items-center">

                <button @click="search=true"
                    class="rounded-lg p-2 duration-300 hover:text-[var(--primary)] hover:bg-[var(--btn-plain-bg-hover)] ml-2"><svg class="size-6" aria-hidden="true"><use xlink:href="#search_line"></use></svg>
                </button>

                <div x-data="{ isOpen: false }" class="inline-block">
                    <button @click="isOpen = !isOpen"
                        class="rounded-lg p-2 duration-300 hover:text-[var(--primary)] hover:bg-[var(--btn-plain-bg-hover)] ml-2">
                        <svg class="size-6" aria-hidden="true"><use xlink:href="#palette_fill"></use></svg>
                    </button>
                    <!-- Dropdown menu -->
                    <div x-cloak x-show="isOpen" @click.outside="isOpen = false"
                        x-transition:enter="transition ease-out duration-100"
                        x-transition:enter-start="opacity-0 scale-90" x-transition:enter-end="opacity-100 scale-100"
                        x-transition:leave="transition ease-in duration-100"
                        x-transition:leave-start="opacity-100 scale-100" x-transition:leave-end="opacity-0 scale-90"
                        class="p-3 pb-4 absolute right-2 lg:right-0 z-60 w-68 lg:w-76 py-2 mt-4 origin-top-right bg-white rounded-lg shadow-xl dark:bg-gray-800">
                        <div class="flex justify-between items-center text-lg mb-3 font-medium">
                            <div class="flex items-center"><span
                                    class="bg-[var(--primary)] h-4 w-1 rounded-full mr-2"></span>主题色
                
                                <button @click="colornum=hue;document.cookie = 'colornum='+colornum+';path=/';" x-cloak x-show="colornum!=hue"
                                class="ml-2 text-[var(--primary)] bg-[var(--btn-regular-bg)] duration-300 hover:bg-[var(--btn-regular-bg-hover)] active:bg-[var(--btn-regular-bg-active)] p-2 rounded-lg"
                                ><svg class="size-4" aria-hidden="true"><use xlink:href="#icon_resave"></use></svg></button>
                                </div>
                            <span class="text-sm text-[var(--primary)] bg-[var(--btn-regular-bg)] p-2 rounded-lg"
                                x-text="colornum">250</span>
                        </div>

                        <div id="setcolor"
                            class="w-full h-6 px-1 bg-[oklch(0.80_0.10_0)] dark:bg-[oklch(0.70_0.10_0)] rounded select-none">
                            <input type="range" min="0" max="360"
                                class="cursor-pointer appearance-none bg-(image:--color-selection-bar) w-full h-6"
                                id="colorSlider" step="5" aria-label="主题色" x-model="colornum"
                                @change="document.cookie = 'colornum='+colornum+';path=/';"></div>
                    </div>
                </div>

                <button
                    class="rounded-lg p-2 hover:text-[var(--primary)] duration-300 hover:bg-[var(--btn-plain-bg-hover)] ml-2"
                    aria-label="网页深浅模式切换" type="button"
                    @click="dark=!dark;if(dark){document.cookie = 'dark=dark;path=/';}else{document.cookie = 'dark=light;path=/';}"><svg class="size-6 m-auto hidden dark:block" aria-hidden="true"><use xlink:href="#sun_fill"></use></svg>
                    <svg class="size-6 m-auto dark:hidden" aria-hidden="true"><use xlink:href="#moon_stars_fill"></use></svg></button>





<div class="flex items-center ml-2">


    <div x-data="{ dropdownOpen: false }" class="relative inline-block"
        @click.outside="dropdownOpen = false">
        <div class="flex items-center">
            
            <template x-if="!\$store.user.login">
            {$loginbtn}
            </template>
          

            <template x-if="\$store.user.login">
            <button @click="dropdownOpen=!dropdownOpen" class="relative rounded-full overflow-hidden">
            <span class="relative block">
                <img :src="\$store.user.img" alt="头像"
                    class="relative z-10 rounded-full size-6 lg:size-8 object-cover" loading="lazy">
                <img :src="\$store.user.wztx" alt="文字头像" loading="lazy"
                    class="absolute top-0 left-0 rounded-full size-6 lg:size-8 object-cover">
                    </span>
            </button>
            </template>
            
        </div>
        <div class="absolute right-0 z-20 w-48 py-2 mt-5 shadow-xl bg-white dark:bg-gray-800 rounded-lg rtl:right-auto rtl:left-0" x-cloak 
            x-show="dropdownOpen" x-transition:enter="transition ease-out duration-100 transform"
            x-transition:enter-start="opacity-0 scale-95"
            x-transition:enter-end="opacity-100 scale-100"
            x-transition:leave="transition ease-in duration-75 transform"
            x-transition:leave-start="opacity-100 scale-100"
            x-transition:leave-end="opacity-0 scale-95">
<template x-if="!\$store.user.login"><view>
            <button @click="login=true"
                class="mt-2 w-full px-4 py-2 text-sm duration-100 hover:bg-gray-100 dark:hover:bg-gray-700">
                登录
            </button>
            <button @click="register=true"
                class="mt-2 w-full px-4 py-2 text-sm duration-100 hover:bg-gray-100 dark:hover:bg-gray-700">
                注册
            </button>         
            </view></template>
<template x-if="\$store.user.login"><view>
            <a :href="\$store.user.url" class="flex items-center p-3 -mt-2 text-sm text-gray-600">
                <span class="flex-shrink-0 relative mx-1">
                    <img :src="\$store.user.img" :alt="\$store.user.name"
                        class="relative z-10 rounded-full size-10 object-cover" loading="lazy">
                    <img :src="\$store.user.wztx" alt="文字头像" loading="lazy"
                        class="absolute top-0 left-0 rounded-full size-10 object-cover">
                </span>
                <div class="mx-1">
                    <h1 class="text-sm font-semibold text-gray-700 dark:text-white "
                        x-text="\$store.user.name"></h1>
                    <p class="text-sm text-gray-500 dark:text-gray-300" x-text="\$store.user.mail">
                    </p>
                </div>
            </a>

            <hr class="border-gray-200 text-gray-600 dark:text-gray-400 dark:border-gray-500">

            <a :href="\$store.user.url"
                class="mt-2 block px-4 py-2 text-sm duration-100 hover:bg-gray-100 dark:hover:bg-gray-700">
                我的文章
            </a>

            <a :href="\$store.user.adminUrl" target="_blank" data-no-instant
                class="block px-4 py-2 text-sm duration-100 hover:bg-gray-100 dark:hover:bg-gray-700">
                进入后台
            </a>

            <a :href="\$store.user.logoutUrl" data-no-instant
                class="block px-4 py-2 text-sm duration-100 hover:bg-gray-100 dark:hover:bg-gray-700">
                登出
            </a>
</view></template>
        </div>
    </div>

</div>
            </div>
HTML;
?>
<div class="fixed inset-x-0 top-0 z-50 w-full bg-white shadow dark:bg-gray-900">

    <nav class="z-50 container max-w-6xl mx-auto font-bold relative">
        <div class="p-2 lg:p-3 lg:px-0 lg:-mx-4 flex items-center justify-between">
<div class="flex items-center">
        <button x-cloak @click="menu = !menu" type="button"
                    class="lg:hidden mr-2"
                    aria-label="菜单">
                <svg class="size-6" aria-hidden="true"><use xlink:href="#grid_fill"></use></svg>
        </button>
            <a href="<?php $this->options->siteUrl(); ?>" class="font-extrabold flex items-center transition-colors duration-300 transform rounded-lg lg:mr-5 <?php if($this->is('index')): ?>text-[var(--primary)] <?php else: ?>text-gray-700 dark:text-gray-200<?php endif; ?> hover:text-[var(--primary)]">
                <?php if($this->options->logo):?>
                <img class="w-auto h-6 sm:h-7 dark:hidden object-contain" src="<?php $this->options->logo(); ?>"
                    alt="logo">
                <img class="w-auto h-6 sm:h-7 hidden dark:block object-contain"
                    src="<?php if($this->options->darklogo){$this->options->darklogo();}else{ $this->options->logo();} ?>"
                    alt="logo">
                <?php else: ?>
                    <?php $this->options->title(); ?>
                <?php endif;?>
            </a>
</div>

<div class="flex-1 hidden lg:flex px-2 flex-row flex-wrap">
    
    
<?php
if (array_key_exists('ZeMenu', Typecho_Plugin::export()['activated'])&&!empty(ZeMenu_Plugin::zemenu())):
    $result=ZeMenu_Plugin::zemenu();
    $thisPageUrl=$this->request->getRequestUrl();
 ?>
<?php 
foreach ($result as $val){
$blank='';if($val['blank']==1){$blank=' target="_blank"';}
if(empty($val['son'])){
?>
<a href="<?php echo $val['a'];?>"
class="px-1 py-2 transition-colors duration-300 transform rounded-lg mx-2 <?php if(!$this->is('index')&&$thisPageUrl==$val['a']): ?>text-[var(--primary)] <?php else: ?>text-gray-700 dark:text-gray-200<?php endif; ?> hover:text-[var(--primary)]" <?php echo $blank;?>><?php echo $val['name'];?></a>

<?php }else{?>

<li class="group flex items-center list-none relative px-1 py-2 mx-2">
<div class="flex items-center transition-colors duration-300 transform hover:text-[var(--primary)]"><button><?php echo $val['name'];?></button><svg class="size-2 ml-0.5" aria-hidden="true"><use xlink:href="#down_small_fill"></use></svg></div>
<ul class="hidden group-hover:block duration-300 absolute z-50 top-full left-0 w-34 bg-white dark:bg-gray-900 shadow-lg rounded-lg py-2 ">
                <?php  foreach ($val['son'] as $xval){$blank='';if($xval['blank']==1){$blank=' target="_blank"';} ?>
<li class="list-none block px-3 py-1 transition-colors duration-300 transform rounded-lg mx-5 hover:text-[var(--primary)]">
<a href="<?php echo $xval['a'] ?>" <?php echo $blank;?> title="<?php echo $xval['name'] ?>"><?php echo $xval['name'] ?>
</a>
</li>
<?php } ?>
            </ul>
        </li>
<?php }} ?>
<?php else: ?>
    
    
    
    
<a href="<?php $this->options->siteUrl(); ?>"
                        class="px-1 py-2 transition-colors duration-300 transform rounded-lg mx-2 text-gray-700 dark:text-gray-200 hover:text-[var(--primary)]">首页</a>



<?php $this->widget('Widget_Metas_Category_List')->to($categorys); ?>
<?php while($categorys->next()): ?>
<?php if ($categorys->levels === 0): ?>
<?php $children = $categorys->getAllChildren($categorys->mid); ?>
<?php if (empty($children)) { ?>
<li class="list-none flex items-center">
<a class="px-1 py-2 transition-colors duration-300 transform rounded-lg mx-2 <?php if($this->is('category', $categorys->slug)): ?>text-[var(--primary)] <?php else: ?>text-gray-700 dark:text-gray-200<?php endif; ?> hover:text-[var(--primary)]" href="<?php $categorys->permalink(); ?>" title="<?php $categorys->name(); ?>"><?php $categorys->name(); ?></a>
</li>
<?php } else { ?>
<li class="group flex items-center list-none relative px-1 py-2 mx-2">
<div class="flex items-center transition-colors duration-300 transform hover:text-[var(--primary)]"><button><?php $categorys->name(); ?></button><svg class="size-2 ml-0.5" aria-hidden="true"><use xlink:href="#down_small_fill"></use></svg></div>

<ul class="hidden group-hover:block duration-300 absolute z-50 top-full left-0 w-34 bg-white dark:bg-gray-900 shadow-lg rounded-lg py-2 ">
<?php foreach ($children as $mid) { ?>
<?php $child = $categorys->getCategory($mid); ?>
<li class="list-none block px-3 py-1 transition-colors duration-300 transform rounded-lg mx-5 hover:text-[var(--primary)]">
<a href="<?php echo $child['permalink'] ?>" title="<?php echo $child['name']; ?>"><?php echo $child['name']; ?>
</a>
</li>
<?php } ?>
</ul></li>
<?php } ?><?php endif; ?><?php endwhile; ?>









                <li class="group flex items-center list-none relative px-1 py-2 mx-2">
                <div class="flex items-center transition-colors duration-300 transform hover:text-[var(--primary)]"><button>其他</button><svg class="size-2 ml-0.5" aria-hidden="true"><use xlink:href="#down_small_fill"></use></svg></div>
                <ul class="hidden group-hover:block duration-300 absolute z-50 top-full left-0 w-34 bg-white dark:bg-gray-900 shadow-lg rounded-lg py-2 ">
                <?php \Widget\Contents\Page\Rows::alloc()->to($pages); ?>
                    <?php if($pages->have()): ?>
                    <?php while ($pages->next()): ?>
                    <li class="list-none block px-3 py-1 transition-colors duration-300 transform rounded-lg mx-5 hover:text-[var(--primary)]">
                    <a href="<?php if($pages->fields->url){$pages->fields->url();}else{$pages->permalink();} ?>"
                        <?php if($pages->fields->url){echo 'target="_blank"';}?>
                        ><?php $pages->title(); ?></a>
                    </li>
                    <?php endwhile; ?>
                    <?php endif; ?>
                </ul>
                 </li>

<?php endif; ?>      

                </div>



 <?php echo $right;?>

        </div>
    </nav>

</div>

<?php $this->need('mobilemenu.php');?>