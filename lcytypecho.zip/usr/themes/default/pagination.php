<?php 
$can="";
if($this->request->get('cat')){
$can="?cat=".$this->request->get('cat');
}
$this->pageNav(
    '<svg class="size-5" aria-hidden="true"><use xlink:href="#left_fill"></use></svg>', 
    '<svg class="size-5 rotate-180" aria-hidden="true"><use xlink:href="#left_fill"></use></svg>',2, '...', 
    'wrapTag=div&wrapClass=flex&itemTag=&aClass=hidden px-4 py-2 mx-1 text-gray-700 transition-colors duration-300 transform bg-white rounded-md sm:inline dark:bg-gray-800 dark:text-gray-200 hover:bg-[var(--btn-regular-bg)] hover:text-[var(--btn-content)] dark:hover:text-gray-200
    &textClass=hidden px-4 py-2 mx-1 text-gray-700 transition-colors duration-300 transform bg-white rounded-md sm:inline dark:bg-gray-800 dark:text-gray-200
    
    &currentClass=flex items-center justify-center px-4 py-2 mx-1 text-[var(--btn-content)] capitalize rounded-md rtl:-scale-x-100 bg-[var(--btn-regular-bg-hover)] duration-300
    
    &prevClass=flex items-center justify-center px-4 py-2 mx-1 text-gray-700 transition-colors duration-300 transform bg-white rounded-md dark:bg-gray-800 dark:text-gray-200 hover:bg-[var(--btn-regular-bg)] hover:text-[var(--btn-content)] dark:hover:text-gray-200
    
    &nextClass=flex items-center justify-center px-4 py-2 mx-1 text-gray-700 transition-colors duration-300 transform bg-white rounded-md dark:bg-gray-800 dark:text-gray-200 hover:bg-[var(--btn-regular-bg)] hover:text-[var(--btn-content)] dark:hover:text-gray-20&can='.$can); ?>