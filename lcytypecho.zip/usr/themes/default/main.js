 //复制按钮
 let clipboard = new ClipboardJS('.copybtn');
 clipboard.on('success', function(e) {
     console.log('复制成功');
 main.notice('success','复制成功！');
     e.clearSelection();
 });
 clipboard.on('error', function(e) {
 main.notice('error','复制失败！');
 });

document.addEventListener('alpine:init', () => {
main.alpine();
Alpine.store('user', {
    init() {
        main.infoget();
    },
    login: false,
    register: false,
    img:ze.theme_url+'/img/tx.png',
    wztx:ze.theme_url+'/img/tx.png',
    uid:-1,
    name:'登录',
    mail:false,
    group:'luren',
    url:'javascript:void(0);',
    adminUrl:false,
    logoutUrl:false,
    ucenter:false,
});
    });
        
window.main = {};

main.alpine=function(){

    Alpine.store('info', {
        init(){
            main.upcateicon();
            main.comment();
        },
        search:'',
        searchtype:'',
        cateicon:ze.theme_url+'/img/null.gif',
        comment:false,
        view:0,
        zan:0,
        comnum:0,
        write:0
    });
}
main.init = function () {


var pres = document.querySelectorAll("pre");
  if (document.getElementById("post")){
      for (var i = 0; i < pres.length; i++) {
        var t = pres[i].getElementsByTagName("code")[0].textContent;
        var btn = document.createElement("button");
btn.classList.add("copy","dark:text-white","absolute","top-0","right-0","p-2","text-xs");
btn.setAttribute("data-clipboard-text", t.trim());
btn.setAttribute("aria-label", "复制");
	var textnode=document.createTextNode("");
	btn.appendChild(textnode)
	pres[i].insertBefore(btn,pres[i].childNodes[0]);
          var c = new ClipboardJS(btn);
          c.on('success', function(e) {
              e.trigger.classList.add('copyed');
              setTimeout(() => {e.trigger.classList.remove('copyed');}, 2000);
              e.clearSelection();
          });
          c.on('error', function(e) {
              e.trigger.classList.add('copyerror');
          });
      }
}


window.addEventListener("scroll",function () {
    var topbtn = document.querySelector('#widget-to-top');
   let a = document.documentElement.scrollTop || window.pageYOffset,
   b = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, document.body.offsetHeight, document.documentElement.offsetHeight, document.body.clientHeight, document.documentElement.clientHeight) - document.documentElement.clientHeight,
result = Math.round(a / b * 100);
if(result == 0) result = '';
if(result == 100) result = '100';
result >= 1 ? topbtn.classList.remove("hidden") : topbtn.classList.add("hidden");

if(result > 0) {
    if(result<=90){
        document.querySelector('#widget-to-top .up').classList.add('hidden');
        document.querySelector('#widget-to-top .num').classList.remove('hidden');
        document.querySelector('#widget-to-top .num').innerHTML=result+'%';
    }else{
        document.querySelector('#widget-to-top .num').classList.add('hidden');
        document.querySelector('#widget-to-top .up').classList.remove('hidden');
    }
}
});
}


main.swiper =function () {
    var mySwiper = new Swiper('.swiper-container', {
        // direction: 'horizonal',
        slidesPerView: 'auto', // 或者你可以设置一个具体的数字，例如 '3'
        spaceBetween: 20,      // 滑块之间的间距
        centeredSlides: true,
        loop: true,
        autoplay: {
            delay: 3000,   // 轮播间隔时间
            stopOnLastSlide: false,
            disableOnInteraction: false,
            
        },
        // 如果需要分页器
        pagination: {
            el: '.swiper-pagination',
            clickable:true
        },

        // 如果需要前进后退按钮
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },

        // 如果需要滚动条
        scrollbar: {
            el: '.swiper-scrollbar',
        },
    })
}
//原生js多功能提示框
main.sinnertips = function(html,type='max-w-xs'){
    var con = html;
	var html = 	`<section class="sinner-tips sitips-open">
	<div class="fixed inset-0 z-50 flex items-end backdrop-blur-md bg-black/30 sm:items-center sm:justify-center"></div>
	<div class="scale-101 fixed top-0 left-0 z-50 flex justify-center justify-items-center items-center w-full h-full border dark:border-gray-600">
    <div x-data="{k:0}" @click.outside="k++;if(k>1){main.closetips()}" class="tips-body rounded bg-gray-50 shadow dark:text-white dark:bg-gray-600">
    <div class="rounded-t py-2 bg-luhead bg-gray-100 dark:bg-gray-800"><div class="mx-2 text-right"><button class="size-3 bg-gray-300 rounded-full mx-1 focus:outline-none"></button><button class="size-3 bg-gray-300 rounded-full mx-1 focus:outline-none"></button><button class="size-3 bg-gray-300 rounded-full mx-1 focus:outline-none"></button></div></div>
    <div class="text-center p-5"><div class="px-3 dark:text-gray-100 dark:border-gray-400">`+con+`</div></div><div class="btn-close-tips"><button @click="main.closetips()" class="mx-auto text-red-500 p-2 bg-white dark:bg-gray-700 rounded-full"><svg class="size-6" aria-hidden="true"><use xlink:href="#close_fill"></use></svg></button>
			</div></div></div></section>`;
document.body.insertAdjacentHTML('beforeend',html);
}

main.closetips=function(){
    [].slice.call(document.querySelectorAll('.btn-close-tips')).forEach(function (closebtn) {
   var c=closebtn.parentNode.parentNode.parentNode;
   c.classList.remove('sitips-open');
   c.classList.add('sitips-close');
   setTimeout(function(){
   c.classList.remove('sitips-close');
   c.remove();
           },400);
   });
}

//打赏
main.reward=function(obj) {
    var wximg = obj.getAttribute('data-wx');
    var tbimg = obj.getAttribute('data-tb');
    var title = obj.getAttribute('data-title');
    var wxdesc = obj.getAttribute('data-desc');
    var tbdesc = obj.getAttribute('data-desc2');
    var html = '<div class="text-center"><input type="radio" name="tab" id="wxpay" class="hidden" checked><input type="radio" name="tab" id="alipay" class="hidden"><h6 class="mb-2 font-bold">'+title+'</h6>\
<img class="wx-img hidden size-56 rounded" src="' + wximg + '" alt="' + title + '">\
<img class="tb-img hidden size-56 rounded" src="' + tbimg + '" alt="' + title + '">\
<div class="inline-block px-2 py-3  mt-2 text-sm rounded-full bg-gray-300 dark:bg-gray-500"><label for="wxpay"><span class="btn-wx cursor-pointer rounded-full py-2 px-3">'+wxdesc+'</span></label><label for="alipay"><span class="btn-wx cursor-pointer rounded-full py-2 px-3">'+tbdesc+'</span></label></div>\
</div>';
    main.sinnertips(html);
}

//分享
main.share=function(obj) {
    var url = obj.getAttribute('data-url');
    var title = obj.getAttribute('data-title');
    var img = obj.getAttribute('data-img');
    var code = obj.getAttribute('data-code');
    var html = `
    <div class="flex">
                    <div class="mr-3">
                        <img src="`+code+`" alt="文章二维码" class="postQrcode size-36 rounded">
                    </div>
                    <div class="flex flex-col py-3 justify-start text-left dark:text-gray-200">
                        <a href="https://service.weibo.com/share/share.php?url=`+url+`&title=`+title+`&appkey=&pic=`+img+`&searchPic=true"
                            class="duration-300 hover:text-[var(--primary)] mb-1.5" target="_blank">分享到微博</a>
                        <a href="https://twitter.com/intent/tweet?url=`+url+`&text=嘿，我发现了一篇宝藏文章「`+title+`」，快来看看吧！&via="
                            class="duration-300 hover:text-[var(--primary)] mb-1.5" target="_blank">分享到Twitter</a>
                        <a href="https://telegram.me/share/url?url=`+url+`&text=嘿，我发现了一篇宝藏文章「`+title+`」，快来看看吧！"
                            class="duration-300 hover:text-[var(--primary)] mb-1.5" target="_blank">分享到Telegram</a>
                        <button class="copybtn text-left" data-clipboard-action="copy" data-clipboard-text="`+title+`\n`+url+`">复制文章链接</button>
                    </div>
</div>
    `;
    main.sinnertips(html);


}


main.notice = function(type='success',text='',time=1800){
    var tip=`<div class="px-6 lg:w-96 lg:px-0 my-1">
                <div class="p-2 bg-green-500 rounded-lg shadow-lg sm:p-3">
                    <div class="flex items-center justify-between text-white">
                        <div class="flex items-center flex-1">
                            <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            <p class="mx-3 font-medium">${text}</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
    if(type=="error"){
    tip=` <div class="px-6 lg:w-96 lg:px-0 my-1">
            <div class="p-2 bg-red-500 rounded-lg shadow-lg sm:p-3">
                <div class="flex items-center justify-between text-white">
                    <div class="flex items-center flex-1">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg> <p class="mx-3 font-medium">${text}</p>
                    </div>
                </div>
            </div>
        </div>`;
        }
    if(!document.querySelector('#notice')){
    const html=`<div id="notice" class="z-[60] transition-transform fixed top-3 right-0 pr-3 translate-x-full"></div>`;
     // 假设插入到body的尾部
    document.body.insertAdjacentHTML('beforeend', html);
    }
    
    let con = document.createElement("div");
        con.innerHTML = tip;
        document.querySelector('#notice').append(con);
        document.querySelector('#notice').classList.remove('translate-x-full');
    
     // 设置定时器，x秒后移除刚才插入的HTML
     setTimeout(function() {
        document.querySelector('#notice').classList.add('translate-x-full');
        setTimeout(function() {
        con.remove(); // 移除
        }, 150);
     }, time);
    
    }

main.upcateicon=function(){
    let cateicon = document.getElementById('cateicon');

    if(cateicon){
        Array.from(document.querySelectorAll('.cateicon')).forEach(cateicon => {  
            let id=cateicon.getAttribute('data-mid');
            let type=cateicon.getAttribute('data-type');

            main.cateicon(id,type);
            cateicon.addEventListener('change', function(e) {
              // 获取选中的文件
              var file = e.target.files[0];
            
              // 创建FormData对象，用于发送文件数据
              var formData = new FormData();
              formData.append('image', file);
              formData.append('name', id);
            
              // 创建XMLHttpRequest对象，用于发送文件数据
              var xhr = new XMLHttpRequest();
            
              // 监听上传进度事件
              xhr.upload.addEventListener('progress', function(e) {
                if (e.lengthComputable) {
                  var percent = Math.round((e.loaded / e.total) * 100);
                  console.log('上传进度：' + percent + '%');
                }
              });
            
              // 监听上传完成事件
              xhr.addEventListener('load', function(e) {
                var response = JSON.parse(xhr.responseText);
                if(response.status==0){
                    main.notice('error',response.msg);

                }else{
                    main.notice('success','上传完成！');
                }
                main.cateicon(id,type);
              });
            
              // 监听上传错误事件
              xhr.addEventListener('error', function(e) {
                console.log('上传错误');
                main.notice('error','上传出错！');
              });
            
              // 设置请求方法、URL和是否异步
              xhr.open('POST', ze.url+'?api=upload&type='+type, true);
            
              // 发送文件数据
              xhr.send(formData);
            });
    });
    }
}

main.cateicon=function(id,type="cate"){
        if(type=="avatar"){
            fetch(ze.url+'?api=cateicon&mid='+id+'&type='+type) .then(response => response.json()).then(data => {
                document.getElementById('avatar').src=data.img;
                main.infoget();
            });
        }else{
        fetch(ze.url+'?api=cateicon&mid='+id+'&type='+type) .then(response => response.json()).then(data => {
            Alpine.store('info').cateicon=data.img;
        });
    }
}

main.infoget = function(){
    var url=ze.url;
    fetch(url+'?api=info') .then(response => response.json()).then(data => {
        Alpine.store('user').login=data.login;
        Alpine.store('user').register=data.register;
        if(data.login==1){
            Alpine.store('user').uid=data.user.uid;
            Alpine.store('user').name=data.user.name;
            Alpine.store('user').img=data.user.img;
            Alpine.store('user').wztx=data.user.wztx;
            Alpine.store('user').url=data.user.url;
            Alpine.store('user').mail=data.user.mail;
            Alpine.store('user').group=data.user.group;
            Alpine.store('user').adminUrl=data.user.adminUrl;
            Alpine.store('user').ucenter=data.user.ucenter;
            Alpine.store('user').logoutUrl=data.user.logoutUrl;
            
            }
    });
}
main.login = function () {
    /*ajax登陆*/
    var login=document.getElementById("login");
    login.addEventListener("submit", function (event) {
            event.preventDefault();
            var submit = document.querySelector('#loginbtn');
            var buttonhtml = submit.innerHTML;
            submit.setAttribute('disabled', 'disabled');
            submit.innerHTML = '<svg class="animate-spin h-5 w-5 text-white m-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>';

            const formData = new FormData(login); 
            var url = ze.url+'?api=login';

            fetch(url, { method: "POST",headers: {'X-Requested-With': 'XMLHttpRequest'},body:formData }) .then(response => response.json()).then(data => {
                if(data.status==1){
                    document.querySelector('#tczhezhao').click();
                    main.notice('success','登录成功！');
                    main.infoget();
                    main.ajaxpost();
                    main.comment();
                }else{
                    main.notice('error','账户名或密码错误，登录失败！');
                    submit.disabled = '';
                    submit.innerHTML = buttonhtml;
                }
            });
        });
}

main.register = function () {
    /*ajax注册*/
    var register=document.getElementById("register");
    if(register){
    register.addEventListener("submit", function (event) {
            event.preventDefault();
            var submit = document.querySelector('#registerbtn');
            var buttonhtml = submit.innerHTML;
            submit.setAttribute('disabled', 'disabled');
            submit.innerHTML = '<svg class="animate-spin h-5 w-5 text-white m-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>';

            const formData = new FormData(register); 
            var url = ze.url+'?api=register';

            fetch(url, { method: "POST",headers: {'X-Requested-With': 'XMLHttpRequest'},body:formData }) .then(response => response.json()).then(data => {
                if(data.status==1){
                    document.querySelector('#tczhezhao').click();
                    main.notice('success','注册成功！');
                    main.infoget();
                }else{
                    main.notice('error',data.msg);
                    submit.disabled = '';
                    submit.innerHTML = buttonhtml;
                }
            });
        });
    }
}


main.ziliao = function () {
    /*ajax登陆*/
    var ziliao=document.getElementById("ziliao");
    if(ziliao){
    ziliao.addEventListener("submit", function (event) {
            event.preventDefault();
            var submit = document.querySelector('#ziliaobtn');
            var buttonhtml = submit.innerHTML;
            submit.setAttribute('disabled', 'disabled');
            submit.innerHTML = '<svg class="animate-spin h-5 w-5 text-white m-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>';
            const formData = new FormData(ziliao); 
            var url = ze.url+'?api=ziliao';
            fetch(url, { method: "POST",body:formData }) .then(response => response.json()).then(data => {
                if(data.status==1){
                    document.querySelector('#tczhezhao').click();
                    main.notice('success',data.msg);
                    main.infoget();
                }else{
                    main.notice('error',data.msg);
                }
                submit.disabled = '';
                submit.innerHTML = buttonhtml;
            });
        });
    }
}


main.mima = function () {
    /*ajax登陆*/
    var mima=document.getElementById("mima");
    if(mima){
    mima.addEventListener("submit", function (event) {
            event.preventDefault();
            var submit = document.querySelector('#mimabtn');
            var buttonhtml = submit.innerHTML;
            submit.setAttribute('disabled', 'disabled');
            submit.innerHTML = '<svg class="animate-spin h-5 w-5 text-white m-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>';
            const formData = new FormData(mima); 
            var url = ze.url+'?api=mima';
            fetch(url, { method: "POST",body:formData }) .then(response => response.json()).then(data => {
                if(data.status==1){
                    document.querySelector('#tczhezhao').click();
                    main.notice('success',data.msg);
                    main.infoget();
                }else{
                    main.notice('error',data.msg);
                }
                submit.disabled = '';
                submit.innerHTML = buttonhtml;
            });
        });
    }
}

main.top =function(){
        var d = document,dd = document.documentElement,db = document.body,top = dd.scrollTop || db.scrollTop,step = Math.floor(top / 20);
        (function() {top -= step;if (top > -step) {dd.scrollTop == 0 ? db.scrollTop = top: dd.scrollTop = top;setTimeout(arguments.callee, 20);}})();
} 
//文章密码ajax提交
main.password = function () {
    var passwordform = document.querySelector(".protected");
    if (passwordform) {
        passwordform.addEventListener("submit", function (event) {
            document.querySelector(".protected .submit").value = '提交中...';
            event.preventDefault();
            var surl = this.getAttribute('action');
            const formData = new FormData(passwordform);  
            fetch(surl, { method: "POST",body:formData }).then(data => data.text()).then(data => {
                if (data.indexOf('name="protectPassword"') >= 0 || data.indexOf("您输入的密码错误") >= 0) {
                    document.querySelector(".protected .submit").value = '提交';
                    main.notice('error','密码错误，请重试！');
                } else {
                    main.notice('success','密码正确，请等待页面刷新！');
                    let zhongzhuan = document.createElement("div");
                    zhongzhuan.innerHTML = data;
                    Array.from(document.querySelectorAll('.posttitle')).forEach(posttitle => {  
                    posttitle.innerHTML = zhongzhuan.querySelector(".posttitle").innerHTML;
                    });
                    document.querySelector(".markdown-section").innerHTML = zhongzhuan.querySelector(".markdown-section").innerHTML;
                    main.ajaxcommentfinish();
                }
            });
        });
    }
}


main.ajaxpost =function(){
    if(document.querySelector("#post")){
        fetch(globals.post_url).then(response => response.text()).then(data=>{ 
            let zhongzhuan = document.createElement("div");
            zhongzhuan.innerHTML = data;
            Array.from(document.querySelectorAll('.posttitle')).forEach(posttitle => {  
            posttitle.innerHTML = zhongzhuan.querySelector(".posttitle").innerHTML;
            });
            document.querySelector(".markdown-section").innerHTML = zhongzhuan.querySelectorAll(".markdown-section")[0].innerHTML;
    });
    }
}

main.comment = function(){
    if(document.querySelector("#post")){
        fetch(globals.post_url+'?cid='+globals.post_id+'&api=like').then(response => response.json()).then(data=>{
            Alpine.store('info').view=data.view;
            Alpine.store('info').zan=data.likenum;
            Alpine.store('info').comnum=data.comnum;
            Alpine.store('info').write=data.write;
        });
    fetch(globals.post_url+'?api=comment').then(response => response.text()).then(data=>{ Alpine.store('info').comment=data;setTimeout(function() {main.ajaxcomment();}, 800);});
    }
}
main.LoadCommentList = function (url) {
  // 发送AJAX请求获取更多HTML
  var request = new XMLHttpRequest();
  request.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      // 解析响应数据
      var response = this.responseText;
      // 取出当前页的内容
      var div = document.createElement("div");
      div.innerHTML = response;
      var items = div.querySelector(".comment-list").innerHTML;
      // 渲染当前页的内容
        var list =  document.querySelector(".comment-list");
            list.insertAdjacentHTML('beforeend',items);
      // 判断是否还有更多内容
      if (div.querySelector("#loadMoreBtn")) {
          //如果有替换翻页按钮
          const oldContent=document.querySelector("#loadMoreBtn")
          const newContent=div.querySelector("#loadMoreBtn");
          oldContent.parentNode.replaceChild(newContent, oldContent);
          window.ViewImage && ViewImage.init('.post-content img, .post-comment img, .post-comment a.view-image');
      }else{
          //如果没有则输出提醒
          const oldContent=document.querySelector("#loadMoreBtn")
          const newContent=document.createElement('div');
          newContent.textContent = '😜已经没有了~';
          oldContent.parentNode.replaceChild(newContent, oldContent);
      }
      main.all();//重置函数
    }
  };
  request.open("GET", url, true);
  request.send();
}
main.deleteCookie = function (name) {
    document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; domain="+ze.domain+"; path=/;";
  }
main.getCookie = function(name) {
  var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
  if(arr = document.cookie.match(reg)){return unescape(arr[2]);}else{return null;}
  }


main.windows = function () {
    if (navigator.userAgentData) {
        navigator.userAgentData.getHighEntropyValues(["platformVersion"])
            .then(ua => {
                if (navigator.userAgentData.platform === "Windows") {
                    const majorPlatformVersion = parseInt(ua.platformVersion.split('.')[0]);
                    if (majorPlatformVersion >= 13) {
                        document.cookie = "win11=true;path=/";
                    }
                }
            });
    }
}


main.search  = function () {
    Array.from(document.querySelectorAll('.search-form')).forEach(searchForm => {  
        searchForm.addEventListener("submit", function (event) {  
            event.preventDefault();
            var cat='';
            if(Alpine.store('info').searchtype){cat='?cat='+Alpine.store('info').searchtype;}
            var url=ze.url+ze.rewrite+'search/'+encodeURIComponent(Alpine.store('info').search)+'/'+cat;
            InstantClick.insa(url);
    });
});
}

main.ajaxcomment = function () {
    window.TypechoComment = {
        dom: function(id) {
            return document.getElementById(id)
        },
        pom: function(id) {
            return document.getElementsByClassName(id)[0]
        },
        iom: function(id, dis) {
            var alist = document.getElementsByClassName(id);
            if (alist) {
                for (var idx = 0; idx < alist.length; idx++) {
                    var mya = alist[idx];
                    mya.style.display = dis
                }
            }
        },
        create: function(tag, attr) {
            var el = document.createElement(tag);
            for (var key in attr) {
                el.setAttribute(key, attr[key])
            }
            return el
        },
        reply: function(cid, coid) {
            var comment = this.dom(cid),
            parent = comment.parentNode,
            response = this.dom(globals.respondId),
            input = this.dom("comment-parent"),
            form = "form" == response.tagName ? response: response.getElementsByTagName("form")[0],
            textarea = response.getElementsByTagName("textarea")[0];
            if (null == input) {
                input = this.create("input", {
                    "type": "hidden",
                    "name": "parent",
                    "id": "comment-parent"
                });
                form.appendChild(input)
            }
            input.setAttribute("value", coid);
            if (null == this.dom("comment-form-place-holder")) {
                var holder = this.create("div", {
                    "id": "comment-form-place-holder"
                });
                response.parentNode.insertBefore(holder, response)
            }
            comment.appendChild(response);
            this.iom("comment-reply", "");
            this.pom("cp-" + cid).style.display = "none";
            this.iom("cancel-comment-reply", "none");
            this.pom("cl-" + cid).style.display = "";
            if (null != textarea && "text" == textarea.name) {
                textarea.focus()
            }
            return false
        },
        cancelReply: function() {
            var response = this.dom(globals.respondId),
            holder = this.dom("comment-form-place-holder"),
            input = this.dom("comment-parent");
            if (null != input) {
                input.parentNode.removeChild(input)
            }
            if (null == holder) {
                return true
            }
            this.iom("comment-reply", "");
            this.iom("cancel-comment-reply", "none");
            holder.parentNode.insertBefore(response, holder);
            return false
        }
    }
    //评论表情初始化
    if (document.getElementsByClassName('OwO')[0]) {
        var biaoqingapi = ze.theme_url + 'assets/OwO.json?2024';
        if (ze.biaoqing.length > 1) { biaoqingapi = ze.biaoqing; }
        var OwO_demo = new OwO({
            container: document.getElementsByClassName('OwO')[0],
            target: document.getElementsByClassName('OwO-textarea')[0],
            api: biaoqingapi,
            position: 'down',
            width: '66vw',
            maxHeight: '250px'
        });
    }

    //隐私评论交互
    var PrivateComments = document.getElementById("PrivateComments");
    if (PrivateComments) {
        var holder = document.getElementById("comment").getAttribute('placeholder');
        PrivateComments.addEventListener('change', function () {
            if (PrivateComments.checked) {
                document.getElementById("comment").setAttribute("placeholder", "正在隐私评论中...");
            } else {
                document.getElementById("comment").setAttribute("placeholder", holder);
            }
        });
    }


    /*ajax评论*/
    //监听评论表单提交
    [].slice.call(document.querySelectorAll('.comment-form')).forEach(function (commentform) {
        commentform.addEventListener("submit", function (event) {
            event.preventDefault();
            var parent=0;

            const formData = new FormData(commentform);  
            var params = 'themeAction=comment';
            var buttonhtml = document.querySelector('#submit').innerHTML;
            // 解析新评论并附加到评论列表
            var appendComment = function (comment) {
                // 评论列表
                var el = document.querySelector('#comments > .comment-list');
                var pl = " comment-parent";
                if (0 != comment.parent) {
                    parent=comment.parent;
                    pl = " children";
                    // 子评论则重新定位评论列表
                    var el = document.querySelector('#li-comment-' + comment.parent);
                    // 父评论不存在子评论时
                    if (el.querySelectorAll('.comment-list').length < 1) {
                        el.insertAdjacentHTML('beforeend', '<ol class="comment-list"></ol>');
                    }
                    el = document.querySelector('#li-comment-' + comment.parent + ' .comment-list');
                }
                if (!el) {//如果是第一次评论
                    document.querySelector('#comments').insertAdjacentHTML('beforeend', '<ol class="comment-list"></ol>');
                    el = document.querySelector('#comments > .comment-list');
                }
                // 评论html模板，根据具体主题定制
            var html = '<div id="div-comment-' + comment.coid + '" class="comment-body' + pl + ' comment-ajax"><article id="div-comment-' + comment.coid + '" class="flex comment-body my-4 py-md-2"><div class="flex-none mr-1"><div class="relative"><img no-view="" class="relative z-10 size-12 object-cover border-2 border-gray-200 rounded-full scrollLoading mr-1" src="' + comment.avatar + '"><img no-view="" class="absolute top-0 left-0 size-12 object-cover border-2 border-gray-200 rounded-full scrollLoading mr-1" src="' + comment.tx + '"></div></div><div class="flex-initial w-full text-sm"><div class="comment-author mb-1"><div class="flex items-center"><a href="' + comment.permalink + '" target="_blank" rel="external nofollow">' + comment.author + '</a>' + comment.sf + '<span class="mx-1"></span></div></div><div class="comment-content px-4 py-2 rounded bg-slate-100 text-gray-900 dark:bg-gray-700 dark:text-gray-100">' + comment.content + '</div><div class="flex items-center comment-meta text-xs text-gray-500 mt-1"><time class="mr-1">刚刚</time><span class="text-muted">' + comment.status + '</span></div></div></article></div>';
            
                el.insertAdjacentHTML('afterbegin', html);
            };
            // ajax提交评论
            var submit = document.querySelector('#submit');
            submit.setAttribute('disabled', 'disabled');
            submit.innerHTML = '<svg class="animate-spin size-5 text-white m-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>';

            fetch(globals.post_url + "?" + params, { method: "POST",body:formData }).then(data => data.json()).then(data => {
                if (data.status == 1) {
                    appendComment(data.comment);
                    document.querySelector('#comment').value = '';
                    if(document.querySelector('#nocomment')){
                      document.querySelector('#nocomment').remove();  
                    }
                    TypechoComment.cancelReply();
                    main.notice('success','评论已成功提交！');
                } else {
                    var tishi = undefined === data.msg ? '评论返回数据异常' : data.msg;
                    main.notice('error',tishi);
                }

                submit.disabled = '';
                submit.innerHTML = buttonhtml;
            })
            .catch(error => {
              console.error('Error during fetch:', error);
              main.notice('success', '已提交，请刷新页面！');
            })
            .finally(() => {
              submit.disabled = '';
              submit.innerHTML = buttonhtml;
            });

            return false;
        });
    });
}



main.lines=function(){
    var linescon=document.querySelectorAll("pre code");
    if(linescon){
    linescon.forEach((value, index) => {if(linescon[index].querySelectorAll("ul li").length<=0){
    var c=linescon[index].innerHTML;
    linescon[index].innerHTML="<ul><li>" + c.replace(/\n/g,"\n</li><li>") +"\n</li></ul>";}
    });
    }
      }
main.lunbo=function(){
    var lunbo=document.getElementById("myCarousel");
    if(lunbo){
    new Carousel(lunbo, {Autoplay : {timeout : 3000,}}, {
        Autoplay
      });
}}
main.fancybox=function(){
    //图片灯箱初始化
    cn={
      CLOSE: "关闭",
      NEXT: "下一张",
      PREV: "上一张",
      MODAL: "您可以使用 ESC 键关闭此模式",
      ERROR: "出现错误，请稍后再次尝试",
      IMAGE_ERROR: "未找到图片",
      ELEMENT_NOT_FOUND: "找不到 HTML 内容",
      AJAX_NOT_FOUND: "AJAX 加载错误：未找到",
      AJAX_FORBIDDEN: "AJAX 加载错误：禁止",
      IFRAME_ERROR: "加载页面时出错",
      TOGGLE_ZOOM: "缩放",
      TOGGLE_THUMBS: "切换缩略图",
      TOGGLE_SLIDESHOW: "播放/暂停幻灯片",
      TOGGLE_FULLSCREEN: "切换全屏模式",
      DOWNLOAD: "下载",
    };
    var fancybox=document.querySelectorAll(".fancycon img");
    if(fancybox){
    fancybox.forEach((value, index) => {
    var element = document.createElement("a");
    if(fancybox[index].getAttribute('src')){
    if(!fancybox[index].parentElement.getAttribute('href')&&fancybox[index].getAttribute('src').indexOf('/TePass')<0&&!fancybox[index].getAttribute("nofancybox")){
    element.setAttribute("data-src", fancybox[index].getAttribute('src'));   
    if(fancybox[index].getAttribute('data-url')){
    element.setAttribute("data-src", fancybox[index].getAttribute('data-url'));    
    }
    element.setAttribute("data-fancybox", "gallery");
    element.setAttribute("data-caption", fancybox[index].getAttribute('alt'));
    element.setAttribute("title", fancybox[index].getAttribute('alt'));
    fancybox[index].parentNode.insertBefore(element, fancybox[index]);
    fancybox[index].parentNode.removeChild(fancybox[index]);
    element.appendChild(fancybox[index]);
    }
    }
    });}
    Fancybox.defaults.l10n = cn;
    Fancybox.bind("[data-fancybox]", {
       Toolbar: {
          display: {
            left: ["infobar",],
            middle: [
              "zoomIn",
              "zoomOut",
              "toggle1to1",
              "rotateCCW",
              "rotateCW",
            ],
            right: ["slideshow", "thumbs", "close"],
          },
        },
      });
    }


    main.all = function(){
        main.init();
        main.search();
        main.windows();
        main.password();
        main.login();
        main.ziliao();
        main.mima();
        main.swiper();
        main.fancybox();
        main.lunbo();
        main.lines();
        hljs.highlightAll();
    }
    main.all();