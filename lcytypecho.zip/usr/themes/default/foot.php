<div class="footer px-5 py-3 w-full mx-auto bg-white dark:bg-gray-900">
                <p class="text-center text-gray-800 dark:text-gray-400"> <?php echo date('Y'); ?> © 不见桃花不见秋 By <a
                    href="https://lcy20.netlify.app/" target="_blank" rel="noopener noreferrer">归档-时光卷轴强力支持</a>
                <?php $this->options->footer(); ?></p>
</div>