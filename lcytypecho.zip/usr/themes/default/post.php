<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
?>

<script type='text/javascript'>/* <![CDATA[ */
var globals = {"post_id":"<?php $this->cid(); ?>","post_url":"<?php $this->permalink(); ?>","respondId":"<?php $this->respondId(); ?>"};
/* ]]> */</script>

<article id="post"
x-data="{type:false,zishu:0,read:0}" 
x-init="id='<?php $this->cid(); ?>';storage = window.localStorage;if(storage.getItem('like_'+id)){type=true;}"
 class="w-full break-all overflow-hidden">
 <div class="bg-white dark:bg-gray-900 p-5 rounded-lg shadow">

 <div class="flex items-center mx-2 text-xs text-gray-400 dark:text-gray-400">
 <svg class="bg-black/5 dark:bg-white/10 size-6 p-1 rounded-lg" aria-hidden="true"><use xlink:href="#align_left_line"></use></svg>

 <span x-text="zishu">0</span> 字 
<svg class="bg-black/5 dark:bg-white/10 size-6 p-1 rounded-lg mr-1 ml-3" aria-hidden="true"><use xlink:href="#time_line"></use></svg>
<span x-text="read">0</span> 分钟</div>

<h1 class="posttitle font-medium  text-lg lg:text-2xl dark:hover:text-[var(--primary)] hover:text-[var(--primary)] duration-300 line-clamp-2 my-2 flex items-center"><span class="bg-[var(--primary)] h-4 w-1 rounded-full mr-2"></span><?php $this->title();?></h1>


<div class="mx-2 flex items-center flex-wrap text-sm text-black/70 dark:text-white/70 line-clamp-1 mb-3">
<span class="bg-[var(--btn-regular-bg)] text-[var(--btn-content)]  p-2 rounded-lg mr-1">
<svg class="size-4" aria-hidden="true"><use xlink:href="#calendar_fill"></use></svg></span><span class="mr-2">
<?php $this->date('Y-m-d'); ?></span>

<?php if($this->is('post')): ?>
<span class="bg-[var(--btn-regular-bg)] text-[var(--btn-content)] p-2 rounded-lg mr-0.5"><svg class="size-4" aria-hidden="true"><use xlink:href="#hashtag_fill"></use></svg>
</span><span class="rounded-lg p-2 duration-300 hover:text-[var(--primary)] hover:bg-[var(--btn-plain-bg-hover)]"><?php $this->category('</span>/<span class="rounded-lg p-2 duration-300 hover:text-[var(--primary)] hover:bg-[var(--btn-plain-bg-hover)]">'); ?></span><?php endif;?>


<a :href="$store.info.write" class="flex items-center text-[var(--primary)] ml-2"  target="_blank" x-show="$store.info.write" x-cloak>
<span class="bg-[var(--btn-regular-bg)] text-[var(--btn-content)]  p-2 rounded-lg mr-1">    
<svg class="size-4" aria-hidden="true"><use xlink:href="#edit_3_fill"></use></svg>
</span>编辑</a>
</div>

<div id="printSection" class="fancycon break-all markdown-section !mx-2"> 
<?php
$this->content=buju($this->content);
$this->content=createCatalog($this->content);
$this->content=setshortcode($this->content,$this);
$this->content();
$zishu=mb_strlen($this->content); 
?>
<?php if (array_key_exists('TePass', Typecho_Plugin::export()['activated'])){echo TePass_Plugin::getTePass();} ?>
</div>
<span x-init="zishu=<?php echo $zishu;?>;read=(zishu/300).toFixed(1)" class="hidden"></span>


<?php if($this->is('post')&&(empty($this->options->tools)||!in_array('ds', $this->options->tools))): ?>
<div class="flex justify-center text-gray-500 dark:text-gray-300 -mx-2 pt-2 text-sm">


<button id="dianzan" x-ref="like" @click="
id='<?php $this->cid(); ?>'; storage = window.localStorage;
if(type){main.notice('error','你已经赞过了');}else{main.notice('success','感谢您的点赞！');type=true;
fetch('<?php $this->options->rootUrl(); ?>?likeup='+id+'&do_action=do',{method: 'POST',}).then(data => data.text()).then(data => {
  storage.setItem('like_'+id, true);
  $store.info.zan=data.trim();
});
}
">
<div class="flex items-center justify-center break-normal shadow dark:shadow-gray-200 mx-2 rounded-full size-14 transition-colors duration-300 bg-pink-600 hover:bg-pink-700 mb-0.5">
<svg class="text-white size-8 mx-auto" aria-hidden="true"><use xlink:href="#thumb_up_2_fill"></use></svg>
</div>
<p>点赞 (<span x-text="$store.info.zan">0</span>)</p>
</button>

</div>
<?php endif;?>


<?php if($this->is('post')&&!empty($this->options->tools)&&in_array('cc', $this->options->tools)): ?>
<!--文章版权声明-->
<div class="mt-6 bg-gray-100/70 dark:bg-white/20 dark:text-gray-300 p-4 rounded-md text-sm">
    <div>
本站未注明转载的文章均为原创，并采用 <a class="text-[var(--primary)]" target="_blank" href="https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode.zh-hans">
    CC BY-NC-SA 4.0</a> 授权协议，转载请注明来源，谢谢！
    </div>
</div>
<!--文章版权声明-->
<?php endif; ?>



<?php if($this->is('post')): ?>
<div class="flex flex-wrap justify-between items-center text-sm text-gray-400 mt-4 gap-2">
<p>
<?php if(count($this->categories) != 0 ){
foreach($this->categories as $val){
    ?>
<a href="<?php echo $val['url']; ?>" itemprop="url" class="border border-black/20 dark:border-white/20 inline-block px-2 py-0.5 rounded-sm"><?php echo $val['name']; ?></a>
<?php }} ?>
</p>

<?php if(empty($this->options->tools)||!in_array('ds', $this->options->tools)): ?>
<p class="flex items-center text-white text-xs gap-2">
<button id="dashang" x-ref="reward" @click="main.reward($refs.reward)" data-title="扫码打赏" data-desc="微信扫码" data-desc2="支付宝扫码" data-wx="<?php if($this->options->dashang){$this->options->dashang();}else{$this->options->themeUrl('img/wx.png');} ?>" data-tb="<?php if($this->options->dashangzfb){$this->options->dashangzfb();}else{$this->options->themeUrl('img/zfb.png');} ?>" class="flex items-center transition-colors duration-200 bg-[var(--btn)] hover:bg-[var(--btn-hover)] rounded-sm px-3 py-2">
<svg class="size-4 mr-0.5" aria-hidden="true"><use xlink:href="#wallet_2_fill"></use></svg>
打赏
</button>

<button id="fenxiang" x-ref="share" @click="main.share($refs.share)" 
data-title="<?php $this->title() ?>"
data-url="<?php $this->permalink() ?>"
data-img="<?php  showThumbnail($this); ?>"
:data-code="jrQrcode.getQrBase64('<?php $this->permalink() ?>');" class="flex items-center transition-colors duration-200 bg-[var(--btn)] hover:bg-[var(--btn-hover)] rounded-sm px-3 py-2">
<svg class="size-4 mr-0.5" aria-hidden="true"><use xlink:href="#share_3_fill"></use></svg>
分享
</button>
</p>
<?php endif;?>
</div>
<?php endif;?>


</div>



  <?php $this->need('prevnext.php'); ?>

  <?php $this->need('recommen.php'); ?>

</article>



<?php if($this->options->ad4||$this->options->ad5): ?>
<div class="mt-8">
<div class="flex flex-col sm:flex-row sm:justify-between -m-2">
<?php if($this->options->ad4): ?>
<div class="flex-1 m-2 shadow rounded overflow-hidden">
<?php $this->options->ad4(); ?>
</div>
<?php endif; ?>
<?php if($this->options->ad5): ?>
<div class="flex-1 m-2 shadow rounded overflow-hidden">
<?php $this->options->ad5(); ?>
</div>
<?php endif; ?>
</div></div>
<?php endif; ?>

<div id="comments-qu" class="bg-white dark:bg-gray-900 mt-8 p-5 rounded-lg shadow shadow-blue-100 dark:shadow-gray-500">
<div class="text-center bg-[#d4dbdf] dark:bg-[#242d34] rounded-lg p-8" x-show="!$store.info.comment">
<svg class="size-10 mx-auto animate-spin" aria-hidden="true"><use xlink:href="#icon_loading"></use></svg>
</div>
<div x-html="$store.info.comment" x-show="$store.info.comment" x-cloak></div>
</div>
<?php $this->need('footer.php'); ?>