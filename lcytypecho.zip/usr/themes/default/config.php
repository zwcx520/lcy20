<?php
define('uid',1);
define('hue',250);
define('InstantClick',1);
?>