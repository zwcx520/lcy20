<div class="px-2 lg:px-0 grid grid-cols-4 gap-4 lg:gap-6 container max-w-6xl mx-auto relative -mt-30 <?php if($this->is('single')){ echo ' animate-headerbgup lg:animate-headerbgbigup';}else{echo ' animate-headerbgdown lg:animate-headerbgbigdown'; } ?>">
<div class="col-span-4 lg:col-span-1 order-2 lg:order-1 hidden lg:block">
<?php $this->need('sidebar.php'); ?>
</div>
<div class="col-span-4 lg:col-span-3 order-1 lg:order-2">