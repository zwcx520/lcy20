<?php
session_start();
require_once '../include/functions.php';

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$error = '';
if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $email = $_POST['email'];
    $avatar = '';
    
    // 处理头像上传
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/avatars/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($file_extension, $allowed_extensions)) {
            $file_name = uniqid() . '.' . $file_extension;
            $target_path = $upload_dir . $file_name;
            
            if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target_path)) {
                $avatar = 'uploads/avatars/' . $file_name;
            }
        }
    }
    
    if ($password !== $confirm_password) {
        $error = '两次输入的密码不一致';
    } elseif (strlen($password) < 6) {
        $error = '密码长度至少为6位';
    } else {
        if (register($username, $password, $email, $avatar)) {
            // 注册成功后自动登录
            login($username, $password);
            header('Location: index.php');
            exit;
        } else {
            $error = '注册失败，用户名或邮箱已存在';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>注册 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
			background-image: url(../../bj.jpg);
			      background-size: cover; /* 修改为cover，使图片铺满满屏 */
			      background-attachment: fixed; /* 可选，使背景图片固定不随页面滚动 */
			      margin: 0; /* 去除默认边距 */
			      padding: 0; /* 去除默认内边距 */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            max-width: 450px;
            width: 100%;
            padding: 0 20px;
        }

        .register-card {
           
            text-align: center;
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .register-card .logo {
            font-size: 32px;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .register-card .logo i {
            font-size: 40px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .register-card h1 {
            font-size: 24px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(255, 107, 157, 0.1);
        }

        /* 头像上传 */
        .avatar-upload {
            text-align: center;
            margin-bottom: 20px;
        }

        .avatar-preview {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--primary-color);
            margin-bottom: 10px;
            background: var(--light-color);
        }

        .avatar-upload input[type="file"] {
            display: none;
        }

        .avatar-upload label {
            display: inline-block;
            padding: 8px 16px;
            background: var(--primary-color);
            color: white;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .avatar-upload label:hover {
            background: #ff528b;
            transform: translateY(-2px);
        }

        .form-group .password-input {
            position: relative;
        }

        .form-group .password-input input {
            padding-right: 40px;
        }

        .form-group .password-input .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #999;
            transition: all 0.3s ease;
        }

        .form-group .password-input .toggle-password:hover {
            color: var(--primary-color);
        }

        .btn {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: #ff528b;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 107, 157, 0.3);
        }

        .error-message {
            background: #ffebee;
            color: #c62828;
            padding: 10px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            font-size: 14px;
        }

        .login-link {
            margin-top: 20px;
            font-size: 14px;
            color: var(--text-color);
        }

        .login-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        /* 响应式设计 */
        @media (max-width: 480px) {
            .register-card {
                padding: 30px 20px;
            }

            .register-card h1 {
                font-size: 20px;
            }

            .form-group input {
                padding: 10px 12px;
            }

            .btn {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="register-card">
           
            <?php if (!empty($error)): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form action="register.php" method="post" enctype="multipart/form-data">
                <!-- 头像上传 -->
                <div class="avatar-upload">
                    <img src="../assets/images/default-avatar.svg" alt="头像预览" class="avatar-preview" id="avatarPreview">
                    <br>
                    <label for="avatar">
                        <i class="fas fa-camera"></i> 选择头像
                    </label>
                    <input type="file" id="avatar" name="avatar" accept="image/*" onchange="previewAvatar(this)">
                </div>

                <div class="form-group">
                    <label for="username">用户名</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="email">邮箱</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="password">密码</label>
                    <div class="password-input">
                        <input type="password" id="password" name="password" required>
                        <span class="toggle-password" onclick="togglePassword('password')"><i class="fas fa-eye"></i></span>
                    </div>
                </div>
                <div class="form-group">
                    <label for="confirm_password">确认密码</label>
                    <div class="password-input">
                        <input type="password" id="confirm_password" name="confirm_password" required>
                        <span class="toggle-password" onclick="togglePassword('confirm_password')"><i class="fas fa-eye"></i></span>
                    </div>
                </div>
                <button type="submit" name="register" class="btn btn-primary">注册</button>
            </form>
            
            <div class="login-link">
                已有账号? <a href="login.php">立即登录</a>
            </div>
        </div>
    </div>

    <script>
        // 密码显示/隐藏
        function togglePassword(inputId) {
            const passwordInput = document.getElementById(inputId);
            const toggleIcon = passwordInput.nextElementSibling.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }

        // 头像预览
        function previewAvatar(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('avatarPreview').src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</body>
</html>