<?php
session_start();
require_once '../include/functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// 获取当前用户信息并检查发布权限
$currentUser = getCurrentUser();
if (!$currentUser || !($currentUser['can_publish'] ?? 1)) {
    $error = '您没有发布应用的权限，请联系管理员。';
}

// 获取所有分类
$categories = getCategories();

$error = '';
$success = '';

if (isset($_POST['submit'])) {
    // 再次检查发布权限
    if (!$currentUser || !($currentUser['can_publish'] ?? 1)) {
        $error = '您没有发布应用的权限，请联系管理员。';
    } else {
        $name = $_POST['name'];
    $description = $_POST['description'];
    $category_id = $_POST['category_id'];
    $version = $_POST['version'];
    $size = $_POST['size'];
    
    // 先插入数据库获取应用ID
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO apps (name, description, category_id, icon, banner, download_url, version, size) VALUES (?, ?, ?, '', '', '', ?, ?)");
    $stmt->execute([$name, $description, $category_id, $version, $size]);
    $app_id = $db->lastInsertId();
    
    // 处理图标上传（可选）
    $icon = '';
    if (isset($_FILES['icon']) && $_FILES['icon']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/icons/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES['icon']['name'], PATHINFO_EXTENSION));
        $allowed_image_types = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($file_extension, $allowed_image_types)) {
            // 检查图标大小 (5MB = 5242880 bytes)
            if ($_FILES['icon']['size'] > 5 * 1024 * 1024) {
                $error = '图标文件大小超过 5MB 限制';
            } else {
                $file_name = $app_id . '_' . uniqid() . '.' . $file_extension;
                $target_path = $upload_dir . $file_name;
                
                if (move_uploaded_file($_FILES['icon']['tmp_name'], $target_path)) {
                    $icon = 'uploads/icons/' . $file_name;
                } else {
                    $error = '图标上传失败，无法移动到目标目录';
                }
            }
        } else {
            $error = '图标格式不支持，请上传 JPG、PNG 或 GIF 格式';
        }
    }
    
    // 如果有错误，删除已创建的应用记录
    if (!empty($error)) {
        $stmt = $db->prepare("DELETE FROM apps WHERE id = ?");
        $stmt->execute([$app_id]);
    } else {
        // 处理横幅上传（可选）
        $banner = '';
        if (isset($_FILES['banner']) && $_FILES['banner']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../uploads/banners/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_extension = strtolower(pathinfo($_FILES['banner']['name'], PATHINFO_EXTENSION));
            $allowed_image_types = ['jpg', 'jpeg', 'png', 'gif'];
            
            if (in_array($file_extension, $allowed_image_types)) {
                // 检查横幅大小 (10MB = 10485760 bytes)
                if ($_FILES['banner']['size'] > 10 * 1024 * 1024) {
                    $error = '横幅文件大小超过 10MB 限制';
                } else {
                    $file_name = $app_id . '_' . uniqid() . '.' . $file_extension;
                    $target_path = $upload_dir . $file_name;
                    
                    if (move_uploaded_file($_FILES['banner']['tmp_name'], $target_path)) {
                        $banner = 'uploads/banners/' . $file_name;
                    } else {
                        $error = '横幅上传失败，无法移动到目标目录';
                    }
                }
            } else {
                $error = '横幅格式不支持，请上传 JPG、PNG 或 GIF 格式';
            }
        }
    }
    
    // 获取文件路径
    $download_url = isset($_POST['download_url']) ? trim($_POST['download_url']) : '';
    
    // 处理应用文件上传（如果上传了文件）
    if (isset($_FILES['app_file']) && $_FILES['app_file']['error'] === UPLOAD_ERR_OK) {
        $file_name = basename($_FILES['app_file']['name']);
        $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_app_types = ['apk', 'ipa', 'exe', 'dmg', 'zip', 'rar', '7z'];
        
        // 检查文件类型
        if (!in_array($file_extension, $allowed_app_types)) {
            $error = '应用文件格式不支持，请上传 APK、IPA、EXE、DMG 或压缩包格式';
        } else {
            // 检查文件大小 (10GB = 10737418240 bytes)
            $max_size = 10 * 1024 * 1024 * 1024;
            if ($_FILES['app_file']['size'] > $max_size) {
                $error = '应用文件大小超过 10GB 限制';
            } else {
                // 使用应用ID创建独立文件夹
                $upload_dir = '../uploads/apps/' . $app_id . '/';
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                
                $target_path = $upload_dir . $file_name;
                
                // 如果文件已存在，添加唯一ID
                if (file_exists($target_path)) {
                    $file_info = pathinfo($file_name);
                    $file_name = $file_info['filename'] . '_' . uniqid() . '.' . $file_info['extension'];
                    $target_path = $upload_dir . $file_name;
                }
                
                if (move_uploaded_file($_FILES['app_file']['tmp_name'], $target_path)) {
                    $download_url = 'uploads/apps/' . $app_id . '/' . $file_name;
                } else {
                    $error = '应用文件上传失败，无法移动到目标目录';
                }
            }
        }
    }
    
    // 验证文件路径
    if (empty($download_url)) {
        $error = '请填写文件路径或上传应用文件';
    }
    
    if (empty($error)) {
        // 更新应用记录，保存文件路径
        $stmt = $db->prepare("UPDATE apps SET icon = ?, banner = ?, download_url = ? WHERE id = ?");
        $stmt->execute([$icon, $banner, $download_url, $app_id]);
        $success = '应用发布成功！';
    } else {
        // 有错误时删除已创建的应用记录
        $stmt = $db->prepare("DELETE FROM apps WHERE id = ?");
        $stmt->execute([$app_id]);
    }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>发布应用 - <?php echo getSetting('site_name', SITE_NAME); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* 导航栏 */
        header {
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            color: white;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
        }

        .logo {
            font-size: 20px;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .logo i {
            font-size: 24px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .search-box {
            flex: 1;
            max-width: 400px;
            margin: 0 20px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 8px 12px;
            border: none;
            border-radius: 30px;
            font-size: 14px;
            outline: none;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .search-box button {
            position: absolute;
            right: 5px;
            top: 50%;
            transform: translateY(-50%);
            background: var(--secondary-color);
            border: none;
            border-radius: 50%;
            width: 26px;
            height: 26px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .search-box button:hover {
            background: var(--accent-color);
            transform: translateY(-50%) scale(1.1);
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-menu a {
            color: white;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .user-menu a:hover {
            transform: translateY(-2px);
        }

        /* 移动端菜单按钮 */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            padding: 5px;
        }

        .mobile-menu-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border-radius: 8px;
            box-shadow: var(--box-shadow);
            min-width: 150px;
            z-index: 1001;
            margin-top: 5px;
        }

        .mobile-menu-dropdown a {
            display: block;
            padding: 10px 15px;
            color: var(--dark-color);
            text-decoration: none;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .mobile-menu-dropdown a:hover {
            background-color: var(--light-color);
        }

        .mobile-menu-dropdown.show {
            display: block;
        }

        /* 主内容区 */
        .main-content {
            margin: 30px 0;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-title {
            font-size: 24px;
            font-weight: bold;
            color: var(--dark-color);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 8px 16px;
            background: var(--light-color);
            color: var(--dark-color);
            text-decoration: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .back-btn:hover {
            background: #e8e8e8;
            transform: translateY(-2px);
        }

        /* 表单 */
        .form-container {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(255, 107, 157, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-group .file-upload {
            border: 1px dashed #ddd;
            border-radius: var(--border-radius);
            padding: 20px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .form-group .file-upload:hover {
            border-color: var(--primary-color);
            background: rgba(255, 107, 157, 0.05);
        }

        .form-group .file-upload input[type="file"] {
            display: none;
        }

        .form-group .file-upload label {
            display: inline-block;
            padding: 8px 16px;
            background: var(--primary-color);
            color: white;
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .form-group .file-upload label:hover {
            background: #ff528b;
            transform: translateY(-2px);
        }

        /* 文件预览 */
        .file-preview {
            margin-top: 15px;
            padding: 15px;
            background: var(--light-color);
            border-radius: var(--border-radius);
            display: none;
        }

        .file-preview.active {
            display: block;
        }

        .file-preview img {
            max-width: 200px;
            max-height: 200px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }

        .file-preview .app-file-info {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: white;
            border-radius: var(--border-radius);
        }

        .file-preview .app-file-info i {
            font-size: 48px;
            color: var(--primary-color);
        }

        .file-preview .app-file-info .file-details {
            flex: 1;
            text-align: left;
        }

        .file-preview .app-file-info .file-details .file-name {
            font-weight: 500;
            color: var(--dark-color);
            margin-bottom: 5px;
            word-break: break-all;
        }

        .file-preview .app-file-info .file-details .file-size {
            font-size: 12px;
            color: #999;
        }

        .file-preview .preview-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 10px;
            font-weight: 500;
        }

        .error-message {
            background: #ffebee;
            color: #c62828;
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            font-size: 14px;
        }

        .success-message {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            font-size: 14px;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            margin-top: 30px;
        }

        .form-actions .btn {
            padding: 12px 24px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .form-actions .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .form-actions .btn-primary:hover {
            background: #ff528b;
            transform: translateY(-2px);
        }

        .form-actions .btn-secondary {
            background: var(--light-color);
            color: var(--dark-color);
        }

        .form-actions .btn-secondary:hover {
            background: #e8e8e8;
            transform: translateY(-2px);
        }

        /* 上传进度条 */
        .upload-progress {
            display: none;
            margin-top: 15px;
        }

        .upload-progress.active {
            display: block;
        }

        .progress-bar-container {
            background: #e0e0e0;
            border-radius: 10px;
            height: 20px;
            overflow: hidden;
        }

        .progress-bar {
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
            height: 100%;
            width: 0%;
            transition: width 0.3s ease;
            border-radius: 10px;
        }

        .progress-text {
            text-align: center;
            margin-top: 5px;
            font-size: 12px;
            color: #666;
        }

        /* 页脚 */
        footer {
            background: var(--dark-color);
            color: white;
            padding: 40px 0;
            margin-top: 50px;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
        }

        .footer-section h3 {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 20px;
            color: var(--primary-color);
        }

        .footer-section ul {
            list-style: none;
        }

        .footer-section ul li {
            margin-bottom: 10px;
        }

        .footer-section ul li a {
            color: #ddd;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-section ul li a:hover {
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            margin-top: 30px;
            border-top: 1px solid #555;
            font-size: 14px;
            color: #999;
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
            .nav-container {
                flex-direction: row;
                gap: 10px;
                padding: 8px 15px;
            }

            .logo {
                font-size: 16px;
            }

            .logo i {
                font-size: 20px;
            }

            .search-box {
                flex: 1;
                max-width: none;
                margin: 0 10px;
            }

            .search-box input {
                padding: 6px 10px;
                font-size: 12px;
            }

            .search-box button {
                width: 24px;
                height: 24px;
                font-size: 12px;
            }

            .user-menu {
                display: none;
            }

            .mobile-menu-btn {
                display: block;
            }

            .form-container {
                padding: 20px;
            }

            .form-actions {
                flex-direction: column;
            }

            .page-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
        }

        /* 动画效果 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <header>
        <div class="container nav-container">
            <div class="logo">
                <i class="fas fa-gamepad"></i>
                <span><?php echo getSetting('site_name', SITE_NAME); ?></span>
            </div>
            <div class="search-box">
                <form action="../search/index.php" method="get">
                    <input type="text" name="keyword" placeholder="搜索应用...">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>
            <div class="user-menu">
                <a href="index.php"><i class="fas fa-user"></i> <?php echo $_SESSION['username']; ?></a>
                <a href="logout.php" onclick="return confirm('确定要退出登录吗？');"><i class="fas fa-sign-out-alt"></i> 退出</a>
                <?php if (isAdmin()): ?>
                    <a href="../admin/index.php"><i class="fas fa-cog"></i> 管理</a>
                <?php endif; ?>
            </div>
            <!-- 移动端菜单按钮 -->
            <button class="mobile-menu-btn" onclick="toggleMobileMenu()">
                <i class="fas fa-bars"></i>
            </button>
            <!-- 移动端下拉菜单 -->
            <div class="mobile-menu-dropdown">
                <a href="index.php"><i class="fas fa-user"></i> <?php echo $_SESSION['username']; ?></a>
                <a href="logout.php" onclick="return confirm('确定要退出登录吗？');"><i class="fas fa-sign-out-alt"></i> 退出</a>
                <?php if (isAdmin()): ?>
                    <a href="../admin/index.php"><i class="fas fa-cog"></i> 管理</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="main-content fade-in">
            <!-- 页面标题 -->
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-plus-circle"></i> 发布应用
                </h1>
                <a href="index.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i> 返回个人中心
                </a>
            </div>

            <!-- 表单 -->
            <div class="form-container">
                <?php if (!empty($error)): ?>
                    <div class="error-message">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="success-message">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <form action="publish_app.php" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name">应用名称 <span style="color: #e74c3c;">*</span></label>
                        <input type="text" id="name" name="name" required placeholder="请输入应用名称">
                    </div>
                    
                    <div class="form-group">
                        <label for="description">应用描述 <span style="color: #e74c3c;">*</span></label>
                        <textarea id="description" name="description" required placeholder="请输入应用描述"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="category_id">分类 <span style="color: #e74c3c;">*</span></label>
                        <select id="category_id" name="category_id" required>
                            <option value="">请选择分类</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="icon">应用图标</label>
                        <div class="file-upload">
                            <input type="file" id="icon" name="icon" accept="image/*" onchange="previewImage(this, 'iconPreview')">
                            <label for="icon"><i class="fas fa-upload"></i> 选择图标</label>
                            <p style="margin-top: 10px; font-size: 12px; color: #999;">支持 JPG、PNG、GIF 格式 (最大 5MB)</p>
                        </div>
                        <div class="file-preview" id="iconPreview">
                            <div class="preview-label">图标预览：</div>
                            <img src="" alt="图标预览">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="banner">应用横幅</label>
                        <div class="file-upload">
                            <input type="file" id="banner" name="banner" accept="image/*" onchange="previewImage(this, 'bannerPreview')">
                            <label for="banner"><i class="fas fa-upload"></i> 选择横幅</label>
                            <p style="margin-top: 10px; font-size: 12px; color: #999;">支持 JPG、PNG、GIF 格式 (最大 10MB)</p>
                        </div>
                        <div class="file-preview" id="bannerPreview">
                            <div class="preview-label">横幅预览：</div>
                            <img src="" alt="横幅预览">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="version">版本号 <span style="color: #e74c3c;">*</span></label>
                        <input type="text" id="version" name="version" required placeholder="例如: 1.0.0">
                    </div>
                    
                    <div class="form-group">
                        <label for="size">应用大小 <span style="color: #e74c3c;">*</span></label>
                        <input type="text" id="size" name="size" required placeholder="例如: 10MB">
                    </div>
                    
                    <div class="form-group">
                        <label for="download_url">文件路径 <span style="color: #e74c3c;">*</span></label>
                        <input type="text" id="download_url" name="download_url" placeholder="例如: uploads/apps/1/filename.apk">
                        <p style="margin-top: 5px; font-size: 12px; color: #999;">填写相对路径，格式：uploads/apps/应用ID/文件名.apk，或直接上传文件自动生成路径</p>
                    </div>
                    
                    <div class="form-group">
                        <label for="app_file">上传应用文件（可选）</label>
                        <div class="file-upload">
                            <input type="file" id="app_file" name="app_file" onchange="handleFileUpload(this)">
                            <label for="app_file"><i class="fas fa-upload"></i> 选择文件</label>
                            <p style="margin-top: 10px; font-size: 12px; color: #999;">支持 APK、IPA、EXE、DMG 或压缩包格式 (最大 10GB)</p>
                        </div>
                        <div class="file-preview" id="appFilePreview">
                            <div class="preview-label">文件信息：</div>
                            <div class="app-file-info">
                                <i class="fas fa-file-archive"></i>
                                <div class="file-details">
                                    <div class="file-name" id="appFileName"></div>
                                    <div class="file-size" id="appFileSize"></div>
                                </div>
                            </div>
                        </div>
                        <!-- 上传进度条 -->
                        <div class="upload-progress" id="uploadProgress">
                            <div class="progress-bar-container">
                                <div class="progress-bar" id="progressBar"></div>
                            </div>
                            <div class="progress-text" id="progressText">0%</div>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane"></i> 发布应用
                        </button>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> 取消
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 页脚 -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>关于我们</h3>
                    <ul>
                        <li><a href="#">公司简介</a></li>
                        <li><a href="#">联系我们</a></li>
                        <li><a href="#">加入我们</a></li>
                        <li><a href="#">隐私政策</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>帮助中心</h3>
                    <ul>
                        <li><a href="#">常见问题</a></li>
                        <li><a href="#">下载指南</a></li>
                        <li><a href="#">应用提交</a></li>
                        <li><a href="#">开发者中心</a></li>
                        <li><a href="../feedback/index.php"><i class="fas fa-comment-dots"></i> 意见反馈</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>关注我们</h3>
                    <ul>
                        <li><a href="#"><i class="fab fa-weibo"></i> 微博</a></li>
                        <li><a href="#"><i class="fab fa-wechat"></i> 微信</a></li>
                        <li><a href="#"><i class="fab fa-qq"></i> QQ</a></li>
                        <li><a href="#"><i class="fab fa-github"></i> GitHub</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>下载客户端</h3>
                    <p>扫描二维码下载客户端</p>
                    <?php
                        $clientDownloadUrl = getSetting('client_download_url', '');
                        if (!empty($clientDownloadUrl)) {
                            $encodedUrl = urlencode($clientDownloadUrl);
                            $qrcodeUrl = "https://api.qrserver.com/v1/create-qr-code/?size=120x120&data={$encodedUrl}";
                            echo '<img src="' . $qrcodeUrl . '" alt="客户端下载二维码" style="width: 120px; height: 120px; margin-top: 10px;">';
                        } else {
                            echo '<div style="width: 120px; height: 120px; background: white; margin-top: 10px; display: flex; align-items: center; justify-content: center; color: #999; font-size: 12px;">请在后台设置下载URL</div>';
                        }
                    ?>
                </div>
            </div>
            <div class="footer-bottom">
                <p><?php echo getSetting('copyright', '&copy; 2026 ' . getSetting('site_name', SITE_NAME) . ' 版权所有'); ?></p>
            </div>
        </div>
    </footer>

    <script>
        // 图片预览功能
        function previewImage(input, previewId) {
            const preview = document.getElementById(previewId);
            const img = preview.querySelector('img');
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    img.src = e.target.result;
                    preview.classList.add('active');
                }
                reader.readAsDataURL(input.files[0]);
            } else {
                img.src = '';
                preview.classList.remove('active');
            }
        }

        // 应用文件预览功能
        function previewAppFile(input) {
            const preview = document.getElementById('appFilePreview');
            const fileName = document.getElementById('appFileName');
            const fileSize = document.getElementById('appFileSize');
            
            if (input.files && input.files[0]) {
                const file = input.files[0];
                fileName.textContent = file.name;
                fileSize.textContent = formatFileSize(file.size);
                preview.classList.add('active');
            } else {
                fileName.textContent = '';
                fileSize.textContent = '';
                preview.classList.remove('active');
            }
        }

        // 处理文件上传（带进度条）
        function handleFileUpload(input) {
            const file = input.files[0];
            if (!file) return;

            // 显示文件信息
            previewAppFile(input);

            // 检查文件类型
            const allowedTypes = ['apk', 'ipa', 'exe', 'dmg', 'zip', 'rar', '7z'];
            const fileExtension = file.name.split('.').pop().toLowerCase();
            if (!allowedTypes.includes(fileExtension)) {
                alert('应用文件格式不支持，请上传 APK、IPA、EXE、DMG 或压缩包格式');
                input.value = '';
                return;
            }

            // 检查文件大小 (10GB)
            const maxSize = 10 * 1024 * 1024 * 1024;
            if (file.size > maxSize) {
                alert('应用文件大小超过 10GB 限制');
                input.value = '';
                return;
            }

            // 显示进度条
            const progressContainer = document.getElementById('uploadProgress');
            const progressBar = document.getElementById('progressBar');
            const progressText = document.getElementById('progressText');
            progressContainer.classList.add('active');
            progressBar.style.width = '0%';
            progressText.textContent = '准备上传...';

            // 创建 FormData
            const formData = new FormData();
            formData.append('app_file', file);
            formData.append('upload_only', '1');

            // 创建 XMLHttpRequest
            const xhr = new XMLHttpRequest();

            // 监听上传进度
            xhr.upload.addEventListener('progress', function(e) {
                if (e.lengthComputable) {
                    const percentComplete = Math.round((e.loaded / e.total) * 100);
                    progressBar.style.width = percentComplete + '%';
                    progressText.textContent = percentComplete + '% (' + formatFileSize(e.loaded) + ' / ' + formatFileSize(e.total) + ')';
                }
            });

            // 监听上传完成
            xhr.addEventListener('load', function() {
                if (xhr.status === 200) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            progressBar.style.width = '100%';
                            progressText.textContent = '上传完成！';
                            
                            // 自动填充文件路径到输入框
                            document.getElementById('download_url').value = response.file_path;
                            
                            // 2秒后隐藏进度条
                            setTimeout(() => {
                                progressContainer.classList.remove('active');
                            }, 2000);
                        } else {
                            progressText.textContent = '上传失败：' + response.message;
                            progressBar.style.background = '#e74c3c';
                        }
                    } catch (e) {
                        progressText.textContent = '上传失败，请稍后重试';
                        progressBar.style.background = '#e74c3c';
                    }
                } else {
                    progressText.textContent = '上传失败，请稍后重试';
                    progressBar.style.background = '#e74c3c';
                }
            });

            // 监听上传错误
            xhr.addEventListener('error', function() {
                progressText.textContent = '上传失败，请检查网络连接';
                progressBar.style.background = '#e74c3c';
            });

            // 监听上传取消
            xhr.addEventListener('abort', function() {
                progressText.textContent = '上传已取消';
                progressBar.style.background = '#e74c3c';
            });

            // 发送请求
            xhr.open('POST', '../admin/upload_app_file.php', true);
            xhr.send(formData);
        }

        // 格式化文件大小
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const fadeElements = document.querySelectorAll('.fade-in');
            fadeElements.forEach((element, index) => {
                element.style.animationDelay = `${index * 0.1}s`;
            });
        });

        // 移动端菜单切换
        function toggleMobileMenu() {
            const dropdown = document.querySelector('.mobile-menu-dropdown');
            dropdown.classList.toggle('show');
        }

        // 点击页面其他地方关闭菜单
        document.addEventListener('click', function(event) {
            const menuBtn = document.querySelector('.mobile-menu-btn');
            const dropdown = document.querySelector('.mobile-menu-dropdown');
            if (!menuBtn.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });
    </script>
</body>
</html>
