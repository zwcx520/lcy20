<?php
session_start();
require_once '../include/functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// 获取当前用户信息
$user = getCurrentUser();

// 获取用户下载记录
$db = getDB();
$stmt = $db->prepare("SELECT downloads.*, apps.name, apps.icon FROM downloads 
                      LEFT JOIN apps ON downloads.app_id = apps.id 
                      WHERE downloads.user_id = ? 
                      ORDER BY downloads.download_time DESC");
$stmt->execute([$user['id']]);
$downloads = $stmt->fetchAll();

// 获取用户评论记录
$stmt = $db->prepare("SELECT reviews.*, apps.name, apps.icon FROM reviews 
                      LEFT JOIN apps ON reviews.app_id = apps.id 
                      WHERE reviews.user_id = ? 
                      ORDER BY reviews.created_at DESC");
$stmt->execute([$user['id']]);
$reviews = $stmt->fetchAll();

// 获取用户发布的应用（通过下载记录关联，这里简化处理，获取所有应用作为示例）
// 注意：实际项目中应该添加 user_id 字段到 apps 表来追踪发布者
$stmt = $db->prepare("SELECT * FROM apps ORDER BY created_at DESC LIMIT 10");
$stmt->execute();
$publishedApps = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>个人中心 - <?php echo getSetting('site_name', SITE_NAME); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* 导航栏 */
        header {
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            color: white;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
        }

        .logo {
            font-size: 20px;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .logo i {
            font-size: 24px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .search-box {
            flex: 1;
            max-width: 400px;
            margin: 0 20px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 8px 12px;
            border: none;
            border-radius: 30px;
            font-size: 14px;
            outline: none;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .search-box button {
            position: absolute;
            right: 5px;
            top: 50%;
            transform: translateY(-50%);
            background: var(--secondary-color);
            border: none;
            border-radius: 50%;
            width: 26px;
            height: 26px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .search-box button:hover {
            background: var(--accent-color);
            transform: translateY(-50%) scale(1.1);
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-menu a {
            color: white;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .user-menu a:hover {
            transform: translateY(-2px);
        }

        /* 移动端菜单按钮 */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            padding: 5px;
        }

        .mobile-menu-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border-radius: 8px;
            box-shadow: var(--box-shadow);
            min-width: 150px;
            z-index: 1001;
            margin-top: 5px;
        }

        .mobile-menu-dropdown a {
            display: block;
            padding: 10px 15px;
            color: var(--dark-color);
            text-decoration: none;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .mobile-menu-dropdown a:hover {
            background-color: var(--light-color);
        }

        .mobile-menu-dropdown.show {
            display: block;
        }

        /* 用户中心 */
        .user-center {
            margin: 30px 0;
        }

        .user-profile {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 30px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .user-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            overflow: hidden;
            background: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 48px;
            font-weight: bold;
        }

        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-info {
            flex: 1;
        }

        .user-info h1 {
            font-size: 24px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 10px;
        }

        .user-info p {
            color: var(--text-color);
            margin-bottom: 5px;
        }

        .edit-profile-btn {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            margin-top: 10px;
            padding: 8px 16px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .edit-profile-btn:hover {
            background: #ff528b;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 107, 157, 0.3);
        }

        .user-stats {
            display: flex;
            gap: 30px;
            margin-top: 20px;
        }

        .stat-item {
            text-align: center;
        }

        .stat-value {
            font-size: 20px;
            font-weight: bold;
            color: var(--primary-color);
        }

        .stat-label {
            font-size: 14px;
            color: var(--text-color);
        }

        /* 标签页 */
        .tabs {
            display: flex;
            background: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
            box-shadow: var(--box-shadow);
            overflow: hidden;
        }

        .tab {
            padding: 15px 30px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            color: var(--text-color);
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
        }

        .tab.active {
            color: var(--primary-color);
            border-bottom-color: var(--primary-color);
        }

        .tab-content {
            background: white;
            border-radius: 0 0 var(--border-radius) var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 30px;
            min-height: 400px;
        }

        .tab-pane {
            display: none;
        }

        .tab-pane.active {
            display: block;
        }

        /* 下载记录 */
        .download-list {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .download-item {
            display: flex;
            align-items: center;
            gap: 20px;
            padding: 20px;
            background: var(--light-color);
            border-radius: var(--border-radius);
            transition: all 0.3s ease;
        }

        .download-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .download-item .app-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            overflow: hidden;
        }

        .download-item .app-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .download-item .app-info {
            flex: 1;
        }

        .download-item .app-name {
            font-size: 16px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 5px;
        }

        .download-item .download-time {
            font-size: 14px;
            color: var(--text-color);
        }

        .download-item .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            background: var(--primary-color);
            color: white;
        }

        .download-item .btn:hover {
            background: #ff528b;
            transform: translateY(-2px);
        }

        /* 评论记录 */
        .review-list {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .review-item {
            padding: 20px;
            background: var(--light-color);
            border-radius: var(--border-radius);
            transition: all 0.3s ease;
        }

        .review-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .review-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }

        .review-header .app-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            overflow: hidden;
        }

        .review-header .app-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .review-header .app-name {
            font-size: 16px;
            font-weight: bold;
            color: var(--dark-color);
        }

        .review-header .rating {
            display: flex;
            align-items: center;
            gap: 5px;
            margin-left: auto;
        }

        .review-header .rating i {
            color: #ffd700;
            font-size: 14px;
        }

        .review-content {
            line-height: 1.6;
            color: var(--text-color);
            margin-bottom: 10px;
        }

        .review-time {
            font-size: 14px;
            color: #999;
        }

        /* 无数据提示 */
        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-color);
        }

        .no-data i {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 20px;
        }

        .no-data h3 {
            font-size: 20px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 10px;
        }

        /* 页脚 */
        footer {
            background: var(--dark-color);
            color: white;
            padding: 40px 0;
            margin-top: 50px;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
        }

        .footer-section h3 {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 20px;
            color: var(--primary-color);
        }

        .footer-section ul {
            list-style: none;
        }

        .footer-section ul li {
            margin-bottom: 10px;
        }

        .footer-section ul li a {
            color: #ddd;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-section ul li a:hover {
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            margin-top: 30px;
            border-top: 1px solid #555;
            font-size: 14px;
            color: #999;
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
            .nav-container {
                flex-direction: row;
                gap: 10px;
                padding: 8px 15px;
            }

            .logo {
                font-size: 16px;
            }

            .logo i {
                font-size: 20px;
            }

            .search-box {
                flex: 1;
                max-width: none;
                margin: 0 10px;
            }

            .search-box input {
                padding: 6px 10px;
                font-size: 12px;
            }

            .search-box button {
                width: 24px;
                height: 24px;
                font-size: 12px;
            }

            .user-menu {
                display: none;
            }

            .mobile-menu-btn {
                display: block;
            }

            .user-profile {
                flex-direction: column;
                text-align: center;
                padding: 20px;
            }

            .user-stats {
                justify-content: center;
            }

            .tabs {
                overflow-x: auto;
                white-space: nowrap;
            }

            .tab {
                padding: 15px 20px;
            }

            .tab-content {
                padding: 20px;
            }

            .download-item {
                flex-direction: column;
                text-align: center;
            }

            .review-header {
                flex-direction: column;
                text-align: center;
                gap: 10px;
            }

            .review-header .rating {
                margin-left: 0;
            }
        }

        /* 动画效果 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <header>
        <div class="container nav-container">
            <div class="logo">
                <i class="fas fa-gamepad"></i>
                <span><?php echo getSetting('site_name', SITE_NAME); ?></span>
            </div>
            <div class="search-box">
                <form action="../search/index.php" method="get">
                    <input type="text" name="keyword" placeholder="搜索应用...">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>
            <div class="user-menu">
                <a href="index.php"><i class="fas fa-user"></i> <?php echo $_SESSION['username']; ?></a>
                <a href="logout.php" onclick="return confirm('确定要退出登录吗？');"><i class="fas fa-sign-out-alt"></i> 退出</a>
                <?php if (isAdmin()): ?>
                    <a href="../admin/index.php"><i class="fas fa-cog"></i> 管理</a>
                <?php endif; ?>
            </div>
            <!-- 移动端菜单按钮 -->
            <button class="mobile-menu-btn" onclick="toggleMobileMenu()">
                <i class="fas fa-bars"></i>
            </button>
            <!-- 移动端下拉菜单 -->
            <div class="mobile-menu-dropdown">
                <a href="index.php"><i class="fas fa-user"></i> <?php echo $_SESSION['username']; ?></a>
                <a href="logout.php" onclick="return confirm('确定要退出登录吗？');"><i class="fas fa-sign-out-alt"></i> 退出</a>
                <?php if (isAdmin()): ?>
                    <a href="../admin/index.php"><i class="fas fa-cog"></i> 管理</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <div class="container">
        <!-- 用户中心 -->
        <div class="user-center fade-in">
            <!-- 用户资料 -->
            <div class="user-profile">
                <div class="user-avatar">
                    <?php if (!empty($user['avatar'])): ?>
                        <img src="../<?php echo $user['avatar']; ?>" alt="<?php echo $user['username']; ?>">
                    <?php else: ?>
                        <?php echo substr($user['username'], 0, 1); ?>
                    <?php endif; ?>
                </div>
                <div class="user-info">
                    <h1><?php echo $user['username']; ?></h1>
                    <p>邮箱: <?php echo $user['email']; ?></p>
                    <p>注册时间: <?php echo date('Y-m-d H:i:s', strtotime($user['created_at'])); ?></p>
                    <a href="edit_profile.php" class="edit-profile-btn">
                        <i class="fas fa-edit"></i> 编辑个人资料
                    </a>
                    <?php if ($user['can_publish'] ?? 1): ?>
                    <a href="publish_app.php" class="edit-profile-btn" style="margin-left: 10px; background: var(--secondary-color);">
                        <i class="fas fa-plus-circle"></i> 发布应用
                    </a>
                    <?php else: ?>
                    <span class="edit-profile-btn" style="margin-left: 10px; background: #ccc; cursor: not-allowed;" title="您的发布权限已被禁用">
                        <i class="fas fa-ban"></i> 发布权限已禁用
                    </span>
                    <?php endif; ?>
                    <div class="user-stats">
                        <div class="stat-item">
                            <div class="stat-value"><?php echo count($downloads); ?></div>
                            <div class="stat-label">下载应用</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value"><?php echo count($reviews); ?></div>
                            <div class="stat-label">发表评论</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value"><?php echo count($publishedApps); ?></div>
                            <div class="stat-label">平台应用数</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 标签页 -->
            <div class="tabs">
                <div class="tab active" onclick="switchTab('downloads')">我的下载</div>
                <div class="tab" onclick="switchTab('reviews')">我的评论</div>
                <div class="tab" onclick="switchTab('published')">平台应用</div>
            </div>

            <div class="tab-content">
                <!-- 下载记录 -->
                <div id="downloads" class="tab-pane active">
                    <?php if (empty($downloads)): ?>
                        <div class="no-data">
                            <i class="fas fa-download"></i>
                            <h3>暂无下载记录</h3>
                            <p>去下载一些应用吧</p>
                        </div>
                    <?php else: ?>
                        <div class="download-list">
                            <?php foreach ($downloads as $download): ?>
                                <div class="download-item">
                                    <div class="app-icon">
                                        <img src="https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=anime%20style%20app%20icon%20cute%20colorful&image_size=square" alt="<?php echo $download['name']; ?>">
                                    </div>
                                    <div class="app-info">
                                        <div class="app-name"><?php echo $download['name']; ?></div>
                                        <div class="download-time">下载时间: <?php echo date('Y-m-d H:i:s', strtotime($download['download_time'])); ?></div>
                                    </div>
                                    <a href="../app/download.php?id=<?php echo $download['app_id']; ?>" class="btn">重新下载</a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- 评论记录 -->
                <div id="reviews" class="tab-pane">
                    <?php if (empty($reviews)): ?>
                        <div class="no-data">
                            <i class="fas fa-comment"></i>
                            <h3>暂无评论记录</h3>
                            <p>去给应用发表评论吧</p>
                        </div>
                    <?php else: ?>
                        <div class="review-list">
                            <?php foreach ($reviews as $review): ?>
                                <div class="review-item">
                                    <div class="review-header">
                                        <div class="app-icon">
                                            <img src="https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=anime%20style%20app%20icon%20cute%20colorful&image_size=square" alt="<?php echo $review['name']; ?>">
                                        </div>
                                        <div class="app-name"><?php echo $review['name']; ?></div>
                                        <div class="rating">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <i class="fas fa-star<?php echo $i <= $review['rating'] ? '' : '-empty'; ?>"></i>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                    <div class="review-content">
                                        <?php echo $review['content']; ?>
                                    </div>
                                    <div class="review-time">
                                        评论时间: <?php echo date('Y-m-d H:i:s', strtotime($review['created_at'])); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- 我的发布 -->
                <div id="published" class="tab-pane">
                    <div style="margin-bottom: 20px;">
                        <?php if ($user['can_publish'] ?? 1): ?>
                        <a href="publish_app.php" class="edit-profile-btn" style="display: inline-flex;">
                            <i class="fas fa-plus-circle"></i> 发布新应用
                        </a>
                        <?php else: ?>
                        <span class="edit-profile-btn" style="display: inline-flex; background: #ccc; cursor: not-allowed;" title="您的发布权限已被禁用">
                            <i class="fas fa-ban"></i> 发布权限已禁用
                        </span>
                        <?php endif; ?>
                    </div>
                    <?php if (empty($publishedApps)): ?>
                        <div class="no-data">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <h3>暂无发布应用</h3>
                            <p>点击上方按钮发布你的第一个应用</p>
                        </div>
                    <?php else: ?>
                        <div class="download-list">
                            <?php foreach ($publishedApps as $app): ?>
                                <div class="download-item">
                                    <div class="app-icon">
                                        <?php if (!empty($app['icon'])): ?>
                                            <img src="../<?php echo $app['icon']; ?>" alt="<?php echo $app['name']; ?>">
                                        <?php else: ?>
                                            <img src="../assets/images/default-app-icon.svg" alt="<?php echo $app['name']; ?>">
                                        <?php endif; ?>
                                    </div>
                                    <div class="app-info">
                                        <div class="app-name"><?php echo $app['name']; ?></div>
                                        <div class="download-time">版本: <?php echo $app['version']; ?> | 大小: <?php echo $app['size']; ?> | 下载: <?php echo number_format($app['download_count']); ?>次</div>
                                    </div>
                                    <a href="../app/index.php?id=<?php echo $app['id']; ?>" class="btn">查看详情</a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- 页脚 -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>关于我们</h3>
                    <ul>
                        <li><a href="#">公司简介</a></li>
                        <li><a href="#">联系我们</a></li>
                        <li><a href="#">加入我们</a></li>
                        <li><a href="#">隐私政策</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>帮助中心</h3>
                    <ul>
                        <li><a href="#">常见问题</a></li>
                        <li><a href="#">下载指南</a></li>
                        <li><a href="#">应用提交</a></li>
                        <li><a href="#">开发者中心</a></li>
                        <li><a href="../feedback/index.php"><i class="fas fa-comment-dots"></i> 意见反馈</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>关注我们</h3>
                    <ul>
                        <li><a href="#"><i class="fab fa-weibo"></i> 微博</a></li>
                        <li><a href="#"><i class="fab fa-wechat"></i> 微信</a></li>
                        <li><a href="#"><i class="fab fa-qq"></i> QQ</a></li>
                        <li><a href="#"><i class="fab fa-github"></i> GitHub</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>下载客户端</h3>
                    <p>扫描二维码下载客户端</p>
                    <?php
                        $clientDownloadUrl = getSetting('client_download_url', '');
                        if (!empty($clientDownloadUrl)) {
                            // 使用Google Charts API生成二维码
                            $encodedUrl = urlencode($clientDownloadUrl);
                            $qrcodeUrl = "https://api.qrserver.com/v1/create-qr-code/?size=120x120&data={$encodedUrl}";
                            echo '<img src="' . $qrcodeUrl . '" alt="客户端下载二维码" style="width: 120px; height: 120px; margin-top: 10px;">';
                        } else {
                            echo '<div style="width: 120px; height: 120px; background: white; margin-top: 10px; display: flex; align-items: center; justify-content: center; color: #999; font-size: 12px;">请在后台设置下载URL</div>';
                        }
                    ?>
                </div>
            </div>
            <div class="footer-bottom">
                <p><?php echo getSetting('copyright', '&copy; 2026 ' . getSetting('site_name', SITE_NAME) . ' 版权所有'); ?></p>
            </div>
        </div>
    </footer>

    <script>
        // 标签页切换
        function switchTab(tabId) {
            // 移除所有标签的活跃状态
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            // 移除所有内容的活跃状态
            document.querySelectorAll('.tab-pane').forEach(pane => {
                pane.classList.remove('active');
            });
            // 添加当前标签的活跃状态
            event.currentTarget.classList.add('active');
            // 添加当前内容的活跃状态
            document.getElementById(tabId).classList.add('active');
        }

        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const fadeElements = document.querySelectorAll('.fade-in');
            fadeElements.forEach((element, index) => {
                element.style.animationDelay = `${index * 0.1}s`;
            });
        });

        // 移动端菜单切换
        function toggleMobileMenu() {
            const dropdown = document.querySelector('.mobile-menu-dropdown');
            dropdown.classList.toggle('show');
        }

        // 点击页面其他地方关闭菜单
        document.addEventListener('click', function(event) {
            const menuBtn = document.querySelector('.mobile-menu-btn');
            const dropdown = document.querySelector('.mobile-menu-dropdown');
            if (!menuBtn.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });
    </script>
</body>
</html>