<?php
session_start();
require_once '../include/functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$db = getDB();
$user_id = $_SESSION['user_id'];
$user = getCurrentUser();

$error = '';
$success = '';

if (isset($_POST['update_profile'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $avatar = $user['avatar']; // 默认保持原头像
    
    // 处理头像上传
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/avatars/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($file_extension, $allowed_extensions)) {
            $file_name = uniqid() . '.' . $file_extension;
            $target_path = $upload_dir . $file_name;
            
            if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target_path)) {
                // 删除旧头像
                if (!empty($user['avatar']) && file_exists('../' . $user['avatar'])) {
                    unlink('../' . $user['avatar']);
                }
                $avatar = 'uploads/avatars/' . $file_name;
            }
        }
    }
    
    // 验证输入
    if (empty($username) || empty($email)) {
        $error = '用户名和邮箱不能为空';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = '邮箱格式不正确';
    } else {
        // 检查用户名和邮箱是否被其他用户使用
        $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE (username = ? OR email = ?) AND id != ?");
        $stmt->execute([$username, $email, $user_id]);
        if ($stmt->fetchColumn() > 0) {
            $error = '用户名或邮箱已被其他用户使用';
        } else {
            // 如果需要修改密码
            if (!empty($new_password)) {
                // 验证当前密码
                if (empty($current_password)) {
                    $error = '请输入当前密码';
                } elseif (!password_verify($current_password, $user['password'])) {
                    $error = '当前密码不正确';
                } elseif (strlen($new_password) < 6) {
                    $error = '新密码长度至少为6位';
                } elseif ($new_password !== $confirm_password) {
                    $error = '两次输入的新密码不一致';
                } else {
                    // 更新用户名、邮箱、密码和头像
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $stmt = $db->prepare("UPDATE users SET username = ?, email = ?, password = ?, avatar = ? WHERE id = ?");
                    if ($stmt->execute([$username, $email, $hashed_password, $avatar, $user_id])) {
                        // 更新session中的用户名
                        $_SESSION['username'] = $username;
                        $success = '个人信息、头像和密码修改成功';
                        // 刷新用户信息
                        $user = getCurrentUser();
                    } else {
                        $error = '修改失败';
                    }
                }
            } else {
                // 只更新用户名、邮箱和头像
                $stmt = $db->prepare("UPDATE users SET username = ?, email = ?, avatar = ? WHERE id = ?");
                if ($stmt->execute([$username, $email, $avatar, $user_id])) {
                    // 更新session中的用户名
                    $_SESSION['username'] = $username;
                    $success = '个人信息和头像修改成功';
                    // 刷新用户信息
                    $user = getCurrentUser();
                } else {
                    $error = '修改失败';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>编辑个人资料 - <?php echo getSetting('site_name', SITE_NAME); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }

        /* 导航栏 */
        header {
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            color: white;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .logo {
            font-size: 20px;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: white;
        }

        .back-link {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .back-link:hover {
            transform: translateX(-3px);
        }

        /* 编辑卡片 */
        .edit-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 30px;
            margin-top: 30px;
        }

        .edit-card h1 {
            font-size: 24px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .edit-card h1 i {
            color: var(--primary-color);
        }

        .edit-card .subtitle {
            color: var(--text-color);
            margin-bottom: 25px;
            font-size: 14px;
        }

        /* 提示信息 */
        .alert {
            padding: 12px 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .alert-error {
            background: #ffebee;
            color: #c62828;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
        }

        /* 表单样式 */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .form-group label .required {
            color: #e74c3c;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(255, 107, 157, 0.1);
        }

        .form-group .input-hint {
            font-size: 12px;
            color: #999;
            margin-top: 5px;
        }

        /* 头像上传 */
        .avatar-upload {
            text-align: center;
            margin-bottom: 25px;
        }

        .avatar-preview {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid var(--primary-color);
            margin-bottom: 15px;
            background: var(--light-color);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .avatar-upload input[type="file"] {
            display: none;
        }

        .avatar-upload label {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            border-radius: 25px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .avatar-upload label:hover {
            background: #ff528b;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 107, 157, 0.3);
        }

        /* 密码输入框 */
        .password-input {
            position: relative;
        }

        .password-input input {
            padding-right: 45px;
        }

        .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #999;
            transition: all 0.3s ease;
        }

        .toggle-password:hover {
            color: var(--primary-color);
        }

        /* 分隔线 */
        .divider {
            border: none;
            border-top: 1px solid #eee;
            margin: 25px 0;
        }

        .section-title {
            font-size: 16px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .section-title i {
            color: var(--primary-color);
        }

        /* 按钮 */
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 25px;
        }

        .btn {
            flex: 1;
            padding: 12px 24px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            text-decoration: none;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: #ff528b;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 107, 157, 0.3);
        }

        .btn-secondary {
            background: var(--light-color);
            color: var(--dark-color);
            border: 1px solid #ddd;
        }

        .btn-secondary:hover {
            background: #e8e8e8;
            transform: translateY(-2px);
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }

            .edit-card {
                padding: 20px;
                margin-top: 20px;
            }

            .edit-card h1 {
                font-size: 20px;
            }

            .form-actions {
                flex-direction: column;
            }
        }

        /* 动画效果 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <header>
        <div class="nav-container">
            <a href="index.php" class="back-link">
                <i class="fas fa-arrow-left"></i> 返回个人中心
            </a>
            <a href="../index.php" class="logo">
                <i class="fas fa-gamepad"></i>
                <span><?php echo getSetting('site_name', SITE_NAME); ?></span>
            </a>
        </div>
    </header>

    <div class="container">
        <div class="edit-card fade-in">
            <h1><i class="fas fa-user-edit"></i> 编辑个人资料</h1>
            <p class="subtitle">修改您的个人信息和密码</p>

            <?php if (!empty($error)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <form action="edit_profile.php" method="post" enctype="multipart/form-data">
                <!-- 头像上传 -->
                <div class="avatar-upload">
                    <img src="<?php echo !empty($user['avatar']) ? '../' . $user['avatar'] : '../assets/images/default-avatar.svg'; ?>" alt="头像预览" class="avatar-preview" id="avatarPreview">
                    <br>
                    <label for="avatar">
                        <i class="fas fa-camera"></i> 更换头像
                    </label>
                    <input type="file" id="avatar" name="avatar" accept="image/*" onchange="previewAvatar(this)">
                </div>

                <!-- 基本信息 -->
                <div class="section-title">
                    <i class="fas fa-info-circle"></i> 基本信息
                </div>

                <div class="form-group">
                    <label for="username">
                        用户名 <span class="required">*</span>
                    </label>
                    <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required placeholder="请输入用户名">
                </div>

                <div class="form-group">
                    <label for="email">
                        邮箱 <span class="required">*</span>
                    </label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required placeholder="请输入邮箱">
                </div>

                <hr class="divider">

                <!-- 修改密码 -->
                <div class="section-title">
                    <i class="fas fa-lock"></i> 修改密码
                </div>
                <p class="subtitle" style="margin-top: -10px;">如需修改密码，请填写以下字段</p>

                <div class="form-group">
                    <label for="current_password">当前密码</label>
                    <div class="password-input">
                        <input type="password" id="current_password" name="current_password" placeholder="请输入当前密码">
                        <span class="toggle-password" onclick="togglePassword('current_password')">
                            <i class="fas fa-eye"></i>
                        </span>
                    </div>
                </div>

                <div class="form-group">
                    <label for="new_password">新密码</label>
                    <div class="password-input">
                        <input type="password" id="new_password" name="new_password" placeholder="请输入新密码（至少6位）">
                        <span class="toggle-password" onclick="togglePassword('new_password')">
                            <i class="fas fa-eye"></i>
                        </span>
                    </div>
                    <p class="input-hint">密码长度至少为6位</p>
                </div>

                <div class="form-group">
                    <label for="confirm_password">确认新密码</label>
                    <div class="password-input">
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="请再次输入新密码">
                        <span class="toggle-password" onclick="togglePassword('confirm_password')">
                            <i class="fas fa-eye"></i>
                        </span>
                    </div>
                </div>

                <div class="form-actions">
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> 取消
                    </a>
                    <button type="submit" name="update_profile" class="btn btn-primary">
                        <i class="fas fa-save"></i> 保存修改
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // 密码显示/隐藏切换
        function togglePassword(inputId) {
            const passwordInput = document.getElementById(inputId);
            const toggleIcon = passwordInput.parentElement.querySelector('.toggle-password i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }

        // 头像预览
        function previewAvatar(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('avatarPreview').src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</body>
</html>
