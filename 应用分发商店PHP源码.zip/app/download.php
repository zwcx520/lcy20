<?php
session_start();
require_once '../include/functions.php';

if (!isset($_GET['id'])) {
    header('Location: ../index.php');
    exit;
}

$app_id = intval($_GET['id']);
$app = getAppById($app_id);

if (!$app) {
    header('Location: ../index.php');
    exit;
}

// 检查是否有下载链接
if (empty($app['download_url'])) {
    header('Location: ../app/index.php?id=' . $app_id . '&error=no_download_url');
    exit;
}

// 获取文件路径
$file_path = $app['download_url'];

// 构建完整文件路径
$full_path = '../' . $file_path;

// 调试信息（开发时使用，生产环境请删除）
error_log('Download - App ID: ' . $app_id);
error_log('Download - File path from DB: ' . $file_path);
error_log('Download - Full path: ' . $full_path);
error_log('Download - File exists: ' . (file_exists($full_path) ? 'yes' : 'no'));

// 检查文件是否存在
if (!file_exists($full_path)) {
    header('Location: ../app/index.php?id=' . $app_id . '&error=file_not_found');
    exit;
}

// 检查文件是否可读
if (!is_readable($full_path)) {
    header('Location: ../app/index.php?id=' . $app_id . '&error=file_not_readable');
    exit;
}

// 获取文件信息
$file_name = basename($full_path);
$file_size = filesize($full_path);
$file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

// 构建友好的下载文件名：应用名称_版本号.扩展名
$safe_app_name = preg_replace('/[^\w\-\.\s]/', '_', $app['name']);
$safe_version = preg_replace('/[^\w\-\.]/', '_', $app['version']);
$download_file_name = $safe_app_name . '_v' . $safe_version . '.' . $file_extension;

// 根据文件类型设置正确的 Content-Type
$content_types = [
    'apk' => 'application/vnd.android.package-archive',
    'ipa' => 'application/octet-stream',
    'exe' => 'application/x-msdownload',
    'dmg' => 'application/x-apple-diskimage',
    'zip' => 'application/zip',
    'rar' => 'application/x-rar-compressed',
    '7z' => 'application/x-7z-compressed',
    'pdf' => 'application/pdf',
    'txt' => 'text/plain'
];

$content_type = isset($content_types[$file_extension]) ? $content_types[$file_extension] : 'application/octet-stream';

// 增加下载次数
incrementDownloadCount($app_id);

// 记录下载日志
$log_file = '../logs/downloads.log';
$log_dir = dirname($log_file);
if (!file_exists($log_dir)) {
    mkdir($log_dir, 0777, true);
}
$log_message = date('Y-m-d H:i:s') . ' | ';
$log_message .= 'App: ' . $app['name'] . ' (ID: ' . $app_id . ') | ';
$log_message .= 'File: ' . $file_path . ' | ';
$log_message .= 'Size: ' . $file_size . ' bytes | ';
$log_message .= 'IP: ' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . ' | ';
$log_message .= 'User: ' . (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'guest') . PHP_EOL;
file_put_contents($log_file, $log_message, FILE_APPEND | LOCK_EX);

// 设置下载头
header('Content-Type: ' . $content_type);
header('Content-Disposition: attachment; filename="' . $download_file_name . '"');
header('Content-Length: ' . $file_size);
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// 清除输出缓冲
ob_clean();
flush();

// 大文件分块读取，避免内存溢出
$chunk_size = 1024 * 1024; // 1MB
$handle = fopen($full_path, 'rb');

while (!feof($handle)) {
    echo fread($handle, $chunk_size);
    flush();
}

fclose($handle);
exit;
?>
