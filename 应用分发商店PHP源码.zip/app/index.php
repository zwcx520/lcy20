<?php
session_start();
require_once '../include/functions.php';

if (!isset($_GET['id'])) {
    header('Location: ../index.php');
    exit;
}

$app_id = $_GET['id'];
$app = getAppById($app_id);

if (!$app) {
    header('Location: ../index.php');
    exit;
}

// 获取应用评论
$reviews = getAppReviews($app_id);

// 处理评论提交
if (isLoggedIn() && isset($_POST['submit_review'])) {
    $content = $_POST['content'];
    $rating = $_POST['rating'];
    $user_id = $_SESSION['user_id'];
    
    if (addReview($app_id, $user_id, $content, $rating)) {
        header('Location: index.php?id=' . $app_id);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $app['name']; ?> - <?php echo getSetting('site_name', SITE_NAME); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* 导航栏 */
        header {
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            color: white;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
        }

        .logo {
            font-size: 20px;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .logo i {
            font-size: 24px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .search-box {
            flex: 1;
            max-width: 400px;
            margin: 0 20px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 8px 12px;
            border: none;
            border-radius: 30px;
            font-size: 14px;
            outline: none;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .search-box button {
            position: absolute;
            right: 5px;
            top: 50%;
            transform: translateY(-50%);
            background: var(--secondary-color);
            border: none;
            border-radius: 50%;
            width: 26px;
            height: 26px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .search-box button:hover {
            background: var(--accent-color);
            transform: translateY(-50%) scale(1.1);
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-menu a {
            color: white;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .user-menu a:hover {
            transform: translateY(-2px);
        }

        /* 移动端菜单按钮 */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            padding: 5px;
        }

        .mobile-menu-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border-radius: 8px;
            box-shadow: var(--box-shadow);
            min-width: 150px;
            z-index: 1001;
            margin-top: 5px;
        }

        .mobile-menu-dropdown a {
            display: block;
            padding: 10px 15px;
            color: var(--dark-color);
            text-decoration: none;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .mobile-menu-dropdown a:hover {
            background-color: var(--light-color);
        }

        .mobile-menu-dropdown.show {
            display: block;
        }

        /* 应用详情 */
        .app-detail {
            margin: 30px 0;
            background: white;
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--box-shadow);
        }

        .app-header {
            display: flex;
            padding: 30px;
            border-bottom: 1px solid #eee;
        }

        .app-icon-large {
            width: 120px;
            height: 120px;
            border-radius: 24px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            margin-right: 30px;
        }

        .app-icon-large img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .app-info {
            flex: 1;
        }

        .app-info h1 {
            font-size: 28px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 10px;
        }

        .app-meta {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 20px;
        }

        .app-category {
            background: var(--light-color);
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 14px;
            color: var(--text-color);
        }

        .app-rating {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .app-rating i {
            color: #ffd700;
            font-size: 16px;
        }

        .app-rating span {
            font-size: 16px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .app-stats {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            font-size: 14px;
            color: var(--text-color);
        }

        .app-buttons {
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 30px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: #ff528b;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 107, 157, 0.3);
        }

        .btn-secondary {
            background: var(--light-color);
            color: var(--dark-color);
            border: 1px solid #ddd;
        }

        .btn-secondary:hover {
            background: #e8e8e8;
            transform: translateY(-2px);
        }

        /* 标签页 */
        .tabs {
            display: flex;
            border-bottom: 1px solid #eee;
        }

        .tab {
            padding: 15px 30px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            color: var(--text-color);
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
        }

        .tab.active {
            color: var(--primary-color);
            border-bottom-color: var(--primary-color);
        }

        .tab-content {
            padding: 30px;
        }

        .tab-pane {
            display: none;
        }

        .tab-pane.active {
            display: block;
        }

        /* 应用截图 */
        .screenshot-carousel {
            position: relative;
            margin: 20px 0;
        }

        .screenshot-inner {
            display: flex;
            overflow-x: auto;
            gap: 15px;
            padding: 10px 0;
        }

        .screenshot-item {
            min-width: 200px;
            height: 350px;
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--box-shadow);
            flex-shrink: 0;
        }

        .screenshot-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* 应用描述 */
        .app-description {
            line-height: 1.8;
            color: var(--text-color);
            margin-bottom: 20px;
        }

        .app-description p {
            margin-bottom: 15px;
        }

        /* 评论区 */
        .review-section {
            margin-top: 30px;
        }

        .review-form {
            background: var(--light-color);
            padding: 20px;
            border-radius: var(--border-radius);
            margin-bottom: 30px;
        }

        .review-form h3 {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
            color: var(--dark-color);
        }

        .review-form .form-group {
            margin-bottom: 15px;
        }

        .review-form label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .review-form textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            resize: vertical;
            min-height: 100px;
            font-size: 14px;
        }

        .review-form .rating-input {
            display: flex;
            gap: 10px;
        }

        .review-form .rating-input input {
            display: none;
        }

        .review-form .rating-input label {
            cursor: pointer;
            font-size: 24px;
            color: #ddd;
            transition: all 0.3s ease;
        }

        .review-form .rating-input input:checked ~ label,
        .review-form .rating-input label:hover,
        .review-form .rating-input label:hover ~ label {
            color: #ffd700;
        }

        .review-list {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .review-item {
            background: var(--light-color);
            padding: 20px;
            border-radius: var(--border-radius);
        }

        .review-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }

        .review-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            overflow: hidden;
            background: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }

        .review-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .review-meta {
            flex: 1;
        }

        .review-username {
            font-weight: 500;
            color: var(--dark-color);
            margin-bottom: 2px;
        }

        .review-time {
            font-size: 12px;
            color: #999;
        }

        .review-content {
            line-height: 1.6;
            color: var(--text-color);
            margin-top: 10px;
        }

        /* 页脚 */
        footer {
            background: var(--dark-color);
            color: white;
            padding: 40px 0;
            margin-top: 50px;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
        }

        .footer-section h3 {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 20px;
            color: var(--primary-color);
        }

        .footer-section ul {
            list-style: none;
        }

        .footer-section ul li {
            margin-bottom: 10px;
        }

        .footer-section ul li a {
            color: #ddd;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-section ul li a:hover {
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            margin-top: 30px;
            border-top: 1px solid #555;
            font-size: 14px;
            color: #999;
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
            .nav-container {
                flex-direction: row;
                gap: 10px;
                padding: 8px 15px;
            }

            .logo {
                font-size: 16px;
            }

            .logo i {
                font-size: 20px;
            }

            .search-box {
                flex: 1;
                max-width: none;
                margin: 0 10px;
            }

            .search-box input {
                padding: 6px 10px;
                font-size: 12px;
            }

            .search-box button {
                width: 24px;
                height: 24px;
                font-size: 12px;
            }

            .user-menu {
                display: none;
            }

            .mobile-menu-btn {
                display: block;
            }

            .app-header {
                flex-direction: column;
                text-align: center;
                padding: 20px;
            }

            .app-icon-large {
                margin-right: 0;
                margin-bottom: 20px;
            }

            .app-meta {
                justify-content: center;
            }

            .app-stats {
                justify-content: center;
            }

            .app-buttons {
                justify-content: center;
            }

            .tabs {
                overflow-x: auto;
                white-space: nowrap;
            }

            .tab {
                padding: 15px 20px;
            }

            .tab-content {
                padding: 20px;
            }

            .screenshot-item {
                min-width: 150px;
                height: 250px;
            }
        }

        /* 动画效果 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <header>
        <div class="container nav-container">
            <div class="logo">
                <i class="fas fa-gamepad"></i>
                <span><?php echo getSetting('site_name', SITE_NAME); ?></span>
            </div>
            <div class="search-box">
                <form action="../search/index.php" method="get">
                    <input type="text" name="keyword" placeholder="搜索应用...">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>
            <div class="user-menu">
                <?php if (isLoggedIn()): ?>
                    <a href="../user/index.php"><i class="fas fa-user"></i> <?php echo $_SESSION['username']; ?></a>
                    <a href="../user/logout.php"><i class="fas fa-sign-out-alt"></i> 退出</a>
                <?php else: ?>
                    <a href="../user/login.php"><i class="fas fa-sign-in-alt"></i> 登录</a>
                    <a href="../user/register.php"><i class="fas fa-user-plus"></i> 注册</a>
                <?php endif; ?>
                <?php if (isAdmin()): ?>
                    <a href="../admin/index.php"><i class="fas fa-cog"></i> 管理</a>
                <?php endif; ?>
            </div>
            <!-- 移动端菜单按钮 -->
            <button class="mobile-menu-btn" onclick="toggleMobileMenu()">
                <i class="fas fa-bars"></i>
            </button>
            <!-- 移动端下拉菜单 -->
            <div class="mobile-menu-dropdown">
                <?php if (isLoggedIn()): ?>
                    <a href="../user/index.php"><i class="fas fa-user"></i> <?php echo $_SESSION['username']; ?></a>
                    <a href="../user/logout.php"><i class="fas fa-sign-out-alt"></i> 退出</a>
                <?php else: ?>
                    <a href="../user/login.php"><i class="fas fa-sign-in-alt"></i> 登录</a>
                    <a href="../user/register.php"><i class="fas fa-user-plus"></i> 注册</a>
                <?php endif; ?>
                <?php if (isAdmin()): ?>
                    <a href="../admin/index.php"><i class="fas fa-cog"></i> 管理</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <div class="container">
        <!-- 错误提示 -->
        <?php if (isset($_GET['error'])): ?>
            <div style="background: #ffebee; color: #c62828; padding: 15px; border-radius: 12px; margin: 20px 0; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-exclamation-circle" style="font-size: 20px;"></i>
                <span>
                <?php 
                    switch ($_GET['error']) {
                        case 'file_not_found':
                            echo '应用文件不存在或已被删除，请联系管理员';
                            break;
                        case 'file_not_readable':
                            echo '应用文件无法读取，请联系管理员';
                            break;
                        case 'no_download_url':
                            echo '该应用暂无下载文件';
                            break;
                        default:
                            echo '下载失败，请稍后重试';
                    }
                ?>
                </span>
            </div>
        <?php endif; ?>
        
        <!-- 应用详情 -->
        <div class="app-detail fade-in">
            <div class="app-header">
                <div class="app-icon-large">
                    <?php if (!empty($app['icon'])): ?>
                        <img src="../<?php echo $app['icon']; ?>" alt="<?php echo $app['name']; ?>">
                    <?php else: ?>
                        <img src="../assets/images/default-app-icon.svg" alt="<?php echo $app['name']; ?>">
                    <?php endif; ?>
                </div>
                <div class="app-info">
                    <h1><?php echo $app['name']; ?></h1>
                    <div class="app-meta">
                        <span class="app-category"><?php echo $app['category_name']; ?></span>
                        <div class="app-rating">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="fas fa-star<?php echo $i <= $app['rating'] ? '' : '-empty'; ?>"></i>
                            <?php endfor; ?>
                            <span><?php echo number_format($app['rating'], 1); ?></span>
                        </div>
                    </div>
                    <div class="app-stats">
                        <span>版本: <?php echo $app['version']; ?></span>
                        <span>大小: <?php echo $app['size']; ?></span>
                        <span>下载: <?php echo number_format($app['download_count']); ?>次</span>
                        <span>更新: <?php echo date('Y-m-d', strtotime($app['updated_at'])); ?></span>
                    </div>
                    <div class="app-buttons">
                        <?php if (!empty($app['download_url'])): ?>
                            <?php
                                // 获取文件扩展名和对应的图标
                                $file_ext = strtolower(pathinfo($app['download_url'], PATHINFO_EXTENSION));
                                $file_icons = [
                                    'apk' => 'fa-android',
                                    'ipa' => 'fa-apple',
                                    'exe' => 'fa-windows',
                                    'dmg' => 'fa-apple',
                                    'zip' => 'fa-file-archive',
                                    'rar' => 'fa-file-archive',
                                    '7z' => 'fa-file-archive',
                                    'pdf' => 'fa-file-pdf'
                                ];
                                $file_icon = isset($file_icons[$file_ext]) ? $file_icons[$file_ext] : 'fa-file';
                            ?>
                            <button onclick="downloadApp(<?php echo $app['id']; ?>)" class="btn btn-primary">
                                <i class="fas fa-download"></i> 下载
                            </button>
                            <span style="color: #999; font-size: 12px; margin-left: 10px; display: flex; align-items: center; gap: 5px;">
                                <i class="fas <?php echo $file_icon; ?>"></i>
                                <?php echo basename($app['download_url']); ?>
                            </span>
                        <?php else: ?>
                            <button class="btn btn-secondary" disabled>
                                <i class="fas fa-download"></i> 暂无下载
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- 标签页 -->
            <div class="tabs">
                <div class="tab active" onclick="switchTab('description')">应用介绍</div>
                <div class="tab" onclick="switchTab('screenshots')">应用截图</div>
                <div class="tab" onclick="switchTab('reviews')">用户评论</div>
            </div>

            <!-- 标签内容 -->
            <div class="tab-content">
                <div id="description" class="tab-pane active">
                    <div class="app-description">
                        <?php echo nl2br($app['description']); ?>
                    </div>
                    <h3>应用信息</h3>
                    <ul style="list-style: none; margin-top: 15px;">
                        <li style="margin-bottom: 10px;"><strong>应用名称:</strong> <?php echo $app['name']; ?></li>
                        <li style="margin-bottom: 10px;"><strong>应用分类:</strong> <?php echo $app['category_name']; ?></li>
                        <li style="margin-bottom: 10px;"><strong>当前版本:</strong> <?php echo $app['version']; ?></li>
                        <li style="margin-bottom: 10px;"><strong>应用大小:</strong> <?php echo $app['size']; ?></li>
                        <?php if (!empty($app['download_url'])): ?>
                            <?php
                                $file_ext = strtolower(pathinfo($app['download_url'], PATHINFO_EXTENSION));
                                $file_type_names = [
                                    'apk' => 'Android 应用',
                                    'ipa' => 'iOS 应用',
                                    'exe' => 'Windows 程序',
                                    'dmg' => 'macOS 应用',
                                    'zip' => 'ZIP 压缩包',
                                    'rar' => 'RAR 压缩包',
                                    '7z' => '7Z 压缩包',
                                    'pdf' => 'PDF 文档'
                                ];
                                $file_type_name = isset($file_type_names[$file_ext]) ? $file_type_names[$file_ext] : strtoupper($file_ext) . ' 文件';
                            ?>
                            <li style="margin-bottom: 10px;"><strong>文件名称:</strong> <?php echo basename($app['download_url']); ?></li>
                            <li style="margin-bottom: 10px;"><strong>文件类型:</strong> <?php echo $file_type_name; ?></li>
                        <?php endif; ?>
                        <li style="margin-bottom: 10px;"><strong>下载次数:</strong> <?php echo number_format($app['download_count']); ?>次</li>
                        <li style="margin-bottom: 10px;"><strong>评分:</strong> <?php echo number_format($app['rating'], 1); ?> (满分5分)</li>
                        <li style="margin-bottom: 10px;"><strong>发布时间:</strong> <?php echo date('Y-m-d H:i:s', strtotime($app['created_at'])); ?></li>
                        <li style="margin-bottom: 10px;"><strong>更新时间:</strong> <?php echo date('Y-m-d H:i:s', strtotime($app['updated_at'])); ?></li>
                    </ul>
                </div>

                <div id="screenshots" class="tab-pane">
                    <div class="screenshot-carousel">
                        <div class="screenshot-inner">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <div class="screenshot-item">
                                    <img src="https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=anime%20style%20app%20screenshot%20cute%20colorful&image_size=portrait_16_9" alt="截图<?php echo $i; ?>">
                                </div>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>

                <div id="reviews" class="tab-pane">
                    <?php if (isLoggedIn()): ?>
                        <div class="review-form">
                            <h3>发表评论</h3>
                            <form action="index.php?id=<?php echo $app['id']; ?>" method="post">
                                <div class="form-group">
                                    <label for="rating">评分:</label>
                                    <div class="rating-input">
                                        <input type="radio" id="star5" name="rating" value="5" checked>
                                        <label for="star5"><i class="fas fa-star"></i></label>
                                        <input type="radio" id="star4" name="rating" value="4">
                                        <label for="star4"><i class="fas fa-star"></i></label>
                                        <input type="radio" id="star3" name="rating" value="3">
                                        <label for="star3"><i class="fas fa-star"></i></label>
                                        <input type="radio" id="star2" name="rating" value="2">
                                        <label for="star2"><i class="fas fa-star"></i></label>
                                        <input type="radio" id="star1" name="rating" value="1">
                                        <label for="star1"><i class="fas fa-star"></i></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="content">评论内容:</label>
                                    <textarea name="content" id="content" required></textarea>
                                </div>
                                <button type="submit" name="submit_review" class="btn btn-primary">提交评论</button>
                            </form>
                        </div>
                    <?php else: ?>
                        <div style="background: var(--light-color); padding: 20px; border-radius: var(--border-radius); margin-bottom: 30px; text-align: center;">
                            <p>请 <a href="../user/login.php" style="color: var(--primary-color); text-decoration: none;">登录</a> 后发表评论</p>
                        </div>
                    <?php endif; ?>

                    <div class="review-list">
                        <?php if (empty($reviews)): ?>
                            <p>暂无评论</p>
                        <?php else: ?>
                            <?php foreach ($reviews as $review): ?>
                                <div class="review-item">
                                    <div class="review-header">
                                        <div class="review-avatar">
                                            <?php if (!empty($review['avatar'])): ?>
                                                <img src="../<?php echo $review['avatar']; ?>" alt="<?php echo $review['username']; ?>">
                                            <?php else: ?>
                                                <?php echo substr($review['username'], 0, 1); ?>
                                            <?php endif; ?>
                                        </div>
                                        <div class="review-meta">
                                            <div class="review-username"><?php echo $review['username']; ?></div>
                                            <div class="review-time"><?php echo date('Y-m-d H:i:s', strtotime($review['created_at'])); ?></div>
                                        </div>
                                        <div class="app-rating">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <i class="fas fa-star<?php echo $i <= $review['rating'] ? '' : '-empty'; ?>"></i>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                    <div class="review-content">
                                        <?php echo $review['content']; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 页脚 -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>关于我们</h3>
                    <ul>
                        <li><a href="#">公司简介</a></li>
                        <li><a href="#">联系我们</a></li>
                        <li><a href="#">加入我们</a></li>
                        <li><a href="#">隐私政策</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>帮助中心</h3>
                    <ul>
                        <li><a href="#">常见问题</a></li>
                        <li><a href="#">下载指南</a></li>
                        <li><a href="#">应用提交</a></li>
                        <li><a href="#">开发者中心</a></li>
                        <li><a href="../feedback/index.php"><i class="fas fa-comment-dots"></i> 意见反馈</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>关注我们</h3>
                    <ul>
                        <li><a href="#"><i class="fab fa-weibo"></i> 微博</a></li>
                        <li><a href="#"><i class="fab fa-wechat"></i> 微信</a></li>
                        <li><a href="#"><i class="fab fa-qq"></i> QQ</a></li>
                        <li><a href="#"><i class="fab fa-github"></i> GitHub</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>下载客户端</h3>
                    <p>扫描二维码下载客户端</p>
                    <?php
                        $clientDownloadUrl = getSetting('client_download_url', '');
                        if (!empty($clientDownloadUrl)) {
                            // 使用Google Charts API生成二维码
                            $encodedUrl = urlencode($clientDownloadUrl);
                            $qrcodeUrl = "https://api.qrserver.com/v1/create-qr-code/?size=120x120&data={$encodedUrl}";
                            echo '<img src="' . $qrcodeUrl . '" alt="客户端下载二维码" style="width: 120px; height: 120px; margin-top: 10px;">';
                        } else {
                            echo '<div style="width: 120px; height: 120px; background: white; margin-top: 10px; display: flex; align-items: center; justify-content: center; color: #999; font-size: 12px;">请在后台设置下载URL</div>';
                        }
                    ?>
                </div>
            </div>
            <div class="footer-bottom">
                <p><?php echo getSetting('copyright', '&copy; 2026 ' . SITE_NAME . ' 版权所有'); ?></p>
            </div>
        </div>
    </footer>

    <script>
        // 标签页切换
        function switchTab(tabId) {
            // 移除所有标签的活跃状态
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            // 移除所有内容的活跃状态
            document.querySelectorAll('.tab-pane').forEach(pane => {
                pane.classList.remove('active');
            });
            // 添加当前标签的活跃状态
            event.currentTarget.classList.add('active');
            // 添加当前内容的活跃状态
            document.getElementById(tabId).classList.add('active');
        }

        // JS下载应用
        function downloadApp(appId) {
            // 显示下载中提示
            const btn = event.currentTarget;
            const originalText = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 准备下载...';
            btn.disabled = true;

            // 调用API获取下载链接
            fetch('../api/get_download_url.php?id=' + appId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // 创建下载链接
                        const downloadUrl = '../' + data.download_url;
                        const link = document.createElement('a');
                        link.href = downloadUrl;
                        link.download = data.file_name;
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);

                        // 恢复按钮状态
                        btn.innerHTML = '<i class="fas fa-check"></i> 下载中...';
                        setTimeout(() => {
                            btn.innerHTML = originalText;
                            btn.disabled = false;
                        }, 2000);
                    } else {
                        alert(data.message || '下载失败');
                        btn.innerHTML = originalText;
                        btn.disabled = false;
                    }
                })
                .catch(error => {
                    console.error('下载错误:', error);
                    alert('下载失败，请稍后重试');
                    btn.innerHTML = originalText;
                    btn.disabled = false;
                });
        }

        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const fadeElements = document.querySelectorAll('.fade-in');
            fadeElements.forEach((element, index) => {
                element.style.animationDelay = `${index * 0.1}s`;
            });
        });

        // 移动端菜单切换
        function toggleMobileMenu() {
            const dropdown = document.querySelector('.mobile-menu-dropdown');
            dropdown.classList.toggle('show');
        }

        // 点击页面其他地方关闭菜单
        document.addEventListener('click', function(event) {
            const menuBtn = document.querySelector('.mobile-menu-btn');
            const dropdown = document.querySelector('.mobile-menu-dropdown');
            if (!menuBtn.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });
    </script>
</body>
</html>