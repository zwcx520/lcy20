<?php
session_start();
require_once '../include/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: login.php');
    exit;
}

$db = getDB();

// 处理回复反馈
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_feedback'])) {
    $feedback_id = $_POST['feedback_id'];
    $reply = trim($_POST['reply']);
    
    if (!empty($reply)) {
        $stmt = $db->prepare("UPDATE feedback SET reply = ?, status = 1 WHERE id = ?");
        $stmt->execute([$reply, $feedback_id]);
    }
    header('Location: feedback.php');
    exit;
}

// 处理删除反馈
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM feedback WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    header('Location: feedback.php');
    exit;
}

// 处理标记为已处理
if (isset($_GET['resolve']) && is_numeric($_GET['resolve'])) {
    $stmt = $db->prepare("UPDATE feedback SET status = 1 WHERE id = ?");
    $stmt->execute([$_GET['resolve']]);
    header('Location: feedback.php');
    exit;
}

// 获取筛选条件
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$type_filter = isset($_GET['type']) ? $_GET['type'] : 'all';

// 构建查询
$query = "SELECT f.*, u.avatar as user_avatar FROM feedback f LEFT JOIN users u ON f.user_id = u.id WHERE 1=1";
$params = [];

if ($status_filter !== 'all') {
    $query .= " AND f.status = ?";
    $params[] = $status_filter;
}

if ($type_filter !== 'all') {
    $query .= " AND f.type = ?";
    $params[] = $type_filter;
}

$query .= " ORDER BY f.created_at DESC";

$stmt = $db->prepare($query);
$stmt->execute($params);
$feedbacks = $stmt->fetchAll();

// 获取统计数据
$stmt = $db->prepare("SELECT COUNT(*) FROM feedback");
$stmt->execute();
$total_count = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM feedback WHERE status = 0");
$stmt->execute();
$pending_count = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM feedback WHERE status = 1");
$stmt->execute();
$resolved_count = $stmt->fetchColumn();

// 获取反馈类型名称
function getFeedbackTypeName($type) {
    $types = [
        'bug' => '功能异常',
        'feature' => '功能建议',
        'content' => '内容举报',
        'other' => '其他反馈'
    ];
    return $types[$type] ?? '其他';
}

// 获取反馈类型图标
function getFeedbackTypeIcon($type) {
    $icons = [
        'bug' => 'fa-bug',
        'feature' => 'fa-lightbulb',
        'content' => 'fa-exclamation-triangle',
        'other' => 'fa-ellipsis-h'
    ];
    return $icons[$type] ?? 'fa-comment';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>反馈管理 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* 侧边栏 */
        .sidebar {
            width: 250px;
            background: white;
            box-shadow: var(--box-shadow);
            padding: 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
        }

        .sidebar .logo {
            font-size: 20px;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sidebar .nav-menu {
            list-style: none;
        }

        .sidebar .nav-menu li {
            margin-bottom: 10px;
        }

        .sidebar .nav-menu a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 15px;
            text-decoration: none;
            color: var(--text-color);
            border-radius: var(--border-radius);
            transition: all 0.3s ease;
        }

        .sidebar .nav-menu a:hover {
            background: var(--light-color);
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .sidebar .nav-menu a.active {
            background: var(--primary-color);
            color: white;
        }

        .sidebar .nav-menu a i {
            width: 20px;
            text-align: center;
        }

        /* 移动端菜单按钮 */
        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 45px;
            height: 45px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: var(--box-shadow);
        }

        /* 遮罩层 */
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        /* 主内容区 */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        /* 顶部导航 */
        .top-nav {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 15px 20px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-nav h1 {
            font-size: 24px;
            color: var(--dark-color);
        }

        /* 统计卡片 */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: white;
        }

        .stat-icon.total { background: var(--primary-color); }
        .stat-icon.pending { background: #ffc107; }
        .stat-icon.resolved { background: #28a745; }

        .stat-info h3 {
            font-size: 24px;
            color: var(--dark-color);
        }

        .stat-info p {
            color: var(--text-color);
            font-size: 14px;
        }

        /* 筛选栏 */
        .filter-bar {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 20px;
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }

        .filter-bar select {
            padding: 8px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
        }

        .filter-bar button {
            padding: 8px 20px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .filter-bar button:hover {
            background: #ff528b;
        }

        /* 反馈列表 */
        .feedback-list {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
        }

        .feedback-item {
            padding: 20px;
            border-bottom: 1px solid #eee;
            transition: all 0.3s ease;
        }

        .feedback-item:hover {
            background: var(--light-color);
        }

        .feedback-item:last-child {
            border-bottom: none;
        }

        .feedback-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .feedback-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .feedback-type {
            display: flex;
            align-items: center;
            gap: 5px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }

        .feedback-type.bug { background: #ffebee; color: #c62828; }
        .feedback-type.feature { background: #e3f2fd; color: #1565c0; }
        .feedback-type.content { background: #fff3e0; color: #e65100; }
        .feedback-type.other { background: #f3e5f5; color: #6a1b9a; }

        .feedback-user {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text-color);
            font-size: 14px;
        }

        .feedback-user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            overflow: hidden;
            background: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 14px;
            font-weight: bold;
            flex-shrink: 0;
        }

        .feedback-user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .feedback-time {
            color: #999;
            font-size: 12px;
        }

        .feedback-status {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }

        .feedback-status.pending {
            background: #fff3cd;
            color: #856404;
        }

        .feedback-status.resolved {
            background: #d4edda;
            color: #155724;
        }

        .feedback-content {
            margin-bottom: 15px;
        }

        .feedback-content h4 {
            font-size: 16px;
            color: var(--dark-color);
            margin-bottom: 8px;
        }

        .feedback-content p {
            color: var(--text-color);
            line-height: 1.6;
        }

        .feedback-reply {
            background: #e3f2fd;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
        }

        .feedback-reply h5 {
            font-size: 14px;
            color: var(--dark-color);
            margin-bottom: 8px;
        }

        .feedback-reply p {
            color: var(--text-color);
            font-size: 14px;
        }

        .feedback-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }

        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: #ff528b;
        }

        .btn-success {
            background: #28a745;
            color: white;
        }

        .btn-success:hover {
            background: #218838;
        }

        .btn-danger {
            background: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background: #c82333;
        }

        /* 回复表单 */
        .reply-form {
            display: none;
            margin-top: 15px;
            padding: 20px;
            background: var(--light-color);
            border-radius: 8px;
        }

        .reply-form.show {
            display: block;
        }

        .reply-form textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            resize: vertical;
            min-height: 100px;
            margin-bottom: 10px;
        }

        /* 空状态 */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }

        .empty-state i {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 20px;
        }

        .empty-state h3 {
            color: var(--dark-color);
            margin-bottom: 10px;
        }

        .empty-state p {
            color: var(--text-color);
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding: 15px;
                padding-top: 70px;
            }

            .mobile-menu-btn {
                display: block;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .filter-bar {
                flex-direction: column;
                align-items: stretch;
            }

            .filter-bar form {
                flex-direction: column;
            }

            .filter-bar select,
            .filter-bar button {
                width: 100%;
            }

            .feedback-header {
                flex-direction: column;
                gap: 10px;
            }

            .feedback-info {
                flex-wrap: wrap;
            }

            .feedback-actions {
                flex-wrap: wrap;
            }

            .btn {
                flex: 1;
                min-width: 120px;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- 侧边栏 -->
        <div class="sidebar">
            <div class="logo">
                <i class="fas fa-cog"></i>
                <span><?php echo SITE_NAME; ?></span>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php"><i class="fas fa-home"></i> 仪表盘</a></li>
                <li><a href="apps.php"><i class="fas fa-apps"></i> 应用管理</a></li>
                <li><a href="categories.php"><i class="fas fa-th-large"></i> 分类管理</a></li>
                <li><a href="users.php"><i class="fas fa-users"></i> 用户管理</a></li>
                <li><a href="reviews.php"><i class="fas fa-comment"></i> 评论管理</a></li>
                <li><a href="feedback.php" class="active"><i class="fas fa-comment-dots"></i> 反馈管理</a></li>
                <li><a href="carousel.php"><i class="fas fa-images"></i> 轮播图管理</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> 系统设置</a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> 退出登录</a></li>
            </ul>
        </div>

        <!-- 主内容区 -->
        <div class="main-content">
            <!-- 顶部导航 -->
            <div class="top-nav">
                <h1><i class="fas fa-comment-dots"></i> 反馈管理</h1>
                <div class="user-info">
                    <span>欢迎，<?php echo $_SESSION['username']; ?></span>
                </div>
            </div>

            <!-- 统计卡片 -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon total">
                        <i class="fas fa-inbox"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $total_count; ?></h3>
                        <p>总反馈数</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon pending">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $pending_count; ?></h3>
                        <p>待处理</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon resolved">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $resolved_count; ?></h3>
                        <p>已处理</p>
                    </div>
                </div>
            </div>

            <!-- 筛选栏 -->
            <div class="filter-bar">
                <form method="get" action="" style="display: flex; gap: 15px; align-items: center;">
                    <select name="status">
                        <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>全部状态</option>
                        <option value="0" <?php echo $status_filter === '0' ? 'selected' : ''; ?>>待处理</option>
                        <option value="1" <?php echo $status_filter === '1' ? 'selected' : ''; ?>>已处理</option>
                    </select>
                    <select name="type">
                        <option value="all" <?php echo $type_filter === 'all' ? 'selected' : ''; ?>>全部类型</option>
                        <option value="bug" <?php echo $type_filter === 'bug' ? 'selected' : ''; ?>>功能异常</option>
                        <option value="feature" <?php echo $type_filter === 'feature' ? 'selected' : ''; ?>>功能建议</option>
                        <option value="content" <?php echo $type_filter === 'content' ? 'selected' : ''; ?>>内容举报</option>
                        <option value="other" <?php echo $type_filter === 'other' ? 'selected' : ''; ?>>其他反馈</option>
                    </select>
                    <button type="submit"><i class="fas fa-filter"></i> 筛选</button>
                </form>
            </div>

            <!-- 反馈列表 -->
            <div class="feedback-list">
                <?php if (empty($feedbacks)): ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>暂无反馈</h3>
                        <p>目前还没有收到任何用户反馈</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($feedbacks as $feedback): ?>
                        <div class="feedback-item">
                            <div class="feedback-header">
                                <div class="feedback-info">
                                    <span class="feedback-type <?php echo $feedback['type']; ?>">
                                        <i class="fas <?php echo getFeedbackTypeIcon($feedback['type']); ?>"></i>
                                        <?php echo getFeedbackTypeName($feedback['type']); ?>
                                    </span>
                                    <span class="feedback-user">
                                        <span class="feedback-user-avatar">
                                            <?php if (!empty($feedback['user_avatar'])): ?>
                                                <img src="../<?php echo $feedback['user_avatar']; ?>" alt="<?php echo $feedback['username']; ?>">
                                            <?php else: ?>
                                                <?php echo substr($feedback['username'], 0, 1); ?>
                                            <?php endif; ?>
                                        </span>
                                        <?php echo htmlspecialchars($feedback['username']); ?>
                                    </span>
                                    <span class="feedback-time">
                                        <i class="fas fa-clock"></i>
                                        <?php echo date('Y-m-d H:i', strtotime($feedback['created_at'])); ?>
                                    </span>
                                </div>
                                <span class="feedback-status <?php echo $feedback['status'] == 0 ? 'pending' : 'resolved'; ?>">
                                    <?php echo $feedback['status'] == 0 ? '待处理' : '已处理'; ?>
                                </span>
                            </div>
                            
                            <div class="feedback-content">
                                <h4><?php echo htmlspecialchars($feedback['title']); ?></h4>
                                <p><?php echo nl2br(htmlspecialchars($feedback['content'])); ?></p>
                            </div>

                            <?php if (!empty($feedback['reply'])): ?>
                                <div class="feedback-reply">
                                    <h5><i class="fas fa-reply"></i> 管理员回复</h5>
                                    <p><?php echo nl2br(htmlspecialchars($feedback['reply'])); ?></p>
                                </div>
                            <?php endif; ?>

                            <div class="feedback-actions">
                                <?php if ($feedback['status'] == 0): ?>
                                    <button class="btn btn-primary" onclick="toggleReplyForm(<?php echo $feedback['id']; ?>)">
                                        <i class="fas fa-reply"></i> 回复
                                    </button>
                                    <a href="?resolve=<?php echo $feedback['id']; ?>" class="btn btn-success" onclick="return confirm('确定标记为已处理吗？')">
                                        <i class="fas fa-check"></i> 标记已处理
                                    </a>
                                <?php endif; ?>
                                <a href="?delete=<?php echo $feedback['id']; ?>" class="btn btn-danger" onclick="return confirm('确定删除这条反馈吗？')">
                                    <i class="fas fa-trash"></i> 删除
                                </a>
                            </div>

                            <!-- 回复表单 -->
                            <div class="reply-form" id="reply-form-<?php echo $feedback['id']; ?>">
                                <form method="post" action="">
                                    <input type="hidden" name="feedback_id" value="<?php echo $feedback['id']; ?>">
                                    <textarea name="reply" placeholder="请输入回复内容..." required></textarea>
                                    <button type="submit" name="reply_feedback" class="btn btn-primary">
                                        <i class="fas fa-paper-plane"></i> 提交回复
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 遮罩层 -->
    <div class="overlay" onclick="toggleSidebar()"></div>

    <!-- 移动端菜单按钮 -->
    <button class="mobile-menu-btn" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <script>
        function toggleReplyForm(feedbackId) {
            const form = document.getElementById('reply-form-' + feedbackId);
            form.classList.toggle('show');
        }

        // 移动端侧边栏切换
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            const overlay = document.querySelector('.overlay');
            sidebar.classList.toggle('show');
            overlay.style.display = sidebar.classList.contains('show') ? 'block' : 'none';
        }
    </script>
</body>
</html>