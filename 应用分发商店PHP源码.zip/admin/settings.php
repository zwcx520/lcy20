<?php
session_start();
require_once '../include/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: login.php');
    exit;
}

// 获取系统统计数据
$db = getDB();

// 应用总数
$stmt = $db->prepare("SELECT COUNT(*) FROM apps");
$stmt->execute();
$appCount = $stmt->fetchColumn();

// 用户总数
$stmt = $db->prepare("SELECT COUNT(*) FROM users");
$stmt->execute();
$userCount = $stmt->fetchColumn();

// 评论总数
$stmt = $db->prepare("SELECT COUNT(*) FROM reviews");
$stmt->execute();
$reviewCount = $stmt->fetchColumn();

// 总下载次数
$stmt = $db->prepare("SELECT SUM(download_count) FROM apps");
$stmt->execute();
$totalDownloads = $stmt->fetchColumn() || 0;

// 处理设置更新
if (isset($_POST['update_settings'])) {
    // 更新站点设置
    updateSetting('site_name', $_POST['site_name']);
    updateSetting('site_url', $_POST['site_url']);
    updateSetting('admin_email', $_POST['admin_email']);
    updateSetting('copyright', $_POST['copyright']);
    updateSetting('client_download_url', $_POST['client_download_url']);
    
    $message = "设置已更新";
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系统设置 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* 侧边栏 */
        .sidebar {
            width: 250px;
            background: white;
            box-shadow: var(--box-shadow);
            padding: 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
            transition: transform 0.3s ease;
        }

        /* 移动端菜单按钮 */
        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 45px;
            height: 45px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: var(--box-shadow);
        }

        /* 遮罩层 */
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        .sidebar .logo {
            font-size: 20px;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sidebar .logo i {
            font-size: 24px;
        }

        .sidebar .nav-menu {
            list-style: none;
        }

        .sidebar .nav-menu li {
            margin-bottom: 10px;
        }

        .sidebar .nav-menu a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 15px;
            text-decoration: none;
            color: var(--text-color);
            border-radius: var(--border-radius);
            transition: all 0.3s ease;
        }

        .sidebar .nav-menu a:hover {
            background: var(--light-color);
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .sidebar .nav-menu a.active {
            background: var(--primary-color);
            color: white;
        }

        .sidebar .nav-menu a i {
            width: 20px;
            text-align: center;
        }

        /* 主内容区 */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        /* 顶部导航 */
        .top-nav {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 15px 20px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-nav .title {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark-color);
        }

        /* 统计卡片 */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 20px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }

        .stat-card .icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 24px;
            color: white;
        }

        .stat-card .value {
            font-size: 28px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 5px;
        }

        .stat-card .label {
            font-size: 14px;
            color: var(--text-color);
        }

        /* 设置表单 */
        .settings-form {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 30px;
        }

        .settings-form h3 {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 20px;
        }

        .settings-form .form-group {
            margin-bottom: 15px;
        }

        .settings-form label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .settings-form input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 14px;
        }

        .settings-form .btn {
            padding: 10px 20px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            background: var(--primary-color);
            color: white;
        }

        .settings-form .btn:hover {
            background: #ff528b;
            transform: translateY(-2px);
        }

        /* 消息提示 */
        .message {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            text-align: center;
        }

        /* 响应式设计 - 移动端优化 */
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .overlay.active {
                display: block;
            }

            .main-content {
                margin-left: 0;
                padding: 70px 15px 20px;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }
        }

        /* 动画效果 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <!-- 移动端菜单按钮 -->
    <button class="mobile-menu-btn" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <!-- 遮罩层 -->
    <div class="overlay" onclick="toggleSidebar()"></div>

    <div class="container">
        <!-- 侧边栏 -->
        <div class="sidebar" id="sidebar">
            <div class="logo">
                <i class="fas fa-cog"></i>
                <span><?php echo SITE_NAME; ?> 管理</span>
            </div>
            <ul class="nav-menu">
                <li>
                    <a href="index.php">
                        <i class="fas fa-home"></i>
                        <span>仪表盘</span>
                    </a>
                </li>
                <li>
                    <a href="apps.php">
                        <i class="fas fa-apps"></i>
                        <span>应用管理</span>
                    </a>
                </li>
                <li>
                    <a href="categories.php">
                        <i class="fas fa-th-large"></i>
                        <span>分类管理</span>
                    </a>
                </li>
                <li>
                    <a href="users.php">
                        <i class="fas fa-users"></i>
                        <span>用户管理</span>
                    </a>
                </li>
                <li>
                    <a href="reviews.php">
                        <i class="fas fa-comment"></i>
                        <span>评论管理</span>
                    </a>
                </li>
                <li>
                    <a href="feedback.php">
                        <i class="fas fa-comment-dots"></i>
                        <span>反馈管理</span>
                    </a>
                </li>
                <li>
                    <a href="carousel.php">
                        <i class="fas fa-images"></i>
                        <span>轮播图管理</span>
                    </a>
                </li>
                <li>
                    <a href="settings.php" class="active">
                        <i class="fas fa-cog"></i>
                        <span>系统设置</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- 主内容区 -->
        <div class="main-content">
            <!-- 顶部导航 -->
            <div class="top-nav fade-in">
                <div class="title">
                    <i class="fas fa-cog"></i> 系统设置
                </div>
            </div>

            <!-- 统计卡片 -->
            <div class="stats-grid fade-in">
                <div class="stat-card">
                    <div class="icon">
                        <i class="fas fa-apps"></i>
                    </div>
                    <div class="value"><?php echo $appCount; ?></div>
                    <div class="label">应用总数</div>
                </div>
                <div class="stat-card">
                    <div class="icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="value"><?php echo $userCount; ?></div>
                    <div class="label">用户总数</div>
                </div>
                <div class="stat-card">
                    <div class="icon">
                        <i class="fas fa-comment"></i>
                    </div>
                    <div class="value"><?php echo $reviewCount; ?></div>
                    <div class="label">评论总数</div>
                </div>
                <div class="stat-card">
                    <div class="icon">
                        <i class="fas fa-download"></i>
                    </div>
                    <div class="value"><?php echo number_format($totalDownloads); ?></div>
                    <div class="label">总下载量</div>
                </div>
            </div>

            <!-- 设置表单 -->
            <div class="settings-form fade-in">
                <h3><i class="fas fa-cog"></i> 系统配置</h3>
                <?php if (isset($message)): ?>
                    <div class="message"><?php echo $message; ?></div>
                <?php endif; ?>
                <form action="settings.php" method="post">
                    <div class="form-group">
                        <label for="site_name">站点名称:</label>
                        <input type="text" id="site_name" name="site_name" value="<?php echo getSetting('site_name', SITE_NAME); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="site_url">站点URL:</label>
                        <input type="text" id="site_url" name="site_url" value="<?php echo getSetting('site_url', SITE_URL); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="admin_email">管理员邮箱:</label>
                        <input type="email" id="admin_email" name="admin_email" value="<?php echo getSetting('admin_email', ADMIN_EMAIL); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="copyright">版权信息:</label>
                        <input type="text" id="copyright" name="copyright" value="<?php echo getSetting('copyright', '&copy; 2026 ' . getSetting('site_name', SITE_NAME) . ' 版权所有'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="client_download_url">客户端下载URL:</label>
                        <input type="url" id="client_download_url" name="client_download_url" value="<?php echo getSetting('client_download_url', ''); ?>" placeholder="输入客户端下载链接，用于生成二维码">
                    </div>
                    <button type="submit" name="update_settings" class="btn">
                        <i class="fas fa-save"></i> 保存设置
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // 移动端侧边栏切换
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.querySelector('.overlay');
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }

        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const fadeElements = document.querySelectorAll('.fade-in');
            fadeElements.forEach((element, index) => {
                element.style.animationDelay = `${index * 0.1}s`;
            });
        });
    </script>
</body>
</html>