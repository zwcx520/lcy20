<?php
session_start();
require_once '../include/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: login.php');
    exit;
}

// 获取所有用户
$db = getDB();
$stmt = $db->prepare("SELECT * FROM users ORDER BY created_at DESC");
$stmt->execute();
$users = $stmt->fetchAll();

// 处理删除用户
if (isset($_GET['delete'])) {
    $user_id = $_GET['delete'];
    
    // 获取用户信息（包括头像路径）
    $stmt = $db->prepare("SELECT avatar FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    // 删除用户头像文件
    if ($user && !empty($user['avatar'])) {
        $avatar_path = '../' . $user['avatar'];
        if (file_exists($avatar_path)) {
            unlink($avatar_path);
        }
    }
    
    // 删除用户记录
    $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    header('Location: users.php');
    exit;
}

// 处理更新用户权限
if (isset($_POST['update_admin'])) {
    $user_id = $_POST['user_id'];
    $is_admin = $_POST['is_admin'];
    $stmt = $db->prepare("UPDATE users SET is_admin = ? WHERE id = ?");
    $stmt->execute([$is_admin, $user_id]);
    header('Location: users.php');
    exit;
}

// 处理更新用户发布权限
if (isset($_POST['update_publish'])) {
    $user_id = $_POST['user_id'];
    $can_publish = $_POST['can_publish'];
    $stmt = $db->prepare("UPDATE users SET can_publish = ? WHERE id = ?");
    $stmt->execute([$can_publish, $user_id]);
    header('Location: users.php');
    exit;
}

// 处理添加用户
$add_error = '';
$add_success = '';
if (isset($_POST['add_user'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $is_admin = isset($_POST['is_admin']) ? 1 : 0;
    $avatar = '';
    
    // 处理头像上传
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/avatars/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($file_extension, $allowed_extensions)) {
            $file_name = uniqid() . '.' . $file_extension;
            $target_path = $upload_dir . $file_name;
            
            if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target_path)) {
                $avatar = 'uploads/avatars/' . $file_name;
            }
        }
    }
    
    // 验证输入
    if (empty($username) || empty($email) || empty($password)) {
        $add_error = '请填写所有必填字段';
    } elseif (strlen($password) < 6) {
        $add_error = '密码长度至少为6位';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $add_error = '邮箱格式不正确';
    } else {
        // 检查用户名和邮箱是否已存在
        $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetchColumn() > 0) {
            $add_error = '用户名或邮箱已存在';
        } else {
            // 添加用户
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO users (username, email, password, avatar, is_admin) VALUES (?, ?, ?, ?, ?)");
            if ($stmt->execute([$username, $email, $hashed_password, $avatar, $is_admin])) {
                $add_success = '用户添加成功';
                // 刷新用户列表
                $stmt = $db->prepare("SELECT * FROM users ORDER BY created_at DESC");
                $stmt->execute();
                $users = $stmt->fetchAll();
            } else {
                $add_error = '添加用户失败';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户管理 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* 侧边栏 */
        .sidebar {
            width: 250px;
            background: white;
            box-shadow: var(--box-shadow);
            padding: 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
            transition: transform 0.3s ease;
        }

        /* 移动端菜单按钮 */
        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 45px;
            height: 45px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: var(--box-shadow);
        }

        /* 遮罩层 */
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        .sidebar .logo {
            font-size: 20px;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sidebar .logo i {
            font-size: 24px;
        }

        .sidebar .nav-menu {
            list-style: none;
        }

        .sidebar .nav-menu li {
            margin-bottom: 10px;
        }

        .sidebar .nav-menu a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 15px;
            text-decoration: none;
            color: var(--text-color);
            border-radius: var(--border-radius);
            transition: all 0.3s ease;
        }

        .sidebar .nav-menu a:hover {
            background: var(--light-color);
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .sidebar .nav-menu a.active {
            background: var(--primary-color);
            color: white;
        }

        .sidebar .nav-menu a i {
            width: 20px;
            text-align: center;
        }

        /* 主内容区 */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        /* 顶部导航 */
        .top-nav {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 15px 20px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-nav .title {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark-color);
        }

        .top-nav .btn {
            padding: 8px 16px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .top-nav .btn:hover {
            background: #ff528b;
            transform: translateY(-2px);
        }

        /* 用户列表 */
        .user-list {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow-x: auto;
        }

        .user-list table {
            width: 100%;
            border-collapse: collapse;
            min-width: 700px;
        }

        .user-list th,
        .user-list td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .user-list th {
            background: var(--light-color);
            font-weight: 500;
            color: var(--dark-color);
        }

        .user-list tr:hover {
            background: var(--light-color);
        }

        .user-list .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            overflow: hidden;
            background: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }

        .user-list .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-list .actions {
            display: flex;
            gap: 10px;
        }

        .user-list .action-btn {
            padding: 6px 12px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .user-list .action-btn.edit {
            background: var(--secondary-color);
            color: white;
        }

        .user-list .action-btn.edit:hover {
            background: #3db8b0;
        }

        .user-list .action-btn.delete {
            background: #e74c3c;
            color: white;
        }

        .user-list .action-btn.delete:hover {
            background: #c0392b;
        }

        .user-list .admin-toggle {
            display: flex;
            align-items: center;
        }

        .user-list .admin-toggle input {
            margin-right: 5px;
        }

        /* 无用户提示 */
        .no-users {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-color);
        }

        .no-users i {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 20px;
        }

        .no-users h3 {
            font-size: 20px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 10px;
        }

        /* 响应式设计 - 移动端优化 */
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .overlay.active {
                display: block;
            }

            .main-content {
                margin-left: 0;
                padding: 70px 15px 20px;
            }

            .user-list {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }

            .user-list table {
                font-size: 12px;
                min-width: 650px;
            }

            .user-list th,
            .user-list td {
                padding: 8px 6px;
            }

            .user-list .user-avatar {
                width: 32px;
                height: 32px;
                font-size: 14px;
            }

            .user-list .actions {
                flex-direction: row;
                gap: 4px;
            }

            .user-list .action-btn {
                padding: 4px 8px;
                font-size: 11px;
            }

            .user-list .admin-toggle {
                font-size: 12px;
            }

            .user-list .admin-toggle input[type="checkbox"] {
                width: 16px;
                height: 16px;
            }
        }

        @media (max-width: 480px) {
            .user-list table {
                min-width: 580px;
            }

            .user-list th,
            .user-list td {
                padding: 6px 4px;
            }
        }

        /* 弹窗样式 */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            width: 90%;
            max-width: 450px;
            max-height: 90vh;
            overflow-y: auto;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            padding: 20px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h3 {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark-color);
        }

        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            color: #999;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .modal-close:hover {
            color: var(--primary-color);
        }

        .modal-body {
            padding: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        /* 头像上传 */
        .avatar-upload {
            text-align: center;
            margin-bottom: 20px;
        }

        .avatar-preview {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--primary-color);
            margin-bottom: 10px;
            background: var(--light-color);
        }

        .avatar-upload input[type="file"] {
            display: none;
        }

        .avatar-upload label {
            display: inline-block;
            padding: 6px 12px;
            background: var(--primary-color);
            color: white;
            border-radius: 15px;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.3s ease;
        }

        .avatar-upload label:hover {
            background: #ff528b;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(255, 107, 157, 0.1);
        }

        .form-group .checkbox-label {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }

        .form-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .modal-footer {
            padding: 15px 20px;
            border-top: 1px solid #eee;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .modal-footer .btn {
            padding: 8px 20px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .modal-footer .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .modal-footer .btn-primary:hover {
            background: #ff528b;
        }

        .modal-footer .btn-secondary {
            background: var(--light-color);
            color: var(--dark-color);
        }

        .modal-footer .btn-secondary:hover {
            background: #e8e8e8;
        }

        .alert {
            padding: 10px 15px;
            border-radius: var(--border-radius);
            margin-bottom: 15px;
            font-size: 14px;
        }

        .alert-error {
            background: #ffebee;
            color: #c62828;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
        }

        /* 动画效果 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <!-- 移动端菜单按钮 -->
    <button class="mobile-menu-btn" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <!-- 遮罩层 -->
    <div class="overlay" onclick="toggleSidebar()"></div>

    <div class="container">
        <!-- 侧边栏 -->
        <div class="sidebar" id="sidebar">
            <div class="logo">
                <i class="fas fa-cog"></i>
                <span><?php echo SITE_NAME; ?> 管理</span>
            </div>
            <ul class="nav-menu">
                <li>
                    <a href="index.php">
                        <i class="fas fa-home"></i>
                        <span>仪表盘</span>
                    </a>
                </li>
                <li>
                    <a href="apps.php">
                        <i class="fas fa-apps"></i>
                        <span>应用管理</span>
                    </a>
                </li>
                <li>
                    <a href="categories.php">
                        <i class="fas fa-th-large"></i>
                        <span>分类管理</span>
                    </a>
                </li>
                <li>
                    <a href="users.php" class="active">
                        <i class="fas fa-users"></i>
                        <span>用户管理</span>
                    </a>
                </li>
                <li>
                    <a href="reviews.php">
                        <i class="fas fa-comment"></i>
                        <span>评论管理</span>
                    </a>
                </li>
                <li>
                    <a href="feedback.php">
                        <i class="fas fa-comment-dots"></i>
                        <span>反馈管理</span>
                    </a>
                </li>
                <li>
                    <a href="carousel.php">
                        <i class="fas fa-images"></i>
                        <span>轮播图管理</span>
                    </a>
                </li>
                <li>
                    <a href="settings.php">
                        <i class="fas fa-cog"></i>
                        <span>系统设置</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- 主内容区 -->
        <div class="main-content">
            <!-- 顶部导航 -->
            <div class="top-nav fade-in">
                <div class="title">
                    <i class="fas fa-users"></i> 用户管理
                </div>
                <button class="btn" onclick="openModal()">
                    <i class="fas fa-plus"></i> 添加用户
                </button>
            </div>

            <!-- 用户列表 -->
            <div class="user-list fade-in">
                <?php if (empty($users)): ?>
                    <div class="no-users">
                        <i class="fas fa-users"></i>
                        <h3>暂无用户</h3>
                        <p>等待用户注册</p>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>头像</th>
                                <th>用户名</th>
                                <th>邮箱</th>
                                <th>管理员</th>
                                <th>发布权限</th>
                                <th>注册时间</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td>
                                        <div class="user-avatar">
                                            <?php if ($user['avatar']): ?>
                                                <img src="../<?php echo $user['avatar']; ?>" alt="<?php echo $user['username']; ?>">
                                            <?php else: ?>
                                                <?php echo substr($user['username'], 0, 1); ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td><?php echo $user['username']; ?></td>
                                    <td><?php echo $user['email']; ?></td>
                                    <td>
                                        <form action="users.php" method="post" class="admin-toggle">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="checkbox" name="is_admin" value="1" <?php echo $user['is_admin'] ? 'checked' : ''; ?> onchange="this.form.submit()">
                                            <span><?php echo $user['is_admin'] ? '是' : '否'; ?></span>
                                        </form>
                                    </td>
                                    <td>
                                        <form action="users.php" method="post" class="admin-toggle">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="update_publish" value="1">
                                            <input type="checkbox" name="can_publish" value="1" <?php echo ($user['can_publish'] ?? 1) ? 'checked' : ''; ?> onchange="this.form.submit()">
                                            <span><?php echo ($user['can_publish'] ?? 1) ? '允许' : '禁止'; ?></span>
                                        </form>
                                    </td>
                                    <td><?php echo date('Y-m-d H:i:s', strtotime($user['created_at'])); ?></td>
                                    <td>
                                        <div class="actions">
                                            <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="action-btn edit-btn">
                                                <i class="fas fa-edit"></i> 编辑
                                            </a>
                                            <a href="users.php?delete=<?php echo $user['id']; ?>" class="action-btn delete-btn" onclick="return confirm('确定要删除这个用户吗？');">
                                                <i class="fas fa-trash"></i> 删除
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 添加用户弹窗 -->
    <div class="modal" id="addUserModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-plus"></i> 添加用户</h3>
                <button class="modal-close" onclick="closeModal()">&times;</button>
            </div>
            <form action="users.php" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?php if (!empty($add_error)): ?>
                        <div class="alert alert-error">
                            <i class="fas fa-exclamation-circle"></i> <?php echo $add_error; ?>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($add_success)): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> <?php echo $add_success; ?>
                        </div>
                    <?php endif; ?>

                    <!-- 头像上传 -->
                    <div class="avatar-upload">
                        <img src="../assets/images/default-avatar.svg" alt="头像预览" class="avatar-preview" id="avatarPreview">
                        <br>
                        <label for="avatar">
                            <i class="fas fa-camera"></i> 选择头像
                        </label>
                        <input type="file" id="avatar" name="avatar" accept="image/*" onchange="previewAvatar(this)">
                    </div>

                    <div class="form-group">
                        <label for="username">用户名 <span style="color: #e74c3c;">*</span></label>
                        <input type="text" id="username" name="username" required placeholder="请输入用户名">
                    </div>
                    <div class="form-group">
                        <label for="email">邮箱 <span style="color: #e74c3c;">*</span></label>
                        <input type="email" id="email" name="email" required placeholder="请输入邮箱">
                    </div>
                    <div class="form-group">
                        <label for="password">密码 <span style="color: #e74c3c;">*</span></label>
                        <input type="password" id="password" name="password" required placeholder="请输入密码（至少6位）">
                    </div>
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="is_admin" value="1">
                            <span>设为管理员</span>
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">取消</button>
                    <button type="submit" name="add_user" class="btn btn-primary">
                        <i class="fas fa-save"></i> 保存
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // 移动端侧边栏切换
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.querySelector('.overlay');
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }

        // 打开弹窗
        function openModal() {
            document.getElementById('addUserModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        // 关闭弹窗
        function closeModal() {
            document.getElementById('addUserModal').classList.remove('active');
            document.body.style.overflow = '';
        }

        // 点击弹窗外部关闭
        document.getElementById('addUserModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });

        // ESC键关闭弹窗
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeModal();
            }
        });

        // 头像预览
        function previewAvatar(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('avatarPreview').src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const fadeElements = document.querySelectorAll('.fade-in');
            fadeElements.forEach((element, index) => {
                element.style.animationDelay = `${index * 0.1}s`;
            });

            // 如果有错误信息，自动打开弹窗
            <?php if (!empty($add_error)): ?>
                openModal();
            <?php endif; ?>
        });
    </script>
</body>
</html>