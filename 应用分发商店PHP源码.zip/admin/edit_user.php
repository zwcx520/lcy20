<?php
session_start();
require_once '../include/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: login.php');
    exit;
}

$db = getDB();

// 获取要编辑的用户ID
if (!isset($_GET['id'])) {
    header('Location: users.php');
    exit;
}

$user_id = $_GET['id'];

// 获取用户信息
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: users.php');
    exit;
}

$error = '';
$success = '';

if (isset($_POST['update_user'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $is_admin = isset($_POST['is_admin']) ? 1 : 0;
    $can_publish = isset($_POST['can_publish']) ? 1 : 0;
    $new_password = $_POST['new_password'];
    $avatar = $user['avatar']; // 默认保持原头像
    
    // 处理头像上传
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/avatars/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($file_extension, $allowed_extensions)) {
            $file_name = uniqid() . '.' . $file_extension;
            $target_path = $upload_dir . $file_name;
            
            if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target_path)) {
                // 删除旧头像
                if (!empty($user['avatar']) && file_exists('../' . $user['avatar'])) {
                    unlink('../' . $user['avatar']);
                }
                $avatar = 'uploads/avatars/' . $file_name;
            }
        }
    }
    
    // 验证输入
    if (empty($username) || empty($email)) {
        $error = '用户名和邮箱不能为空';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = '邮箱格式不正确';
    } else {
        // 检查用户名和邮箱是否被其他用户使用
        $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE (username = ? OR email = ?) AND id != ?");
        $stmt->execute([$username, $email, $user_id]);
        if ($stmt->fetchColumn() > 0) {
            $error = '用户名或邮箱已被其他用户使用';
        } else {
            // 如果需要修改密码
            if (!empty($new_password)) {
                    if (strlen($new_password) < 6) {
                        $error = '密码长度至少为6位';
                    } else {
                        // 更新用户名、邮箱、密码、头像、管理员状态和发布权限
                        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                        $stmt = $db->prepare("UPDATE users SET username = ?, email = ?, password = ?, avatar = ?, is_admin = ?, can_publish = ? WHERE id = ?");
                        if ($stmt->execute([$username, $email, $hashed_password, $avatar, $is_admin, $can_publish, $user_id])) {
                            $success = '用户信息修改成功';
                            // 刷新用户信息
                            $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
                            $stmt->execute([$user_id]);
                            $user = $stmt->fetch();
                        } else {
                            $error = '修改失败';
                        }
                    }
                } else {
                    // 只更新用户名、邮箱、头像、管理员状态和发布权限
                    $stmt = $db->prepare("UPDATE users SET username = ?, email = ?, avatar = ?, is_admin = ?, can_publish = ? WHERE id = ?");
                    if ($stmt->execute([$username, $email, $avatar, $is_admin, $can_publish, $user_id])) {
                        $success = '用户信息修改成功';
                        // 刷新用户信息
                        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
                        $stmt->execute([$user_id]);
                        $user = $stmt->fetch();
                    } else {
                        $error = '修改失败';
                    }
                }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>编辑用户 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* 侧边栏 */
        .sidebar {
            width: 250px;
            background: white;
            box-shadow: var(--box-shadow);
            padding: 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
            transition: transform 0.3s ease;
        }

        /* 移动端菜单按钮 */
        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 45px;
            height: 45px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: var(--box-shadow);
        }

        /* 遮罩层 */
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        .sidebar .logo {
            font-size: 20px;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sidebar .logo i {
            font-size: 24px;
        }

        .sidebar .nav-menu {
            list-style: none;
        }

        .sidebar .nav-menu li {
            margin-bottom: 10px;
        }

        .sidebar .nav-menu a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 15px;
            text-decoration: none;
            color: var(--text-color);
            border-radius: var(--border-radius);
            transition: all 0.3s ease;
        }

        .sidebar .nav-menu a:hover {
            background: var(--light-color);
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .sidebar .nav-menu a.active {
            background: var(--primary-color);
            color: white;
        }

        .sidebar .nav-menu a i {
            width: 20px;
            text-align: center;
        }

        /* 主内容区 */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        /* 顶部导航 */
        .top-nav {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 15px 20px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-nav .title {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark-color);
        }

        .top-nav .btn {
            padding: 8px 16px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            background: var(--light-color);
            color: var(--dark-color);
            display: flex;
            align-items: center;
            gap: 5px;
            text-decoration: none;
        }

        .top-nav .btn:hover {
            background: #e8e8e8;
            transform: translateY(-2px);
        }

        /* 编辑卡片 */
        .edit-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 30px;
        }

        .edit-card h2 {
            font-size: 20px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .edit-card h2 i {
            color: var(--primary-color);
        }

        /* 提示信息 */
        .alert {
            padding: 12px 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .alert-error {
            background: #ffebee;
            color: #c62828;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
        }

        /* 表单样式 */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .form-group label .required {
            color: #e74c3c;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(255, 107, 157, 0.1);
        }

        .form-group .input-hint {
            font-size: 12px;
            color: #999;
            margin-top: 5px;
        }

        .form-group .checkbox-label {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }

        .form-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        /* 分隔线 */
        .divider {
            border: none;
            border-top: 1px solid #eee;
            margin: 25px 0;
        }

        .section-title {
            font-size: 16px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .section-title i {
            color: var(--primary-color);
        }

        /* 按钮 */
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 25px;
        }

        .btn-submit {
            padding: 12px 30px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: #ff528b;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 107, 157, 0.3);
        }

        .btn-secondary {
            background: var(--light-color);
            color: var(--dark-color);
            border: 1px solid #ddd;
            text-decoration: none;
        }

        .btn-secondary:hover {
            background: #e8e8e8;
            transform: translateY(-2px);
        }

        /* 用户信息显示 */
        .user-info-display {
            background: var(--light-color);
            border-radius: var(--border-radius);
            padding: 15px 20px;
            margin-bottom: 25px;
        }

        .user-info-display p {
            margin-bottom: 5px;
            font-size: 14px;
        }

        .user-info-display p:last-child {
            margin-bottom: 0;
        }

        /* 头像上传 */
        .avatar-upload {
            text-align: center;
            margin-bottom: 25px;
        }

        .avatar-preview {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid var(--primary-color);
            margin-bottom: 15px;
            background: var(--light-color);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .avatar-upload input[type="file"] {
            display: none;
        }

        .avatar-upload label {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            border-radius: 25px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .avatar-upload label:hover {
            background: #ff528b;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 107, 157, 0.3);
        }

        /* 响应式设计 - 移动端优化 */
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .overlay.active {
                display: block;
            }

            .main-content {
                margin-left: 0;
                padding: 70px 15px 20px;
            }

            .edit-card {
                padding: 20px;
            }

            .form-actions {
                flex-direction: column;
            }

            .btn-submit {
                width: 100%;
                justify-content: center;
            }
        }

        /* 动画效果 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <!-- 移动端菜单按钮 -->
    <button class="mobile-menu-btn" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <!-- 遮罩层 -->
    <div class="overlay" onclick="toggleSidebar()"></div>

    <div class="container">
        <!-- 侧边栏 -->
        <div class="sidebar" id="sidebar">
            <div class="logo">
                <i class="fas fa-cog"></i>
                <span><?php echo SITE_NAME; ?> 管理</span>
            </div>
            <ul class="nav-menu">
                <li>
                    <a href="index.php">
                        <i class="fas fa-home"></i>
                        <span>仪表盘</span>
                    </a>
                </li>
                <li>
                    <a href="apps.php">
                        <i class="fas fa-apps"></i>
                        <span>应用管理</span>
                    </a>
                </li>
                <li>
                    <a href="categories.php">
                        <i class="fas fa-th-large"></i>
                        <span>分类管理</span>
                    </a>
                </li>
                <li>
                    <a href="users.php" class="active">
                        <i class="fas fa-users"></i>
                        <span>用户管理</span>
                    </a>
                </li>
                <li>
                    <a href="reviews.php">
                        <i class="fas fa-comment"></i>
                        <span>评论管理</span>
                    </a>
                </li>
                <li>
                    <a href="settings.php">
                        <i class="fas fa-cog"></i>
                        <span>系统设置</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- 主内容区 -->
        <div class="main-content">
            <!-- 顶部导航 -->
            <div class="top-nav fade-in">
                <div class="title">
                    <i class="fas fa-user-edit"></i> 编辑用户
                </div>
                <a href="users.php" class="btn">
                    <i class="fas fa-arrow-left"></i> 返回列表
                </a>
            </div>

            <!-- 编辑表单 -->
            <div class="edit-card fade-in">
                <h2><i class="fas fa-user"></i> 编辑用户信息</h2>

                <!-- 用户信息显示 -->
                <div class="user-info-display">
                    <p><strong>用户ID:</strong> <?php echo $user['id']; ?></p>
                    <p><strong>注册时间:</strong> <?php echo date('Y-m-d H:i:s', strtotime($user['created_at'])); ?></p>
                    <p><strong>当前状态:</strong> <?php echo $user['is_admin'] ? '<span style="color: var(--primary-color);">管理员</span>' : '普通用户'; ?></p>
                    <p><strong>发布权限:</strong> <?php echo ($user['can_publish'] ?? 1) ? '<span style="color: #2ecc71;">允许发布</span>' : '<span style="color: #e74c3c;">禁止发布</span>'; ?></p>
                </div>

                <?php if (!empty($error)): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($success)): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>

                <form action="edit_user.php?id=<?php echo $user_id; ?>" method="post" enctype="multipart/form-data">
                    <!-- 头像上传 -->
                    <div class="avatar-upload">
                        <img src="<?php echo !empty($user['avatar']) ? '../' . $user['avatar'] : '../assets/images/default-avatar.svg'; ?>" alt="头像预览" class="avatar-preview" id="avatarPreview">
                        <br>
                        <label for="avatar">
                            <i class="fas fa-camera"></i> 更换头像
                        </label>
                        <input type="file" id="avatar" name="avatar" accept="image/*" onchange="previewAvatar(this)">
                    </div>

                    <!-- 基本信息 -->
                    <div class="section-title">
                        <i class="fas fa-info-circle"></i> 基本信息
                    </div>

                    <div class="form-group">
                        <label for="username">
                            用户名 <span class="required">*</span>
                        </label>
                        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required placeholder="请输入用户名">
                    </div>

                    <div class="form-group">
                        <label for="email">
                            邮箱 <span class="required">*</span>
                        </label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required placeholder="请输入邮箱">
                    </div>

                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="is_admin" value="1" <?php echo $user['is_admin'] ? 'checked' : ''; ?>>
                            <span>设为管理员</span>
                        </label>
                    </div>

                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="can_publish" value="1" <?php echo ($user['can_publish'] ?? 1) ? 'checked' : ''; ?>>
                            <span>允许发布应用</span>
                        </label>
                        <p class="input-hint">取消勾选将禁止该用户发布应用</p>
                    </div>

                    <hr class="divider">

                    <!-- 修改密码 -->
                    <div class="section-title">
                        <i class="fas fa-lock"></i> 修改密码
                    </div>
                    <p class="input-hint" style="margin-bottom: 15px;">如需修改用户密码，请填写以下字段（留空则不修改）</p>

                    <div class="form-group">
                        <label for="new_password">新密码</label>
                        <input type="password" id="new_password" name="new_password" placeholder="请输入新密码（至少6位）">
                        <p class="input-hint">密码长度至少为6位</p>
                    </div>

                    <div class="form-actions">
                        <a href="users.php" class="btn-submit btn-secondary">
                            <i class="fas fa-times"></i> 取消
                        </a>
                        <button type="submit" name="update_user" class="btn-submit btn-primary">
                            <i class="fas fa-save"></i> 保存修改
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // 移动端侧边栏切换
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.querySelector('.overlay');
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }

        // 头像预览
        function previewAvatar(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('avatarPreview').src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const fadeElements = document.querySelectorAll('.fade-in');
            fadeElements.forEach((element, index) => {
                element.style.animationDelay = `${index * 0.1}s`;
            });
        });
    </script>
</body>
</html>
