<?php
session_start();
require_once '../include/functions.php';

header('Content-Type: application/json');

// 检查登录状态（普通用户和管理员都可以上传）
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => '未登录']);
    exit;
}

// 检查是否是AJAX上传请求
if (!isset($_POST['upload_only']) || $_POST['upload_only'] !== '1') {
    echo json_encode(['success' => false, 'message' => '无效的请求']);
    exit;
}

// 检查文件是否上传
if (!isset($_FILES['app_file']) || $_FILES['app_file']['error'] !== UPLOAD_ERR_OK) {
    $error_message = '文件上传失败';
    if (isset($_FILES['app_file'])) {
        switch ($_FILES['app_file']['error']) {
            case UPLOAD_ERR_INI_SIZE:
                $error_message = '文件大小超过服务器限制';
                break;
            case UPLOAD_ERR_FORM_SIZE:
                $error_message = '文件大小超过表单限制';
                break;
            case UPLOAD_ERR_PARTIAL:
                $error_message = '文件部分上传失败';
                break;
            case UPLOAD_ERR_NO_FILE:
                $error_message = '没有文件被上传';
                break;
        }
    }
    echo json_encode(['success' => false, 'message' => $error_message]);
    exit;
}

// 获取文件信息
$file = $_FILES['app_file'];
$file_name = basename($file['name']);
$file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

// 检查文件类型
$allowed_app_types = ['apk', 'ipa', 'exe', 'dmg', 'zip', 'rar', '7z'];
if (!in_array($file_extension, $allowed_app_types)) {
    echo json_encode(['success' => false, 'message' => '应用文件格式不支持，请上传 APK、IPA、EXE、DMG 或压缩包格式']);
    exit;
}

// 检查文件大小 (10GB = 10737418240 bytes)
$max_size = 10 * 1024 * 1024 * 1024;
if ($file['size'] > $max_size) {
    echo json_encode(['success' => false, 'message' => '应用文件大小超过 10GB 限制']);
    exit;
}

// 生成临时应用ID（使用时间戳）
$temp_app_id = time();

// 创建上传目录
$upload_dir = '../uploads/apps/' . $temp_app_id . '/';
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

$target_path = $upload_dir . $file_name;

// 如果文件已存在，添加唯一ID
if (file_exists($target_path)) {
    $file_info = pathinfo($file_name);
    $file_name = $file_info['filename'] . '_' . uniqid() . '.' . $file_info['extension'];
    $target_path = $upload_dir . $file_name;
}

// 移动上传的文件
if (move_uploaded_file($file['tmp_name'], $target_path)) {
    $file_path = 'uploads/apps/' . $temp_app_id . '/' . $file_name;
    echo json_encode([
        'success' => true,
        'message' => '文件上传成功',
        'file_path' => $file_path,
        'file_name' => $file_name,
        'file_size' => $file['size']
    ]);
} else {
    echo json_encode(['success' => false, 'message' => '文件移动失败，请检查目录权限']);
}
exit;
?>
