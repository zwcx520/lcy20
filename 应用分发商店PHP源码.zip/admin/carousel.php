<?php
session_start();
require_once '../include/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: login.php');
    exit;
}

// 处理轮播图操作
if (isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'add':
            // 处理添加轮播图
            $title = $_POST['title'] ?? '';
            $description = $_POST['description'] ?? '';
            $link = $_POST['link'] ?? '';
            $order_num = isset($_POST['order_num']) ? intval($_POST['order_num']) : 1;
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            $image_input_type = $_POST['image_input_type'] ?? 'file';
            $image_url = $_POST['image_url'] ?? '';
            
            // 验证必填字段
            if (empty($title) || empty($description)) {
                header("Location: carousel.php?error=" . urlencode("标题和描述不能为空"));
                exit;
            }
            
            // 处理图片
            $image = '';
            if ($image_input_type === 'url' && !empty($image_url)) {
                // 使用URL方式
                $image = $image_url;
            } elseif ($image_input_type === 'file' && isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                // 使用文件上传方式 - 不限制图片格式和尺寸
                $targetDir = '../include/assets/uploads/carousel';
                if (!file_exists($targetDir)) {
                    mkdir($targetDir, 0777, true);
                }
                
                $fileExtension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                $fileName = uniqid() . '.' . $fileExtension;
                $targetPath = $targetDir . '/' . $fileName;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
                    $image = 'include/assets/uploads/carousel/' . $fileName;
                } else {
                    header("Location: carousel.php?error=" . urlencode("图片上传失败，请检查目录权限"));
                    exit;
                }
            }
            
            if (!empty($image)) {
                $db = getDB();
                $stmt = $db->prepare("INSERT INTO carousel (title, description, image, link, order_num, is_active) VALUES (?, ?, ?, ?, ?, ?)");
                $result = $stmt->execute([$title, $description, $image, $link, $order_num, $is_active]);
                
                if ($result) {
                    header("Location: carousel.php?message=" . urlencode("轮播图添加成功"));
                } else {
                    header("Location: carousel.php?error=" . urlencode("轮播图添加失败"));
                }
                exit;
            } else {
                header("Location: carousel.php?error=" . urlencode("请上传轮播图图片或输入图片URL"));
                exit;
            }
            break;
            
        case 'edit':
            // 处理编辑轮播图
            $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
            $title = $_POST['title'] ?? '';
            $description = $_POST['description'] ?? '';
            $link = $_POST['link'] ?? '';
            $order_num = isset($_POST['order_num']) ? intval($_POST['order_num']) : 1;
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            $image_input_type = $_POST['image_input_type'] ?? 'keep';
            $image_url = $_POST['image_url'] ?? '';
            
            // 验证ID
            if ($id <= 0) {
                header("Location: carousel.php?error=" . urlencode("无效的轮播图ID"));
                exit;
            }
            
            // 验证必填字段
            if (empty($title) || empty($description)) {
                header("Location: carousel.php?edit=" . $id . "&error=" . urlencode("标题和描述不能为空"));
                exit;
            }
            
            // 获取当前轮播图信息
            $db = getDB();
            $stmt = $db->prepare("SELECT image FROM carousel WHERE id = ?");
            $stmt->execute([$id]);
            $current_carousel = $stmt->fetch();
            $current_image = $current_carousel['image'] ?? '';
            
            // 处理图片
            $image = $current_image;
            
            if ($image_input_type === 'url' && !empty($image_url)) {
                // 使用新URL，删除旧本地图片
                if (!empty($current_image) && !preg_match('/^https?:\/\//', $current_image) && file_exists('../' . $current_image)) {
                    unlink('../' . $current_image);
                }
                $image = $image_url;
            } elseif ($image_input_type === 'file' && isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                // 使用新上传文件，删除旧本地图片 - 不限制图片格式和尺寸
                if (!empty($current_image) && !preg_match('/^https?:\/\//', $current_image) && file_exists('../' . $current_image)) {
                    unlink('../' . $current_image);
                }
                
                $targetDir = '../include/assets/uploads/carousel';
                if (!file_exists($targetDir)) {
                    mkdir($targetDir, 0777, true);
                }
                
                $fileExtension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                $fileName = uniqid() . '.' . $fileExtension;
                $targetPath = $targetDir . '/' . $fileName;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
                    $image = 'include/assets/uploads/carousel/' . $fileName;
                } else {
                    header("Location: carousel.php?edit=" . $id . "&error=" . urlencode("图片上传失败，请检查目录权限"));
                    exit;
                }
            }
            // 如果 $image_input_type === 'keep'，保持原有图片不变
            
            // 验证图片不能为空
            if (empty($image)) {
                header("Location: carousel.php?edit=" . $id . "&error=" . urlencode("图片不能为空"));
                exit;
            }
            
            $stmt = $db->prepare("UPDATE carousel SET title = ?, description = ?, image = ?, link = ?, order_num = ?, is_active = ? WHERE id = ?");
            $result = $stmt->execute([$title, $description, $image, $link, $order_num, $is_active, $id]);
            
            if ($result) {
                header("Location: carousel.php?edit=" . $id . "&message=" . urlencode("轮播图更新成功"));
            } else {
                header("Location: carousel.php?edit=" . $id . "&error=" . urlencode("轮播图更新失败"));
            }
            exit;
            break;
            
        case 'delete':
            // 处理删除轮播图
            $id = $_POST['id'];
            
            // 获取轮播图信息，用于删除图片
            $db = getDB();
            $stmt = $db->prepare("SELECT image FROM carousel WHERE id = ?");
            $stmt->execute([$id]);
            $carousel = $stmt->fetch();
            
            // 删除图片（仅删除本地文件，不删除外部URL）
            if (!empty($carousel['image']) && !preg_match('/^https?:\/\//', $carousel['image']) && file_exists('../' . $carousel['image'])) {
                unlink('../' . $carousel['image']);
            }
            
            // 删除轮播图
            $stmt = $db->prepare("DELETE FROM carousel WHERE id = ?");
            $stmt->execute([$id]);
            
            header("Location: carousel.php?message=" . urlencode("轮播图删除成功"));
            exit;
            break;
    }
}

// 获取轮播图列表
$db = getDB();
$stmt = $db->prepare("SELECT * FROM carousel ORDER BY order_num ASC");
$stmt->execute();
$carousels = $stmt->fetchAll();

// 获取单个轮播图信息（用于编辑）
$edit_carousel = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $db->prepare("SELECT * FROM carousel WHERE id = ?");
    $stmt->execute([$id]);
    $edit_carousel = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>轮播图管理 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* 侧边栏 */
        .sidebar {
            width: 250px;
            background: white;
            box-shadow: var(--box-shadow);
            padding: 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
            transition: transform 0.3s ease;
        }

        /* 移动端菜单按钮 */
        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 45px;
            height: 45px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: var(--box-shadow);
        }

        /* 遮罩层 */
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        .sidebar .logo {
            font-size: 20px;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sidebar .logo i {
            font-size: 24px;
        }

        .sidebar .nav-menu {
            list-style: none;
        }

        .sidebar .nav-menu li {
            margin-bottom: 10px;
        }

        .sidebar .nav-menu a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 15px;
            text-decoration: none;
            color: var(--text-color);
            border-radius: var(--border-radius);
            transition: all 0.3s ease;
        }

        .sidebar .nav-menu a:hover {
            background: var(--light-color);
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .sidebar .nav-menu a.active {
            background: var(--primary-color);
            color: white;
        }

        .sidebar .nav-menu a i {
            width: 20px;
            text-align: center;
        }

        /* 主内容区 */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        /* 顶部导航 */
        .top-nav {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 15px 20px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-nav .title {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark-color);
        }

        /* 轮播图列表 */
        .carousel-list {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 30px;
            margin-bottom: 30px;
        }

        .carousel-list h3 {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .carousel-list table {
            width: 100%;
            border-collapse: collapse;
        }

        .carousel-list th,
        .carousel-list td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .carousel-list th {
            background: var(--light-color);
            font-weight: 500;
            color: var(--dark-color);
        }

        .carousel-list .image-cell {
            width: 120px;
        }

        .carousel-list .image-cell img {
            width: 100%;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
        }

        .carousel-list .action-cell {
            width: 150px;
        }

        .carousel-list .btn {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-right: 5px;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: #ff528b;
        }

        .btn-secondary {
            background: var(--secondary-color);
            color: white;
        }

        .btn-secondary:hover {
            background: #3dbfb8;
        }

        .btn-danger {
            background: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background: #c82333;
        }

        /* 轮播图表单 */
        .carousel-form {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 30px;
        }

        .carousel-form h3 {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .carousel-form .form-group {
            margin-bottom: 20px;
        }

        .carousel-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .carousel-form .label-hint {
            font-weight: normal;
            color: #999;
            font-size: 12px;
            margin-left: 5px;
        }

        .carousel-form input[type="text"],
        .carousel-form input[type="url"],
        .carousel-form input[type="number"],
        .carousel-form textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        .carousel-form input[type="text"]:focus,
        .carousel-form input[type="url"]:focus,
        .carousel-form input[type="number"]:focus,
        .carousel-form textarea:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .carousel-form textarea {
            resize: vertical;
            min-height: 100px;
        }

        /* 图片输入方式选择 */
        .image-input-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }

        .image-input-tab {
            padding: 10px 20px;
            border: 2px solid #ddd;
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: all 0.3s ease;
            background: white;
            font-size: 14px;
        }

        .image-input-tab:hover {
            border-color: var(--primary-color);
            color: var(--primary-color);
        }

        .image-input-tab.active {
            border-color: var(--primary-color);
            background: var(--primary-color);
            color: white;
        }

        .image-input-content {
            display: none;
        }

        .image-input-content.active {
            display: block;
        }

        .carousel-form input[type="file"] {
            padding: 10px;
            border: 2px dashed #ddd;
            border-radius: var(--border-radius);
            width: 100%;
            cursor: pointer;
            transition: border-color 0.3s ease;
        }

        .carousel-form input[type="file"]:hover {
            border-color: var(--primary-color);
        }

        /* 图片预览区域 */
        .image-preview-container {
            margin-top: 15px;
            padding: 15px;
            background: var(--light-color);
            border-radius: var(--border-radius);
            display: none;
        }

        .image-preview-container.show {
            display: block;
        }

        .image-preview-container .preview-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 10px;
        }

        .image-preview-container img {
            max-width: 100%;
            max-height: 200px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }

        /* 当前图片显示 */
        .current-image-container {
            margin-top: 15px;
            padding: 15px;
            background: var(--light-color);
            border-radius: var(--border-radius);
        }

        .current-image-container .current-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 10px;
        }

        .current-image-container img {
            max-width: 100%;
            max-height: 200px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }

        .carousel-form .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .carousel-form .checkbox-group input[type="checkbox"] {
            width: auto;
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        .carousel-form .btn {
            padding: 12px 24px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            background: var(--primary-color);
            color: white;
        }

        .carousel-form .btn:hover {
            background: #ff528b;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 107, 157, 0.3);
        }

        .carousel-form .btn-secondary {
            background: var(--light-color);
            color: var(--dark-color);
            border: 1px solid #ddd;
            margin-left: 10px;
        }

        .carousel-form .btn-secondary:hover {
            background: #e8e8e8;
        }

        /* 消息提示 */
        .message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .message i {
            font-size: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .error i {
            font-size: 20px;
        }

        /* 图片尺寸提示 */
        .image-hint {
            background: #e3f2fd;
            color: #1976d2;
            padding: 10px 15px;
            border-radius: var(--border-radius);
            margin-bottom: 15px;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .image-hint i {
            font-size: 16px;
        }

        /* 响应式设计 - 移动端优化 */
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .overlay.active {
                display: block;
            }

            .main-content {
                margin-left: 0;
                padding: 70px 15px 20px;
            }

            .carousel-list {
                padding: 20px;
            }

            .carousel-list table {
                font-size: 14px;
            }

            .carousel-list .image-cell {
                width: 80px;
            }

            .carousel-list .action-cell {
                width: 120px;
            }

            .carousel-list .btn {
                padding: 4px 8px;
                font-size: 10px;
            }

            .carousel-form {
                padding: 20px;
            }

            .image-input-tabs {
                flex-direction: column;
            }

            .image-input-tab {
                text-align: center;
            }
        }

        /* 动画效果 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <!-- 移动端菜单按钮 -->
    <button class="mobile-menu-btn" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <!-- 遮罩层 -->
    <div class="overlay" onclick="toggleSidebar()"></div>

    <div class="container">
        <!-- 侧边栏 -->
        <div class="sidebar" id="sidebar">
            <div class="logo">
                <i class="fas fa-cog"></i>
                <span><?php echo SITE_NAME; ?> 管理</span>
            </div>
            <ul class="nav-menu">
                <li>
                    <a href="index.php">
                        <i class="fas fa-home"></i>
                        <span>仪表盘</span>
                    </a>
                </li>
                <li>
                    <a href="apps.php">
                        <i class="fas fa-apps"></i>
                        <span>应用管理</span>
                    </a>
                </li>
                <li>
                    <a href="categories.php">
                        <i class="fas fa-th-large"></i>
                        <span>分类管理</span>
                    </a>
                </li>
                <li>
                    <a href="users.php">
                        <i class="fas fa-users"></i>
                        <span>用户管理</span>
                    </a>
                </li>
                <li>
                    <a href="reviews.php">
                        <i class="fas fa-comment"></i>
                        <span>评论管理</span>
                    </a>
                </li>
                <li>
                    <a href="feedback.php">
                        <i class="fas fa-comment-dots"></i>
                        <span>反馈管理</span>
                    </a>
                </li>
                <li>
                    <a href="carousel.php" class="active">
                        <i class="fas fa-images"></i>
                        <span>轮播图管理</span>
                    </a>
                </li>
                <li>
                    <a href="settings.php">
                        <i class="fas fa-cog"></i>
                        <span>系统设置</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- 主内容区 -->
        <div class="main-content">
            <!-- 顶部导航 -->
            <div class="top-nav fade-in">
                <div class="title">
                    <i class="fas fa-images"></i> 轮播图管理
                </div>
            </div>

            <!-- 轮播图列表 -->
            <div class="carousel-list fade-in">
                <h3><i class="fas fa-list"></i> 轮播图列表</h3>
                <?php if (isset($_GET['message'])): ?>
                    <div class="message">
                        <i class="fas fa-check-circle"></i>
                        <?php echo htmlspecialchars($_GET['message']); ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($_GET['error'])): ?>
                    <div class="error">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php echo htmlspecialchars($_GET['error']); ?>
                    </div>
                <?php endif; ?>
                <table>
                    <thead>
                        <tr>
                            <th>排序</th>
                            <th>标题</th>
                            <th>图片</th>
                            <th>状态</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($carousels as $carousel): ?>
                            <tr>
                                <td><?php echo $carousel['order_num']; ?></td>
                                <td><?php echo htmlspecialchars($carousel['title']); ?></td>
                                <td class="image-cell">
                                    <?php 
                                        $imageSrc = $carousel['image'];
                                        if (!preg_match('/^https?:\/\//', $imageSrc)) {
                                            $imageSrc = '../' . $imageSrc;
                                        }
                                    ?>
                                    <img src="<?php echo htmlspecialchars($imageSrc); ?>" alt="<?php echo htmlspecialchars($carousel['title']); ?>" onerror="this.src='../assets/images/default-app-icon.svg'">
                                </td>
                                <td>
                                    <?php if ($carousel['is_active']): ?>
                                        <span style="color: #28a745;"><i class="fas fa-check-circle"></i> 启用</span>
                                    <?php else: ?>
                                        <span style="color: #dc3545;"><i class="fas fa-times-circle"></i> 禁用</span>
                                    <?php endif; ?>
                                </td>
                                <td class="action-cell">
                                    <a href="carousel.php?edit=<?php echo $carousel['id']; ?>" class="btn btn-primary">编辑</a>
                                    <form action="carousel.php" method="post" style="display: inline;" onsubmit="return confirm('确定要删除这个轮播图吗？');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $carousel['id']; ?>">
                                        <button type="submit" class="btn btn-danger">删除</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- 轮播图表单 -->
            <div class="carousel-form fade-in">
                <h3><i class="fas fa-<?php echo isset($edit_carousel) ? 'edit' : 'plus'; ?>"></i> <?php echo isset($edit_carousel) ? '编辑轮播图' : '添加轮播图'; ?></h3>
                
                <form action="carousel.php" method="post" enctype="multipart/form-data" id="carouselForm">
                    <input type="hidden" name="action" value="<?php echo isset($edit_carousel) ? 'edit' : 'add'; ?>">
                    <?php if (isset($edit_carousel)): ?>
                        <input type="hidden" name="id" value="<?php echo $edit_carousel['id']; ?>">
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="title">标题 <span class="label-hint">*</span></label>
                        <input type="text" id="title" name="title" value="<?php echo isset($edit_carousel) ? htmlspecialchars($edit_carousel['title']) : ''; ?>" required placeholder="请输入轮播图标题">
                    </div>
                    
                    <div class="form-group">
                        <label for="description">描述 <span class="label-hint">*</span></label>
                        <textarea id="description" name="description" required placeholder="请输入轮播图描述"><?php echo isset($edit_carousel) ? htmlspecialchars($edit_carousel['description']) : ''; ?></textarea>
                    </div>
                    
                    <!-- 图片输入方式选择 -->
                    <div class="form-group">
                        <label>图片 <span class="label-hint">*</span></label>
                        
                        <div class="image-hint">
                            <i class="fas fa-info-circle"></i>
                            支持任意格式和尺寸的图片上传
                        </div>
                        
                        <?php if (isset($edit_carousel)): ?>
                            <!-- 编辑模式：三种选择 -->
                            <div class="image-input-tabs">
                                <div class="image-input-tab active" onclick="switchImageInput('keep')">
                                    <i class="fas fa-image"></i> 保持原图
                                </div>
                                <div class="image-input-tab" onclick="switchImageInput('file')">
                                    <i class="fas fa-upload"></i> 上传新图
                                </div>
                                <div class="image-input-tab" onclick="switchImageInput('url')">
                                    <i class="fas fa-link"></i> 图片链接
                                </div>
                            </div>
                            
                            <input type="hidden" name="image_input_type" id="image_input_type" value="keep">
                            
                            <!-- 保持原图 -->
                            <div id="input-keep" class="image-input-content active">
                                <?php if (!empty($edit_carousel['image'])): ?>
                                    <div class="current-image-container">
                                        <div class="current-label">当前图片：</div>
                                        <?php 
                                            $imageSrc = $edit_carousel['image'];
                                            if (!preg_match('/^https?:\/\//', $imageSrc)) {
                                                $imageSrc = '../' . $imageSrc;
                                            }
                                        ?>
                                        <img src="<?php echo htmlspecialchars($imageSrc); ?>" alt="当前图片" onerror="this.src='../assets/images/default-app-icon.svg'">
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- 上传新图 -->
                            <div id="input-file" class="image-input-content">
                                <input type="file" id="image" name="image" accept="image/*" onchange="previewImage(this)">
                                <div class="image-preview-container" id="filePreview">
                                    <div class="preview-label">新图片预览：</div>
                                    <img src="" alt="预览" id="previewImg">
                                </div>
                            </div>
                            
                            <!-- 图片链接 -->
                            <div id="input-url" class="image-input-content">
                                <input type="url" name="image_url" id="image_url" placeholder="请输入图片URL地址" oninput="previewUrl(this.value)">
                                <div class="image-preview-container" id="urlPreview">
                                    <div class="preview-label">图片预览：</div>
                                    <img src="" alt="预览" id="urlPreviewImg" onerror="this.style.display='none'" onload="this.style.display='block'">
                                </div>
                            </div>
                        <?php else: ?>
                            <!-- 添加模式：两种选择 -->
                            <div class="image-input-tabs">
                                <div class="image-input-tab active" onclick="switchImageInput('file')">
                                    <i class="fas fa-upload"></i> 本地上传
                                </div>
                                <div class="image-input-tab" onclick="switchImageInput('url')">
                                    <i class="fas fa-link"></i> 图片链接
                                </div>
                            </div>
                            
                            <input type="hidden" name="image_input_type" id="image_input_type" value="file">
                            
                            <!-- 本地上传 -->
                            <div id="input-file" class="image-input-content active">
                                <input type="file" id="image" name="image" accept="image/*" onchange="previewImage(this)">
                                <div class="image-preview-container" id="filePreview">
                                    <div class="preview-label">图片预览：</div>
                                    <img src="" alt="预览" id="previewImg">
                                </div>
                            </div>
                            
                            <!-- 图片链接 -->
                            <div id="input-url" class="image-input-content">
                                <input type="url" name="image_url" id="image_url" placeholder="请输入图片URL地址" oninput="previewUrl(this.value)">
                                <div class="image-preview-container" id="urlPreview">
                                    <div class="preview-label">图片预览：</div>
                                    <img src="" alt="预览" id="urlPreviewImg" onerror="this.style.display='none'" onload="this.style.display='block'">
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label for="link">链接 <span class="label-hint">（可选，点击轮播图跳转的地址）</span></label>
                        <input type="url" id="link" name="link" value="<?php echo isset($edit_carousel) ? htmlspecialchars($edit_carousel['link']) : ''; ?>" placeholder="请输入链接地址">
                    </div>
                    
                    <div class="form-group">
                        <label for="order_num">排序 <span class="label-hint">（数字越小越靠前）</span></label>
                        <input type="number" id="order_num" name="order_num" value="<?php echo isset($edit_carousel) ? $edit_carousel['order_num'] : count($carousels) + 1; ?>" min="1" required>
                    </div>
                    
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" id="is_active" name="is_active" <?php echo (isset($edit_carousel) && $edit_carousel['is_active']) || !isset($edit_carousel) ? 'checked' : ''; ?>>
                            <label for="is_active">启用此轮播图</label>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn">
                        <i class="fas fa-save"></i> <?php echo isset($edit_carousel) ? '更新轮播图' : '添加轮播图'; ?>
                    </button>
                    
                    <?php if (isset($edit_carousel)): ?>
                        <a href="carousel.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> 取消编辑
                        </a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>

    <script>
        // 移动端侧边栏切换
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.querySelector('.overlay');
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }

        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const fadeElements = document.querySelectorAll('.fade-in');
            fadeElements.forEach((element, index) => {
                element.style.animationDelay = `${index * 0.1}s`;
            });
        });

        // 切换图片输入方式
        function switchImageInput(type) {
            // 更新隐藏字段
            document.getElementById('image_input_type').value = type;
            
            // 更新标签样式
            document.querySelectorAll('.image-input-tab').forEach(tab => {
                tab.classList.remove('active');
            });
            event.currentTarget.classList.add('active');
            
            // 显示对应内容
            document.querySelectorAll('.image-input-content').forEach(content => {
                content.classList.remove('active');
            });
            document.getElementById('input-' + type).classList.add('active');
        }

        // 预览本地上传的图片
        function previewImage(input) {
            const previewContainer = document.getElementById('filePreview');
            const previewImg = document.getElementById('previewImg');
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    previewContainer.classList.add('show');
                };
                
                reader.readAsDataURL(input.files[0]);
            } else {
                previewContainer.classList.remove('show');
            }
        }

        // 预览URL图片
        function previewUrl(url) {
            const previewContainer = document.getElementById('urlPreview');
            const previewImg = document.getElementById('urlPreviewImg');
            
            if (url.trim()) {
                previewImg.src = url;
                previewContainer.classList.add('show');
            } else {
                previewContainer.classList.remove('show');
            }
        }

        // 表单验证
        document.getElementById('carouselForm').addEventListener('submit', function(e) {
            const imageInputType = document.getElementById('image_input_type').value;
            
            if (imageInputType === 'file') {
                const fileInput = document.getElementById('image');
                <?php if (!isset($edit_carousel)): ?>
                // 添加模式必须选择文件
                if (!fileInput.files || fileInput.files.length === 0) {
                    e.preventDefault();
                    alert('请选择要上传的图片');
                    return false;
                }
                <?php endif; ?>
            } else if (imageInputType === 'url') {
                const urlInput = document.getElementById('image_url');
                if (!urlInput.value.trim()) {
                    e.preventDefault();
                    alert('请输入图片URL地址');
                    return false;
                }
            }
            
            return true;
        });
    </script>
</body>
</html>
