<?php
session_start();
require_once '../include/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: login.php');
    exit;
}

$db = getDB();

// 处理添加公告
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_announcement'])) {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    if (!empty($title) && !empty($content)) {
        addAnnouncement($title, $content, $is_active);
        header('Location: announcements.php');
        exit;
    }
}

// 处理编辑公告
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_announcement'])) {
    $id = $_POST['id'];
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    if (!empty($title) && !empty($content)) {
        updateAnnouncement($id, $title, $content, $is_active);
        header('Location: announcements.php');
        exit;
    }
}

// 处理删除公告
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    deleteAnnouncement($_GET['delete']);
    header('Location: announcements.php');
    exit;
}

// 处理切换状态
if (isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    toggleAnnouncementStatus($_GET['toggle']);
    header('Location: announcements.php');
    exit;
}

// 获取编辑的公告
$edit_announcement = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $edit_announcement = getAnnouncementById($_GET['edit']);
}

// 获取公告列表
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;
$announcements = getAnnouncements($limit, $offset);
$total_count = getAnnouncementsCount();
$total_pages = ceil($total_count / $limit);

// 获取激活公告数
$active_count = getActiveAnnouncementsCount();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>公告管理 - <?php echo getSetting('site_name', SITE_NAME); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* 侧边栏 */
        .sidebar {
            width: 250px;
            background: white;
            box-shadow: var(--box-shadow);
            padding: 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
        }

        .sidebar .logo {
            font-size: 20px;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sidebar .nav-menu {
            list-style: none;
        }

        .sidebar .nav-menu li {
            margin-bottom: 10px;
        }

        .sidebar .nav-menu a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 15px;
            text-decoration: none;
            color: var(--text-color);
            border-radius: var(--border-radius);
            transition: all 0.3s ease;
        }

        .sidebar .nav-menu a:hover {
            background: var(--light-color);
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .sidebar .nav-menu a.active {
            background: var(--primary-color);
            color: white;
        }

        .sidebar .nav-menu a i {
            width: 20px;
            text-align: center;
        }

        /* 主内容区 */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        /* 顶部导航 */
        .top-nav {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 15px 20px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-nav h1 {
            font-size: 24px;
            color: var(--dark-color);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* 统计卡片 */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: white;
        }

        .stat-icon.total { background: var(--primary-color); }
        .stat-icon.active { background: #28a745; }

        .stat-info h3 {
            font-size: 24px;
            color: var(--dark-color);
        }

        .stat-info p {
            color: var(--text-color);
            font-size: 14px;
        }

        /* 按钮样式 */
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: #ff528b;
        }

        .btn-success {
            background: #28a745;
            color: white;
        }

        .btn-success:hover {
            background: #218838;
        }

        .btn-danger {
            background: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background: #c82333;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        /* 表单样式 */
        .form-container {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 30px;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(255, 107, 157, 0.1);
        }

        textarea.form-control {
            resize: vertical;
            min-height: 150px;
        }

        .form-check {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-check input[type="checkbox"] {
            width: auto;
        }

        /* 公告列表 */
        .announcements-list {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
        }

        .announcement-item {
            padding: 20px;
            border-bottom: 1px solid #eee;
            transition: background-color 0.3s ease;
        }

        .announcement-item:hover {
            background: var(--light-color);
        }

        .announcement-item:last-child {
            border-bottom: none;
        }

        .announcement-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
        }

        .announcement-title {
            font-size: 16px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .announcement-meta {
            color: #999;
            font-size: 12px;
            margin-bottom: 10px;
        }

        .announcement-content {
            margin-bottom: 15px;
            line-height: 1.6;
        }

        .announcement-actions {
            display: flex;
            gap: 10px;
        }

        .status-badge {
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }

        .status-active {
            background: #d4edda;
            color: #155724;
        }

        .status-inactive {
            background: #f8d7da;
            color: #721c24;
        }

        /* 分页 */
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 30px;
            gap: 5px;
        }

        .pagination a {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: var(--text-color);
            transition: all 0.3s ease;
        }

        .pagination a:hover {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }

        .pagination .active {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding: 15px;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .announcement-actions {
                flex-wrap: wrap;
            }

            .btn {
                flex: 1;
                min-width: 100px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- 侧边栏 -->
        <div class="sidebar">
            <div class="logo">
                <i class="fas fa-cog"></i>
                <span><?php echo getSetting('site_name', SITE_NAME); ?></span>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php"><i class="fas fa-home"></i> 仪表盘</a></li>
                <li><a href="apps.php"><i class="fas fa-apps"></i> 应用管理</a></li>
                <li><a href="categories.php"><i class="fas fa-th-large"></i> 分类管理</a></li>
                <li><a href="users.php"><i class="fas fa-users"></i> 用户管理</a></li>
                <li><a href="reviews.php"><i class="fas fa-comment"></i> 评论管理</a></li>
                <li><a href="feedback.php"><i class="fas fa-comment-dots"></i> 反馈管理</a></li>
                <li><a href="announcements.php" class="active"><i class="fas fa-bullhorn"></i> 公告管理</a></li>
                <li><a href="carousel.php"><i class="fas fa-images"></i> 轮播图管理</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> 系统设置</a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> 退出登录</a></li>
            </ul>
        </div>

        <!-- 主内容区 -->
        <div class="main-content">
            <!-- 顶部导航 -->
            <div class="top-nav">
                <h1><i class="fas fa-bullhorn"></i> 公告管理</h1>
                <div class="user-info">
                    <span>欢迎，<?php echo $_SESSION['username']; ?></span>
                </div>
            </div>

            <!-- 统计卡片 -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon total">
                        <i class="fas fa-bullhorn"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $total_count; ?></h3>
                        <p>总公告数</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon active">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $active_count; ?></h3>
                        <p>激活公告</p>
                    </div>
                </div>
            </div>

            <!-- 表单区域 -->
            <div class="form-container">
                <h2><?php echo $edit_announcement ? '编辑公告' : '添加公告'; ?></h2>
                <form method="post" action="">
                    <?php if ($edit_announcement): ?>
                        <input type="hidden" name="id" value="<?php echo $edit_announcement['id']; ?>">
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="title">公告标题 *</label>
                        <input type="text" id="title" name="title" class="form-control" 
                               value="<?php echo $edit_announcement ? htmlspecialchars($edit_announcement['title']) : ''; ?>" 
                               placeholder="请输入公告标题" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="content">公告内容 *</label>
                        <textarea id="content" name="content" class="form-control" 
                                  placeholder="请输入公告内容" required><?php echo $edit_announcement ? htmlspecialchars($edit_announcement['content']) : ''; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <div class="form-check">
                            <input type="checkbox" id="is_active" name="is_active" 
                                   <?php echo ($edit_announcement ? $edit_announcement['is_active'] : true) ? 'checked' : ''; ?>>
                            <label for="is_active">激活公告</label>
                        </div>
                    </div>
                    
                    <div style="margin-top: 20px;">
                        <?php if ($edit_announcement): ?>
                            <button type="submit" name="edit_announcement" class="btn btn-primary">
                                <i class="fas fa-save"></i> 保存修改
                            </button>
                            <a href="announcements.php" class="btn btn-secondary">
                                <i class="fas fa-times"></i> 取消
                            </a>
                        <?php else: ?>
                            <button type="submit" name="add_announcement" class="btn btn-primary">
                                <i class="fas fa-plus"></i> 添加公告
                            </button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <!-- 公告列表 -->
            <div class="announcements-list">
                <?php if (empty($announcements)): ?>
                    <div style="padding: 40px; text-align: center;">
                        <i class="fas fa-bullhorn" style="font-size: 48px; color: #ddd; margin-bottom: 20px;"></i>
                        <h3>暂无公告</h3>
                        <p>您还没有添加任何公告</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($announcements as $announcement): ?>
                        <div class="announcement-item">
                            <div class="announcement-header">
                                <div>
                                    <h3 class="announcement-title"><?php echo htmlspecialchars($announcement['title']); ?></h3>
                                    <div class="announcement-meta">
                                        <span><?php echo date('Y-m-d H:i', strtotime($announcement['created_at'])); ?></span>
                                        <span style="margin: 0 10px;">|</span>
                                        <span class="status-badge <?php echo $announcement['is_active'] ? 'status-active' : 'status-inactive'; ?>">
                                            <?php echo $announcement['is_active'] ? '已激活' : '未激活'; ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="announcement-actions">
                                    <a href="?edit=<?php echo $announcement['id']; ?>" class="btn btn-secondary">
                                        <i class="fas fa-edit"></i> 编辑
                                    </a>
                                    <a href="?toggle=<?php echo $announcement['id']; ?>" class="btn <?php echo $announcement['is_active'] ? 'btn-danger' : 'btn-success'; ?>">
                                        <i class="fas <?php echo $announcement['is_active'] ? 'fa-eye-slash' : 'fa-eye'; ?>"></i> 
                                        <?php echo $announcement['is_active'] ? '停用' : '激活'; ?>
                                    </a>
                                    <a href="?delete=<?php echo $announcement['id']; ?>" class="btn btn-danger" onclick="return confirm('确定删除这条公告吗？');">
                                        <i class="fas fa-trash"></i> 删除
                                    </a>
                                </div>
                            </div>
                            <div class="announcement-content">
                                <?php echo nl2br(htmlspecialchars($announcement['content'])); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- 分页 -->
            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>" class="<?php echo $i == $page ? 'active' : ''; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>