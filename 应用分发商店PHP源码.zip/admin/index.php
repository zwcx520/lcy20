<?php
session_start();
require_once '../include/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: login.php');
    exit;
}

// 获取应用数量
$db = getDB();
$stmt = $db->prepare("SELECT COUNT(*) FROM apps");
$stmt->execute();
$appCount = $stmt->fetchColumn();

// 获取分类数量
$stmt = $db->prepare("SELECT COUNT(*) FROM categories");
$stmt->execute();
$categoryCount = $stmt->fetchColumn();

// 获取用户数量
$stmt = $db->prepare("SELECT COUNT(*) FROM users");
$stmt->execute();
$userCount = $stmt->fetchColumn();

// 获取下载总量
$stmt = $db->prepare("SELECT COALESCE(SUM(download_count), 0) FROM apps");
$stmt->execute();
$downloadCount = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>后台管理 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* 侧边栏 */
        .sidebar {
            width: 250px;
            background: white;
            box-shadow: var(--box-shadow);
            padding: 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
            transition: transform 0.3s ease;
        }

        .sidebar .logo {
            font-size: 20px;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sidebar .logo i {
            font-size: 24px;
        }

        .sidebar .nav-menu {
            list-style: none;
        }

        .sidebar .nav-menu li {
            margin-bottom: 10px;
        }

        .sidebar .nav-menu a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 15px;
            text-decoration: none;
            color: var(--text-color);
            border-radius: var(--border-radius);
            transition: all 0.3s ease;
        }

        .sidebar .nav-menu a:hover {
            background: var(--light-color);
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .sidebar .nav-menu a.active {
            background: var(--primary-color);
            color: white;
        }

        .sidebar .nav-menu a i {
            width: 20px;
            text-align: center;
        }

        /* 移动端菜单按钮 */
        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 45px;
            height: 45px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: var(--box-shadow);
        }

        /* 遮罩层 */
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        /* 主内容区 */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        /* 顶部导航 */
        .top-nav {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 15px 20px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .top-nav .welcome {
            font-size: 18px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .top-nav .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .top-nav .user-info .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }

        .top-nav .user-info .user-name {
            font-weight: 500;
            color: var(--dark-color);
        }

        .top-nav .user-info .logout {
            color: var(--text-color);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .top-nav .user-info .logout:hover {
            color: var(--primary-color);
        }

        /* 统计卡片 */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 20px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }

        .stat-card .stat-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            color: white;
            font-size: 24px;
        }

        .stat-card .stat-value {
            font-size: 24px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 5px;
        }

        .stat-card .stat-label {
            font-size: 14px;
            color: var(--text-color);
        }

        /* 最近活动 */
        .activity-section {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 20px;
        }

        .activity-section h2 {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .activity-section h2 i {
            color: var(--primary-color);
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            padding: 15px;
            border-bottom: 1px solid #eee;
            transition: all 0.3s ease;
        }

        .activity-item:hover {
            background: var(--light-color);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-item .activity-time {
            font-size: 12px;
            color: #999;
            margin-bottom: 5px;
        }

        .activity-item .activity-content {
            font-size: 14px;
            color: var(--text-color);
        }

        /* 响应式设计 - 移动端优化 */
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .overlay.active {
                display: block;
            }

            .main-content {
                margin-left: 0;
                padding: 70px 15px 20px;
            }

            .top-nav {
                flex-direction: column;
                text-align: center;
                padding: 12px 15px;
            }

            .top-nav .welcome {
                font-size: 16px;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
            }

            .stat-card {
                padding: 15px;
            }

            .stat-card .stat-icon {
                width: 50px;
                height: 50px;
                font-size: 20px;
            }

            .stat-card .stat-value {
                font-size: 20px;
            }

            .stat-card .stat-label {
                font-size: 12px;
            }
        }

        @media (max-width: 480px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }

            .top-nav .user-info {
                flex-wrap: wrap;
                justify-content: center;
            }
        }

        /* 动画效果 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <!-- 移动端菜单按钮 -->
    <button class="mobile-menu-btn" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <!-- 遮罩层 -->
    <div class="overlay" onclick="toggleSidebar()"></div>

    <div class="container">
        <!-- 侧边栏 -->
        <div class="sidebar" id="sidebar">
            <div class="logo">
                <i class="fas fa-cog"></i>
                <span><?php echo SITE_NAME; ?> 管理</span>
            </div>
            <ul class="nav-menu">
                <li>
                    <a href="index.php" class="active">
                        <i class="fas fa-home"></i>
                        <span>仪表盘</span>
                    </a>
                </li>
                <li>
                    <a href="apps.php">
                        <i class="fas fa-apps"></i>
                        <span>应用管理</span>
                    </a>
                </li>
                <li>
                    <a href="categories.php">
                        <i class="fas fa-th-large"></i>
                        <span>分类管理</span>
                    </a>
                </li>
                <li>
                    <a href="users.php">
                        <i class="fas fa-users"></i>
                        <span>用户管理</span>
                    </a>
                </li>
                <li>
                    <a href="reviews.php">
                        <i class="fas fa-comment"></i>
                        <span>评论管理</span>
                    </a>
                </li>
                <li>
                    <a href="feedback.php">
                        <i class="fas fa-comment-dots"></i>
                        <span>反馈管理</span>
                    </a>
                </li>
                <li>
                    <a href="carousel.php">
                        <i class="fas fa-images"></i>
                        <span>轮播图管理</span>
                    </a>
                </li>
                <li>
                    <a href="settings.php">
                        <i class="fas fa-cog"></i>
                        <span>系统设置</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- 主内容区 -->
        <div class="main-content">
            <!-- 顶部导航 -->
            <div class="top-nav fade-in">
                <div class="welcome">
                    <i class="fas fa-user"></i> 欢迎回来，<?php echo $_SESSION['username']; ?>！
                </div>
                <div class="user-info">
                    <div class="user-avatar">
                        <?php echo substr($_SESSION['username'], 0, 1); ?>
                    </div>
                    <div class="user-name"><?php echo $_SESSION['username']; ?></div>
                    <a href="logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> 退出</a>
                </div>
            </div>

            <!-- 统计卡片 -->
            <div class="stats-grid">
                <div class="stat-card fade-in">
                    <div class="stat-icon">
                        <i class="fas fa-apps"></i>
                    </div>
                    <div class="stat-value"><?php echo $appCount; ?></div>
                    <div class="stat-label">应用总数</div>
                </div>
                <div class="stat-card fade-in">
                    <div class="stat-icon">
                        <i class="fas fa-th-large"></i>
                    </div>
                    <div class="stat-value"><?php echo $categoryCount; ?></div>
                    <div class="stat-label">分类数量</div>
                </div>
                <div class="stat-card fade-in">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-value"><?php echo $userCount; ?></div>
                    <div class="stat-label">用户数量</div>
                </div>
                <div class="stat-card fade-in">
                    <div class="stat-icon">
                        <i class="fas fa-download"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($downloadCount); ?></div>
                    <div class="stat-label">下载总量</div>
                </div>
            </div>

            <!-- 最近活动 -->
            <div class="activity-section fade-in">
                <h2><i class="fas fa-history"></i> 最近活动</h2>
                <ul class="activity-list">
                    <li class="activity-item">
                        <div class="activity-time">2026-03-26 12:30:00</div>
                        <div class="activity-content">管理员 <?php echo $_SESSION['username']; ?> 登录了后台管理系统</div>
                    </li>
                    <li class="activity-item">
                        <div class="activity-time">2026-03-25 18:45:00</div>
                        <div class="activity-content">用户 test 用户注册了新账号</div>
                    </li>
                    <li class="activity-item">
                        <div class="activity-time">2026-03-25 15:20:00</div>
                        <div class="activity-content">应用 "测试应用" 被下载了 10 次</div>
                    </li>
                    <li class="activity-item">
                        <div class="activity-time">2026-03-25 10:15:00</div>
                        <div class="activity-content">管理员 <?php echo $_SESSION['username']; ?> 添加了新应用 "测试应用"</div>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <script>
        // 移动端侧边栏切换
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.querySelector('.overlay');
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }

        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const fadeElements = document.querySelectorAll('.fade-in');
            fadeElements.forEach((element, index) => {
                element.style.animationDelay = `${index * 0.1}s`;
            });
        });
    </script>
</body>
</html>