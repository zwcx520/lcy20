<?php
session_start();
require_once '../include/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: login.php');
    exit;
}

// 获取所有应用
$db = getDB();
$stmt = $db->prepare("SELECT apps.*, categories.name as category_name FROM apps 
                      LEFT JOIN categories ON apps.category_id = categories.id 
                      ORDER BY apps.created_at DESC");
$stmt->execute();
$apps = $stmt->fetchAll();

// 获取所有分类
$categories = getCategories();

// 处理删除应用
if (isset($_GET['delete'])) {
    $app_id = $_GET['delete'];
    
    // 获取应用信息（包括图标、横幅和应用文件路径）
    $stmt = $db->prepare("SELECT icon, banner, download_url FROM apps WHERE id = ?");
    $stmt->execute([$app_id]);
    $app = $stmt->fetch();
    
    // 删除应用图标文件
    if ($app && !empty($app['icon'])) {
        $icon_path = '../' . $app['icon'];
        if (file_exists($icon_path)) {
            unlink($icon_path);
        }
    }
    
    // 删除应用横幅文件
    if ($app && !empty($app['banner'])) {
        $banner_path = '../' . $app['banner'];
        if (file_exists($banner_path)) {
            unlink($banner_path);
        }
    }
    
    // 删除应用文件
    if ($app && !empty($app['download_url'])) {
        $download_path = '../' . $app['download_url'];
        if (file_exists($download_path)) {
            unlink($download_path);
        }
    }
    
    // 删除应用记录
    $stmt = $db->prepare("DELETE FROM apps WHERE id = ?");
    $stmt->execute([$app_id]);
    header('Location: apps.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>应用管理 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* 侧边栏 */
        .sidebar {
            width: 250px;
            background: white;
            box-shadow: var(--box-shadow);
            padding: 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
            transition: transform 0.3s ease;
        }

        /* 移动端菜单按钮 */
        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 45px;
            height: 45px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: var(--box-shadow);
        }

        /* 遮罩层 */
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        .sidebar .logo {
            font-size: 20px;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sidebar .logo i {
            font-size: 24px;
        }

        .sidebar .nav-menu {
            list-style: none;
        }

        .sidebar .nav-menu li {
            margin-bottom: 10px;
        }

        .sidebar .nav-menu a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 15px;
            text-decoration: none;
            color: var(--text-color);
            border-radius: var(--border-radius);
            transition: all 0.3s ease;
        }

        .sidebar .nav-menu a:hover {
            background: var(--light-color);
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .sidebar .nav-menu a.active {
            background: var(--primary-color);
            color: white;
        }

        .sidebar .nav-menu a i {
            width: 20px;
            text-align: center;
        }

        /* 主内容区 */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        /* 顶部导航 */
        .top-nav {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 15px 20px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-nav .title {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark-color);
        }

        .top-nav .btn {
            padding: 8px 16px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .top-nav .btn:hover {
            background: #ff528b;
            transform: translateY(-2px);
        }

        /* 应用列表 */
        .app-list {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
        }

        .app-list table {
            width: 100%;
            border-collapse: collapse;
        }

        .app-list th,
        .app-list td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .app-list th {
            background: var(--light-color);
            font-weight: 500;
            color: var(--dark-color);
        }

        .app-list tr:hover {
            background: var(--light-color);
        }

        .app-list .app-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            overflow: hidden;
        }

        .app-list .app-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .app-list .actions {
            display: flex;
            gap: 10px;
        }

        .app-list .action-btn {
            padding: 6px 12px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .app-list .action-btn.edit {
            background: var(--secondary-color);
            color: white;
        }

        .app-list .action-btn.edit:hover {
            background: #3db8b0;
        }

        .app-list .action-btn.delete {
            background: #e74c3c;
            color: white;
        }

        .app-list .action-btn.delete:hover {
            background: #c0392b;
        }

        /* 无应用提示 */
        .no-apps {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-color);
        }

        .no-apps i {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 20px;
        }

        .no-apps h3 {
            font-size: 20px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 10px;
        }

        /* 响应式设计 - 移动端优化 */
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .overlay.active {
                display: block;
            }

            .main-content {
                margin-left: 0;
                padding: 70px 15px 20px;
            }

            .top-nav {
                flex-direction: column;
                text-align: center;
                padding: 12px 15px;
            }

            .app-list {
                overflow-x: auto;
            }

            .app-list table {
                font-size: 12px;
                min-width: 800px;
            }

            .app-list th,
            .app-list td {
                padding: 8px;
            }

            .app-list .actions {
                flex-direction: row;
                gap: 5px;
            }

            .app-list .action-btn {
                padding: 4px 8px;
                font-size: 11px;
            }
        }

        /* 动画效果 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <!-- 移动端菜单按钮 -->
    <button class="mobile-menu-btn" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <!-- 遮罩层 -->
    <div class="overlay" onclick="toggleSidebar()"></div>

    <div class="container">
        <!-- 侧边栏 -->
        <div class="sidebar" id="sidebar">
            <div class="logo">
                <i class="fas fa-cog"></i>
                <span><?php echo SITE_NAME; ?> 管理</span>
            </div>
            <ul class="nav-menu">
                <li>
                    <a href="index.php">
                        <i class="fas fa-home"></i>
                        <span>仪表盘</span>
                    </a>
                </li>
                <li>
                    <a href="apps.php" class="active">
                        <i class="fas fa-apps"></i>
                        <span>应用管理</span>
                    </a>
                </li>
                <li>
                    <a href="categories.php">
                        <i class="fas fa-th-large"></i>
                        <span>分类管理</span>
                    </a>
                </li>
                <li>
                    <a href="users.php">
                        <i class="fas fa-users"></i>
                        <span>用户管理</span>
                    </a>
                </li>
                <li>
                    <a href="reviews.php">
                        <i class="fas fa-comment"></i>
                        <span>评论管理</span>
                    </a>
                </li>
                <li>
                    <a href="feedback.php">
                        <i class="fas fa-comment-dots"></i>
                        <span>反馈管理</span>
                    </a>
                </li>
                <li>
                    <a href="carousel.php">
                        <i class="fas fa-images"></i>
                        <span>轮播图管理</span>
                    </a>
                </li>
                <li>
                    <a href="settings.php">
                        <i class="fas fa-cog"></i>
                        <span>系统设置</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- 主内容区 -->
        <div class="main-content">
            <!-- 顶部导航 -->
            <div class="top-nav fade-in">
                <div class="title">
                    <i class="fas fa-apps"></i> 应用管理
                </div>
                <a href="add_app.php" class="btn">
                    <i class="fas fa-plus"></i> 添加应用
                </a>
            </div>

            <!-- 应用列表 -->
            <div class="app-list fade-in">
                <?php if (empty($apps)): ?>
                    <div class="no-apps">
                        <i class="fas fa-box-open"></i>
                        <h3>暂无应用</h3>
                        <p>点击添加应用按钮添加新应用</p>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>图标</th>
                                <th>应用名称</th>
                                <th>分类</th>
                                <th>版本</th>
                                <th>大小</th>
                                <th>下载次数</th>
                                <th>评分</th>
                                <th>创建时间</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($apps as $app): ?>
                                <tr>
                                    <td>
                                        <div class="app-icon">
                                            <img src="https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=anime%20style%20app%20icon%20cute%20colorful&image_size=square" alt="<?php echo $app['name']; ?>">
                                        </div>
                                    </td>
                                    <td><?php echo $app['name']; ?></td>
                                    <td><?php echo $app['category_name']; ?></td>
                                    <td><?php echo $app['version']; ?></td>
                                    <td><?php echo $app['size']; ?></td>
                                    <td><?php echo number_format($app['download_count']); ?></td>
                                    <td><?php echo number_format($app['rating'], 1); ?></td>
                                    <td><?php echo date('Y-m-d H:i:s', strtotime($app['created_at'])); ?></td>
                                    <td>
                                        <div class="actions">
                                            <a href="edit_app.php?id=<?php echo $app['id']; ?>" class="action-btn edit">
                                                <i class="fas fa-edit"></i> 编辑
                                            </a>
                                            <a href="apps.php?delete=<?php echo $app['id']; ?>" class="action-btn delete" onclick="return confirm('确定要删除这个应用吗？');">
                                                <i class="fas fa-trash"></i> 删除
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // 移动端侧边栏切换
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.querySelector('.overlay');
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }

        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const fadeElements = document.querySelectorAll('.fade-in');
            fadeElements.forEach((element, index) => {
                element.style.animationDelay = `${index * 0.1}s`;
            });
        });
    </script>
</body>
</html>