<?php
session_start();
require_once '../include/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: login.php');
    exit;
}

// 获取所有分类
$categories = getCategories();

// 处理添加分类
if (isset($_POST['add_category'])) {
    $name = $_POST['name'];
    $icon = $_POST['icon'];
    
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO categories (name, icon) VALUES (?, ?)");
    $stmt->execute([$name, $icon]);
    header('Location: categories.php');
    exit;
}

// 处理删除分类
if (isset($_GET['delete'])) {
    $category_id = $_GET['delete'];
    $db = getDB();
    $stmt = $db->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->execute([$category_id]);
    header('Location: categories.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>分类管理 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* 侧边栏 */
        .sidebar {
            width: 250px;
            background: white;
            box-shadow: var(--box-shadow);
            padding: 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
            transition: transform 0.3s ease;
        }

        /* 移动端菜单按钮 */
        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 45px;
            height: 45px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: var(--box-shadow);
        }

        /* 遮罩层 */
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        .sidebar .logo {
            font-size: 20px;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sidebar .logo i {
            font-size: 24px;
        }

        .sidebar .nav-menu {
            list-style: none;
        }

        .sidebar .nav-menu li {
            margin-bottom: 10px;
        }

        .sidebar .nav-menu a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 15px;
            text-decoration: none;
            color: var(--text-color);
            border-radius: var(--border-radius);
            transition: all 0.3s ease;
        }

        .sidebar .nav-menu a:hover {
            background: var(--light-color);
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .sidebar .nav-menu a.active {
            background: var(--primary-color);
            color: white;
        }

        .sidebar .nav-menu a i {
            width: 20px;
            text-align: center;
        }

        /* 主内容区 */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        /* 顶部导航 */
        .top-nav {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 15px 20px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-nav .title {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark-color);
        }

        .top-nav .btn {
            padding: 8px 16px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .top-nav .btn:hover {
            background: #ff528b;
            transform: translateY(-2px);
        }

        /* 分类列表 */
        .category-list {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            margin-bottom: 30px;
        }

        .category-list table {
            width: 100%;
            border-collapse: collapse;
        }

        .category-list th,
        .category-list td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .category-list th {
            background: var(--light-color);
            font-weight: 500;
            color: var(--dark-color);
        }

        .category-list tr:hover {
            background: var(--light-color);
        }

        .category-list .category-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            color: white;
        }

        .category-list .actions {
            display: flex;
            gap: 10px;
        }

        .category-list .action-btn {
            padding: 6px 12px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .category-list .action-btn.edit {
            background: var(--secondary-color);
            color: white;
        }

        .category-list .action-btn.edit:hover {
            background: #3db8b0;
        }

        .category-list .action-btn.delete {
            background: #e74c3c;
            color: white;
        }

        .category-list .action-btn.delete:hover {
            background: #c0392b;
        }

        /* 添加分类表单 */
        .add-category-form {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 30px;
        }

        .add-category-form h3 {
            font-size: 18px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 20px;
        }

        .add-category-form .form-group {
            margin-bottom: 15px;
        }

        .add-category-form label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .add-category-form input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 14px;
        }

        .add-category-form .btn {
            padding: 10px 20px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            background: var(--primary-color);
            color: white;
        }

        .add-category-form .btn:hover {
            background: #ff528b;
            transform: translateY(-2px);
        }

        /* 无分类提示 */
        .no-categories {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-color);
        }

        .no-categories i {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 20px;
        }

        .no-categories h3 {
            font-size: 20px;
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 10px;
        }

        /* 响应式设计 - 移动端优化 */
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .overlay.active {
                display: block;
            }

            .main-content {
                margin-left: 0;
                padding: 70px 15px 20px;
            }

            .category-list table {
                font-size: 14px;
            }

            .category-list th,
            .category-list td {
                padding: 10px;
            }

            .category-list .actions {
                flex-direction: column;
                gap: 5px;
            }
        }

        /* 动画效果 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <!-- 移动端菜单按钮 -->
    <button class="mobile-menu-btn" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <!-- 遮罩层 -->
    <div class="overlay" onclick="toggleSidebar()"></div>

    <div class="container">
        <!-- 侧边栏 -->
        <div class="sidebar" id="sidebar">
            <div class="logo">
                <i class="fas fa-cog"></i>
                <span><?php echo SITE_NAME; ?> 管理</span>
            </div>
            <ul class="nav-menu">
                <li>
                    <a href="index.php">
                        <i class="fas fa-home"></i>
                        <span>仪表盘</span>
                    </a>
                </li>
                <li>
                    <a href="apps.php">
                        <i class="fas fa-apps"></i>
                        <span>应用管理</span>
                    </a>
                </li>
                <li>
                    <a href="categories.php" class="active">
                        <i class="fas fa-th-large"></i>
                        <span>分类管理</span>
                    </a>
                </li>
                <li>
                    <a href="users.php">
                        <i class="fas fa-users"></i>
                        <span>用户管理</span>
                    </a>
                </li>
                <li>
                    <a href="reviews.php">
                        <i class="fas fa-comment"></i>
                        <span>评论管理</span>
                    </a>
                </li>
                <li>
                    <a href="feedback.php">
                        <i class="fas fa-comment-dots"></i>
                        <span>反馈管理</span>
                    </a>
                </li>
                <li>
                    <a href="carousel.php">
                        <i class="fas fa-images"></i>
                        <span>轮播图管理</span>
                    </a>
                </li>
                <li>
                    <a href="settings.php">
                        <i class="fas fa-cog"></i>
                        <span>系统设置</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- 主内容区 -->
        <div class="main-content">
            <!-- 顶部导航 -->
            <div class="top-nav fade-in">
                <div class="title">
                    <i class="fas fa-th-large"></i> 分类管理
                </div>
            </div>

            <!-- 分类列表 -->
            <div class="category-list fade-in">
                <?php if (empty($categories)): ?>
                    <div class="no-categories">
                        <i class="fas fa-th-large"></i>
                        <h3>暂无分类</h3>
                        <p>添加新的应用分类</p>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>图标</th>
                                <th>分类名称</th>
                                <th>创建时间</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($categories as $category): ?>
                                <tr>
                                    <td>
                                        <div class="category-icon">
                                            <?php 
                                                switch ($category['name']) {
                                                    case '游戏': echo '<i class="fas fa-gamepad"></i>'; break;
                                                    case '工具': echo '<i class="fas fa-tools"></i>'; break;
                                                    case '社交': echo '<i class="fas fa-users"></i>'; break;
                                                    case '娱乐': echo '<i class="fas fa-film"></i>'; break;
                                                    case '教育': echo '<i class="fas fa-graduation-cap"></i>'; break;
                                                    case '生活': echo '<i class="fas fa-home"></i>'; break;
                                                    case '健康': echo '<i class="fas fa-heartbeat"></i>'; break;
                                                    case '新闻': echo '<i class="fas fa-newspaper"></i>'; break;
                                                    default: echo '<i class="fas fa-apps"></i>';
                                                }
                                            ?>
                                        </div>
                                    </td>
                                    <td><?php echo $category['name']; ?></td>
                                    <td><?php echo date('Y-m-d H:i:s', strtotime($category['created_at'])); ?></td>
                                    <td>
                                        <div class="actions">
                                            <a href="edit_category.php?id=<?php echo $category['id']; ?>" class="action-btn edit">
                                                <i class="fas fa-edit"></i> 编辑
                                            </a>
                                            <a href="categories.php?delete=<?php echo $category['id']; ?>" class="action-btn delete" onclick="return confirm('确定要删除这个分类吗？');">
                                                <i class="fas fa-trash"></i> 删除
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- 添加分类表单 -->
            <div class="add-category-form fade-in">
                <h3><i class="fas fa-plus"></i> 添加分类</h3>
                <form action="categories.php" method="post">
                    <div class="form-group">
                        <label for="name">分类名称:</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="icon">图标类名 (Font Awesome):</label>
                        <input type="text" id="icon" name="icon" placeholder="例如: gamepad" required>
                    </div>
                    <button type="submit" name="add_category" class="btn">
                        <i class="fas fa-plus"></i> 添加分类
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // 移动端侧边栏切换
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.querySelector('.overlay');
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }

        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const fadeElements = document.querySelectorAll('.fade-in');
            fadeElements.forEach((element, index) => {
                element.style.animationDelay = `${index * 0.1}s`;
            });
        });
    </script>
</body>
</html>