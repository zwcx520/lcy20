<?php
// 开启输出缓冲
ob_start();

session_start();

// 清除所有会话变量
$_SESSION = array();

// 如果存在会话cookie，删除它
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 3600, '/');
}

// 销毁会话
session_destroy();

// 清除输出缓冲并关闭
ob_end_clean();

// 重定向到登录页面
header('Location: login.php');
exit;
?>