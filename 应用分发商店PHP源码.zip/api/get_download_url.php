<?php
session_start();
require_once '../include/functions.php';

header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => '缺少应用ID']);
    exit;
}

$app_id = intval($_GET['id']);
$app = getAppById($app_id);

if (!$app) {
    echo json_encode(['success' => false, 'message' => '应用不存在']);
    exit;
}

if (empty($app['download_url'])) {
    echo json_encode(['success' => false, 'message' => '暂无下载文件']);
    exit;
}

// 增加下载次数
incrementDownloadCount($app_id);

// 记录下载日志
$log_file = '../logs/downloads.log';
$log_dir = dirname($log_file);
if (!file_exists($log_dir)) {
    mkdir($log_dir, 0777, true);
}
$log_message = date('Y-m-d H:i:s') . ' | ';
$log_message .= 'App: ' . $app['name'] . ' (ID: ' . $app_id . ') | ';
$log_message .= 'URL: ' . $app['download_url'] . ' | ';
$log_message .= 'IP: ' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . ' | ';
$log_message .= 'User: ' . (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'guest') . PHP_EOL;
file_put_contents($log_file, $log_message, FILE_APPEND | LOCK_EX);

// 构建下载文件名
$file_name = basename($app['download_url']);
$file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
$safe_app_name = preg_replace('/[^\w\-\.\s]/', '_', $app['name']);
$safe_version = preg_replace('/[^\w\-\.]/', '_', $app['version']);
$download_file_name = $safe_app_name . '_v' . $safe_version . '.' . $file_extension;

echo json_encode([
    'success' => true,
    'download_url' => $app['download_url'],
    'file_name' => $download_file_name,
    'app_name' => $app['name']
]);
exit;
?>
