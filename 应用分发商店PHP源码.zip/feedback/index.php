<?php
session_start();
require_once '../include/functions.php';

// 检查用户是否登录
if (!isLoggedIn()) {
    header('Location: ../user/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit;
}

// 获取当前用户信息
$currentUser = getCurrentUser();

// 处理反馈提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? 'other';
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    
    // 验证输入
    $errors = [];
    if (empty($title)) {
        $errors[] = '请输入反馈标题';
    }
    if (empty($content)) {
        $errors[] = '请输入反馈内容';
    }
    
    if (empty($errors)) {
        $db = getDB();
        
        try {
            $stmt = $db->prepare("INSERT INTO feedback (user_id, username, email, type, title, content) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $_SESSION['user_id'], 
                $_SESSION['username'], 
                $currentUser['email'], 
                $type, 
                $title, 
                $content
            ]);
            $success = true;
        } catch (PDOException $e) {
            $errors[] = '提交失败，请稍后重试';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户反馈 - <?php echo getSetting('site_name', SITE_NAME); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* 导航栏 */
        header {
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            color: white;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
        }

        .logo {
            font-size: 20px;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 8px;
            color: white;
            text-decoration: none;
        }

        .logo i {
            font-size: 24px;
        }

        .back-btn {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .back-btn:hover {
            transform: translateX(-3px);
        }

        /* 用户信息卡片 */
        .user-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 20px;
            margin: 30px 0 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            overflow: hidden;
            background: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            font-weight: bold;
            flex-shrink: 0;
        }

        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-info h3 {
            font-size: 18px;
            color: var(--dark-color);
            margin-bottom: 5px;
        }

        .user-info p {
            color: var(--text-color);
            font-size: 14px;
        }

        /* 反馈表单 */
        .feedback-section {
            margin: 20px 0 40px;
        }

        .feedback-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .feedback-header h1 {
            font-size: 28px;
            color: var(--dark-color);
            margin-bottom: 10px;
        }

        .feedback-header p {
            color: var(--text-color);
            font-size: 16px;
        }

        .feedback-form {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 40px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .form-group label .required {
            color: var(--primary-color);
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: var(--border-radius);
            font-size: 14px;
            transition: all 0.3s ease;
            font-family: inherit;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(255, 107, 157, 0.1);
        }

        textarea.form-control {
            resize: vertical;
            min-height: 150px;
        }

        .feedback-types {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .feedback-type {
            flex: 1;
            min-width: 120px;
        }

        .feedback-type input {
            display: none;
        }

        .feedback-type label {
            display: block;
            padding: 12px 20px;
            text-align: center;
            border: 2px solid #e0e0e0;
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 0;
        }

        .feedback-type input:checked + label {
            border-color: var(--primary-color);
            background: rgba(255, 107, 157, 0.1);
            color: var(--primary-color);
        }

        .feedback-type label:hover {
            border-color: var(--primary-color);
        }

        .feedback-type i {
            display: block;
            font-size: 20px;
            margin-bottom: 5px;
        }

        .submit-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            color: white;
            border: none;
            border-radius: var(--border-radius);
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(255, 107, 157, 0.3);
        }

        /* 提示消息 */
        .alert {
            padding: 15px 20px;
            border-radius: var(--border-radius);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert ul {
            margin: 0;
            padding-left: 20px;
        }

        /* 成功页面 */
        .success-page {
            text-align: center;
            padding: 60px 20px;
        }

        .success-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 30px;
            color: white;
            font-size: 40px;
        }

        .success-page h2 {
            font-size: 24px;
            color: var(--dark-color);
            margin-bottom: 15px;
        }

        .success-page p {
            color: var(--text-color);
            margin-bottom: 30px;
        }

        .back-home-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 30px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 30px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .back-home-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 107, 157, 0.3);
        }

        /* 页脚 */
        footer {
            background: var(--dark-color);
            color: white;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
        }

        footer p {
            color: #999;
            font-size: 14px;
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
            .user-card {
                padding: 15px;
            }

            .user-avatar {
                width: 50px;
                height: 50px;
                font-size: 20px;
            }

            .feedback-form {
                padding: 25px;
            }

            .feedback-types {
                flex-direction: column;
            }

            .feedback-type {
                min-width: auto;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <header>
        <div class="container">
            <div class="nav-container">
                <a href="../index.php" class="logo">
                    <i class="fas fa-gamepad"></i>
                    <span><?php echo getSetting('site_name', SITE_NAME); ?></span>
                </a>
                <a href="../index.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i> 返回首页
                </a>
            </div>
        </div>
    </header>

    <div class="container">
        <?php if (isset($success) && $success): ?>
            <!-- 提交成功页面 -->
            <div class="feedback-section">
                <div class="feedback-form success-page">
                    <div class="success-icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <h2>感谢您的反馈！</h2>
                    <p>我们已经收到您的反馈信息，会尽快进行处理。感谢您的支持与理解！</p>
                    <a href="../index.php" class="back-home-btn">
                        <i class="fas fa-home"></i> 返回首页
                    </a>
                </div>
            </div>
        <?php else: ?>
            <!-- 用户信息卡片 -->
            <div class="user-card">
                <div class="user-avatar">
                    <?php if (!empty($currentUser['avatar'])): ?>
                        <img src="../<?php echo $currentUser['avatar']; ?>" alt="<?php echo $currentUser['username']; ?>">
                    <?php else: ?>
                        <?php echo substr($currentUser['username'], 0, 1); ?>
                    <?php endif; ?>
                </div>
                <div class="user-info">
                    <h3><?php echo htmlspecialchars($currentUser['username']); ?></h3>
                    <p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($currentUser['email']); ?></p>
                </div>
            </div>

            <!-- 反馈表单 -->
            <div class="feedback-section">
                <div class="feedback-header">
                    <h1><i class="fas fa-comment-dots"></i> 用户反馈</h1>
                    <p>您的意见是我们改进的动力，请告诉我们您的想法</p>
                </div>

                <div class="feedback-form">
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-error">
                            <i class="fas fa-exclamation-circle"></i>
                            <ul>
                                <?php foreach ($errors as $error): ?>
                                    <li><?php echo $error; ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="post" action="">
                        <!-- 反馈类型 -->
                        <div class="form-group">
                            <label>反馈类型</label>
                            <div class="feedback-types">
                                <div class="feedback-type">
                                    <input type="radio" id="type_bug" name="type" value="bug" checked>
                                    <label for="type_bug">
                                        <i class="fas fa-bug"></i>
                                        功能异常
                                    </label>
                                </div>
                                <div class="feedback-type">
                                    <input type="radio" id="type_feature" name="type" value="feature">
                                    <label for="type_feature">
                                        <i class="fas fa-lightbulb"></i>
                                        功能建议
                                    </label>
                                </div>
                                <div class="feedback-type">
                                    <input type="radio" id="type_content" name="type" value="content">
                                    <label for="type_content">
                                        <i class="fas fa-exclamation-triangle"></i>
                                        内容举报
                                    </label>
                                </div>
                                <div class="feedback-type">
                                    <input type="radio" id="type_other" name="type" value="other">
                                    <label for="type_other">
                                        <i class="fas fa-ellipsis-h"></i>
                                        其他反馈
                                    </label>
                                </div>
                            </div>
                        </div>

                        <!-- 反馈标题 -->
                        <div class="form-group">
                            <label for="title">反馈标题 <span class="required">*</span></label>
                            <input type="text" id="title" name="title" class="form-control" 
                                   value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>" 
                                   placeholder="请简要描述您的问题或建议" required>
                        </div>

                        <!-- 反馈内容 -->
                        <div class="form-group">
                            <label for="content">详细描述 <span class="required">*</span></label>
                            <textarea id="content" name="content" class="form-control" 
                                      placeholder="请详细描述您遇到的问题或建议，如果是功能异常，请说明操作步骤和具体表现..." required><?php echo isset($_POST['content']) ? htmlspecialchars($_POST['content']) : ''; ?></textarea>
                        </div>

                        <button type="submit" class="submit-btn">
                            <i class="fas fa-paper-plane"></i> 提交反馈
                        </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- 页脚 -->
    <footer>
        <div class="container">
            <p><?php echo getSetting('copyright', '&copy; 2026 ' . SITE_NAME . ' 版权所有'); ?></p>
        </div>
    </footer>
</body>
</html>