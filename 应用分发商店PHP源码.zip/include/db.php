<?php
require_once 'config.php';

class Database {
    private static $instance = null;
    private $conn;

    private function __construct() {
        try {
            // 首先尝试连接数据库（不指定数据库名）
            $this->conn = $this->connectWithoutDatabase();
            
            // 创建数据库（如果不存在）
            $this->createDatabase();
            
            // 重新连接到具体数据库
            $this->conn = $this->connectWithDatabase();
            
            // 创建表结构
            $this->createTables();
            
        } catch (PDOException $e) {
            die("数据库连接失败: " . $e->getMessage());
        }
    }

    // 连接MySQL服务器（不指定数据库）
    private function connectWithoutDatabase() {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
            return $pdo;
        } catch (PDOException $e) {
            throw new Exception("无法连接到MySQL服务器，请检查配置: " . $e->getMessage());
        }
    }

    // 连接到具体数据库
    private function connectWithDatabase() {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
            return $pdo;
        } catch (PDOException $e) {
            throw new Exception("无法连接到数据库 '" . DB_NAME . "': " . $e->getMessage());
        }
    }

    // 创建数据库
    private function createDatabase() {
        try {
            $sql = "CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
            $this->conn->exec($sql);
        } catch (PDOException $e) {
            throw new Exception("创建数据库失败: " . $e->getMessage());
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->conn;
    }

    private function createTables() {
        // 创建分类表
        $this->conn->exec("CREATE TABLE IF NOT EXISTS categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(50) NOT NULL,
            icon VARCHAR(255) DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 创建应用表
        $this->conn->exec("CREATE TABLE IF NOT EXISTS apps (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            description TEXT NOT NULL,
            category_id INT NOT NULL,
            icon VARCHAR(255) NOT NULL,
            banner VARCHAR(255) DEFAULT NULL,
            download_url VARCHAR(255) NOT NULL,
            version VARCHAR(20) NOT NULL,
            size VARCHAR(20) NOT NULL,
            rating FLOAT DEFAULT 0,
            download_count INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 创建用户表
        $this->conn->exec("CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            avatar VARCHAR(255) DEFAULT NULL,
            is_admin TINYINT(1) DEFAULT 0,
            can_publish TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 创建评论表
        $this->conn->exec("CREATE TABLE IF NOT EXISTS reviews (
            id INT AUTO_INCREMENT PRIMARY KEY,
            app_id INT NOT NULL,
            user_id INT NOT NULL,
            content TEXT NOT NULL,
            rating INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (app_id) REFERENCES apps(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 创建下载记录表
        $this->conn->exec("CREATE TABLE IF NOT EXISTS downloads (
            id INT AUTO_INCREMENT PRIMARY KEY,
            app_id INT NOT NULL,
            user_id INT DEFAULT NULL,
            ip_address VARCHAR(50) NOT NULL,
            download_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (app_id) REFERENCES apps(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 创建设置表
        $this->conn->exec("CREATE TABLE IF NOT EXISTS settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(50) NOT NULL UNIQUE,
            value TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 创建轮播图表
        $this->conn->exec("CREATE TABLE IF NOT EXISTS carousel (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(100) NOT NULL,
            description VARCHAR(255) NOT NULL,
            image VARCHAR(255) NOT NULL,
            link VARCHAR(255) DEFAULT NULL,
            order_num INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 创建反馈表
        $this->conn->exec("CREATE TABLE IF NOT EXISTS feedback (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT DEFAULT NULL,
            username VARCHAR(50) NOT NULL,
            email VARCHAR(100) NOT NULL,
            type VARCHAR(20) NOT NULL DEFAULT 'other',
            title VARCHAR(100) NOT NULL,
            content TEXT NOT NULL,
            status TINYINT(1) DEFAULT 0 COMMENT '0=未处理, 1=已处理',
            reply TEXT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 插入默认分类数据
        $this->insertDefaultCategories();
        
        // 创建默认管理员用户
        $this->insertDefaultAdmin();
        
        // 插入默认设置数据
        $this->insertDefaultSettings();
        
        // 插入默认轮播图数据
        $this->insertDefaultCarousel();
    }

    // 插入默认分类
    private function insertDefaultCategories() {
        try {
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM categories");
            $stmt->execute();
            if ($stmt->fetchColumn() == 0) {
                $categories = [
                    ['name' => '游戏', 'icon' => 'game.png'],
                    ['name' => '工具', 'icon' => 'tool.png'],
                    ['name' => '社交', 'icon' => 'social.png'],
                    ['name' => '娱乐', 'icon' => 'entertainment.png'],
                    ['name' => '教育', 'icon' => 'education.png'],
                    ['name' => '生活', 'icon' => 'life.png'],
                    ['name' => '健康', 'icon' => 'health.png'],
                    ['name' => '新闻', 'icon' => 'news.png']
                ];
                $stmt = $this->conn->prepare("INSERT INTO categories (name, icon) VALUES (?, ?)");
                foreach ($categories as $category) {
                    $stmt->execute([$category['name'], $category['icon']]);
                }
            }
        } catch (PDOException $e) {
            error_log("插入默认分类失败: " . $e->getMessage());
        }
    }

    // 插入默认管理员
    private function insertDefaultAdmin() {
        try {
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM users WHERE is_admin = 1");
            $stmt->execute();
            if ($stmt->fetchColumn() == 0) {
                $password = password_hash('admin123', PASSWORD_DEFAULT);
                $stmt = $this->conn->prepare("INSERT INTO users (username, password, email, is_admin) VALUES (?, ?, ?, ?)");
                $stmt->execute(['admin', $password, '18376015153@qq.com', 1]);
            }
        } catch (PDOException $e) {
            error_log("创建默认管理员失败: " . $e->getMessage());
        }
    }

    // 插入默认设置
    private function insertDefaultSettings() {
        try {
            $defaultSettings = [
                ['name' => 'copyright', 'value' => '&copy; 2026 ' . SITE_NAME . ' 版权所有'],
                ['name' => 'site_name', 'value' => SITE_NAME],
                ['name' => 'site_url', 'value' => SITE_URL],
                ['name' => 'admin_email', 'value' => ADMIN_EMAIL],
                ['name' => 'client_download_url', 'value' => '']
            ];

            foreach ($defaultSettings as $setting) {
                $stmt = $this->conn->prepare("SELECT COUNT(*) FROM settings WHERE name = ?");
                $stmt->execute([$setting['name']]);
                if ($stmt->fetchColumn() == 0) {
                    $stmt = $this->conn->prepare("INSERT INTO settings (name, value) VALUES (?, ?)");
                    $stmt->execute([$setting['name'], $setting['value']]);
                }
            }
        } catch (PDOException $e) {
            error_log("插入默认设置失败: " . $e->getMessage());
        }
    }

    // 插入默认轮播图
    private function insertDefaultCarousel() {
        try {
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM carousel");
            $stmt->execute();
            if ($stmt->fetchColumn() == 0) {
                $defaultCarousel = [
                    [
                        'title' => '热门动漫游戏推荐',
                        'description' => '探索最新最热门的动漫主题游戏',
                        'image' => 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=anime%20style%20app%20store%20banner%20colorful%20cute%20characters&image_size=landscape_16_9',
                        'link' => '',
                        'order_num' => 1
                    ],
                    [
                        'title' => '实用工具合集',
                        'description' => '提升生活品质的必备工具',
                        'image' => 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=anime%20style%20tools%20app%20banner%20colorful%20cute&image_size=landscape_16_9',
                        'link' => '',
                        'order_num' => 2
                    ],
                    [
                        'title' => '社交娱乐平台',
                        'description' => '连接同好，分享精彩',
                        'image' => 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=anime%20style%20social%20app%20banner%20colorful%20cute&image_size=landscape_16_9',
                        'link' => '',
                        'order_num' => 3
                    ]
                ];

                $stmt = $this->conn->prepare("INSERT INTO carousel (title, description, image, link, order_num) VALUES (?, ?, ?, ?, ?)");
                foreach ($defaultCarousel as $item) {
                    $stmt->execute([$item['title'], $item['description'], $item['image'], $item['link'], $item['order_num']]);
                }
            }
        } catch (PDOException $e) {
            error_log("插入默认轮播图失败: " . $e->getMessage());
        }
    }
}

// 初始化数据库连接
Database::getInstance();
?>