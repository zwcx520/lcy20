<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', '资源');
define('DB_USER', 'root');
define('DB_PASS', 'lcy');

// 网站配置
define('SITE_NAME', '动漫应用商店');
define('SITE_URL', 'http://localhost:8080');
define('UPLOAD_PATH', 'include/assets/uploads');
define('MAX_UPLOAD_SIZE', 10485760); // 10MB

// 其他配置
define('DEFAULT_PAGE_SIZE', 20);
define('ADMIN_EMAIL', 'admin@example.com');
?>