<?php
require_once 'db.php';

// 获取数据库连接
function getDB() {
    return Database::getInstance()->getConnection();
}

// 用户登录
function login($username, $password) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['is_admin'] = $user['is_admin'];
        return true;
    }
    return false;
}

// 用户注册
function register($username, $password, $email, $avatar = '') {
    $db = getDB();
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    try {
        $stmt = $db->prepare("INSERT INTO users (username, password, email, avatar) VALUES (?, ?, ?, ?)");
        $stmt->execute([$username, $hashedPassword, $email, $avatar]);
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

// 检查用户是否登录
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// 检查用户是否为管理员
function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
}

// 获取当前用户信息
function getCurrentUser() {
    if (!isLoggedIn()) return null;
    
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

// 获取应用列表
function getApps($category_id = null, $limit = 20, $offset = 0) {
    $db = getDB();
    $query = "SELECT apps.*, categories.name as category_name FROM apps 
              LEFT JOIN categories ON apps.category_id = categories.id";
    
    if ($category_id) {
        $query .= " WHERE apps.category_id = ?";
    }
    
    $query .= " ORDER BY apps.created_at DESC LIMIT ? OFFSET ?";
    
    $stmt = $db->prepare($query);
    
    if ($category_id) {
        $stmt->execute([$category_id, $limit, $offset]);
    } else {
        $stmt->execute([$limit, $offset]);
    }
    
    return $stmt->fetchAll();
}

// 获取热门应用
function getHotApps($limit = 10) {
    $db = getDB();
    $stmt = $db->prepare("SELECT apps.*, categories.name as category_name FROM apps 
                          LEFT JOIN categories ON apps.category_id = categories.id 
                          ORDER BY apps.download_count DESC LIMIT ?");
    $stmt->execute([$limit]);
    return $stmt->fetchAll();
}

// 获取推荐应用
function getRecommendedApps($limit = 10) {
    $db = getDB();
    $stmt = $db->prepare("SELECT apps.*, categories.name as category_name FROM apps 
                          LEFT JOIN categories ON apps.category_id = categories.id 
                          ORDER BY apps.rating DESC, apps.download_count DESC LIMIT ?");
    $stmt->execute([$limit]);
    return $stmt->fetchAll();
}

// 获取应用详情
function getAppById($id) {
    $db = getDB();
    $stmt = $db->prepare("SELECT apps.*, categories.name as category_name FROM apps 
                          LEFT JOIN categories ON apps.category_id = categories.id 
                          WHERE apps.id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

// 搜索应用
function searchApps($keyword, $limit = 20, $offset = 0) {
    $db = getDB();
    $stmt = $db->prepare("SELECT apps.*, categories.name as category_name FROM apps 
                          LEFT JOIN categories ON apps.category_id = categories.id 
                          WHERE apps.name LIKE ? OR apps.description LIKE ? 
                          ORDER BY apps.created_at DESC LIMIT ? OFFSET ?");
    $stmt->execute(["%$keyword%", "%$keyword%", $limit, $offset]);
    return $stmt->fetchAll();
}

// 获取分类列表
function getCategories() {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM categories ORDER BY id ASC");
    $stmt->execute();
    return $stmt->fetchAll();
}

// 增加应用下载次数
function incrementDownloadCount($app_id) {
    $db = getDB();
    $stmt = $db->prepare("UPDATE apps SET download_count = download_count + 1 WHERE id = ?");
    $stmt->execute([$app_id]);
    
    // 记录下载信息
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    
    // 如果用户未登录，不记录 user_id（避免外键约束错误）
    if ($user_id === null) {
        $stmt = $db->prepare("INSERT INTO downloads (app_id, ip_address) VALUES (?, ?)");
        $stmt->execute([$app_id, $ip_address]);
    } else {
        $stmt = $db->prepare("INSERT INTO downloads (app_id, user_id, ip_address) VALUES (?, ?, ?)");
        $stmt->execute([$app_id, $user_id, $ip_address]);
    }
}

// 添加评论
function addReview($app_id, $user_id, $content, $rating) {
    $db = getDB();
    
    // 检查用户是否已经评论过
    $stmt = $db->prepare("SELECT * FROM reviews WHERE app_id = ? AND user_id = ?");
    $stmt->execute([$app_id, $user_id]);
    if ($stmt->fetch()) {
        return false; // 已经评论过
    }
    
    // 添加评论
    $stmt = $db->prepare("INSERT INTO reviews (app_id, user_id, content, rating) VALUES (?, ?, ?, ?)");
    $stmt->execute([$app_id, $user_id, $content, $rating]);
    
    // 更新应用评分
    $stmt = $db->prepare("SELECT AVG(rating) as avg_rating FROM reviews WHERE app_id = ?");
    $stmt->execute([$app_id]);
    $result = $stmt->fetch();
    $avg_rating = $result['avg_rating'];
    
    $stmt = $db->prepare("UPDATE apps SET rating = ? WHERE id = ?");
    $stmt->execute([$avg_rating, $app_id]);
    
    return true;
}

// 获取应用评论
function getAppReviews($app_id, $limit = 10, $offset = 0) {
    $db = getDB();
    $stmt = $db->prepare("SELECT reviews.*, users.username, users.avatar FROM reviews 
                          LEFT JOIN users ON reviews.user_id = users.id 
                          WHERE reviews.app_id = ? 
                          ORDER BY reviews.created_at DESC LIMIT ? OFFSET ?");
    $stmt->execute([$app_id, $limit, $offset]);
    return $stmt->fetchAll();
}

// 上传文件
function uploadFile($file, $targetDir) {
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($fileExtension, $allowedTypes)) {
        return false;
    }
    
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        return false;
    }
    
    $fileName = uniqid() . '.' . $fileExtension;
    $targetPath = $targetDir . '/' . $fileName;
    
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return $fileName;
    }
    
    return false;
}

// 生成随机字符串
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

// 格式化时间
function formatDate($date) {
    return date('Y-m-d H:i:s', strtotime($date));
}

// 计算文件大小
function formatFileSize($size) {
    if ($size >= 1073741824) {
        $size = number_format($size / 1073741824, 2) . ' GB';
    } elseif ($size >= 1048576) {
        $size = number_format($size / 1048576, 2) . ' MB';
    } elseif ($size >= 1024) {
        $size = number_format($size / 1024, 2) . ' KB';
    } else {
        $size = $size . ' B';
    }
    return $size;
}

// 获取设置
function getSetting($name, $default = '') {
    $db = getDB();
    $stmt = $db->prepare("SELECT value FROM settings WHERE name = ?");
    $stmt->execute([$name]);
    $result = $stmt->fetch();
    return $result ? $result['value'] : $default;
}

// 更新设置
function updateSetting($name, $value) {
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO settings (name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = ?");
    return $stmt->execute([$name, $value, $value]);
}

// 获取所有设置
function getAllSettings() {
    $db = getDB();
    $stmt = $db->prepare("SELECT name, value FROM settings");
    $stmt->execute();
    $settings = [];
    while ($row = $stmt->fetch()) {
        $settings[$row['name']] = $row['value'];
    }
    return $settings;
}
?>