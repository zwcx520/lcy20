<?php
session_start();
require_once 'include/functions.php';

// 获取分类列表
$categories = getCategories();

// 获取推荐应用
$recommendedApps = getRecommendedApps(6);

// 获取热门应用
$hotApps = getHotApps(6);

// 获取最新应用
$latestApps = getApps(null, 6);

// 获取轮播图数据
$db = getDB();
$stmt = $db->prepare("SELECT * FROM carousel WHERE is_active = 1 ORDER BY order_num ASC");
$stmt->execute();
$carousels = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getSetting('site_name', SITE_NAME); ?> - 动漫应用商店</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff6b9d;
            --secondary-color: #4ecdc4;
            --accent-color: #45b7d1;
            --light-color: #f7f7f7;
            --dark-color: #333;
            --text-color: #555;
            --border-radius: 12px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* 导航栏 */
        header {
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            color: white;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
        }

        .logo {
            font-size: 20px;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .logo i {
            font-size: 24px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .search-box {
            flex: 1;
            max-width: 400px;
            margin: 0 20px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 8px 12px;
            border: none;
            border-radius: 30px;
            font-size: 14px;
            outline: none;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .search-box button {
            position: absolute;
            right: 5px;
            top: 50%;
            transform: translateY(-50%);
            background: var(--secondary-color);
            border: none;
            border-radius: 50%;
            width: 26px;
            height: 26px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .search-box button:hover {
            background: var(--accent-color);
            transform: translateY(-50%) scale(1.1);
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-menu a {
            color: white;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .user-menu a:hover {
            transform: translateY(-2px);
        }

        /* 移动端菜单按钮 */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            padding: 5px;
        }

        .mobile-menu-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border-radius: 8px;
            box-shadow: var(--box-shadow);
            min-width: 150px;
            z-index: 1001;
            margin-top: 5px;
        }

        .mobile-menu-dropdown a {
            display: block;
            padding: 10px 15px;
            color: var(--dark-color);
            text-decoration: none;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .mobile-menu-dropdown a:hover {
            background-color: var(--light-color);
        }

        .mobile-menu-dropdown.show {
            display: block;
        }

        /* 轮播图 */
        .carousel {
            position: relative;
            margin: 20px 0;
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--box-shadow);
        }

        .carousel-inner {
            display: flex;
            transition: transform 0.5s ease;
        }

        .carousel-item {
            min-width: 100%;
            height: 300px;
            background: linear-gradient(135deg, #ff9a9e, #fecfef);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .carousel-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .carousel-caption {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(to top, rgba(0,0,0,0.8), rgba(0,0,0,0));
            color: white;
            padding: 30px;
        }

        .carousel-caption h3 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .carousel-caption p {
            font-size: 14px;
            opacity: 0.9;
        }



        /* 分类导航 */
        .category-section {
            margin: 30px 0;
        }

        .section-title {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 20px;
            color: var(--dark-color);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title i {
            color: var(--primary-color);
        }

        .category-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 20px;
        }

        .category-item {
            background: white;
            border-radius: var(--border-radius);
            padding: 20px;
            text-align: center;
            box-shadow: var(--box-shadow);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .category-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }

        .category-item .icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            font-size: 24px;
            color: white;
        }

        .category-item h3 {
            font-size: 14px;
            font-weight: 500;
            color: var(--dark-color);
        }

        /* 应用列表 */
        .app-section {
            margin: 30px 0;
        }

        .app-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .app-card {
            background: white;
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--box-shadow);
            transition: all 0.3s ease;
        }

        .app-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }

        .app-card .app-icon {
            width: 80px;
            height: 80px;
            margin: 20px auto 10px;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .app-card .app-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .app-card .app-info {
            padding: 15px;
            text-align: center;
        }

        .app-card .app-name {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 5px;
            color: var(--dark-color);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .app-card .app-category {
            font-size: 12px;
            color: var(--text-color);
            margin-bottom: 10px;
        }

        .app-card .app-rating {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            margin-bottom: 10px;
        }

        .app-card .app-rating i {
            color: #ffd700;
            font-size: 12px;
        }

        .app-card .app-rating span {
            font-size: 12px;
            color: var(--text-color);
        }

        .app-card .app-downloads {
            font-size: 12px;
            color: var(--text-color);
            margin-bottom: 15px;
        }

        .app-card .app-buttons {
            display: flex;
            gap: 10px;
        }

        .app-card .btn {
            flex: 1;
            padding: 8px 12px;
            border: none;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: #ff528b;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: var(--light-color);
            color: var(--dark-color);
            border: 1px solid #ddd;
        }

        .btn-secondary:hover {
            background: #e8e8e8;
            transform: translateY(-2px);
        }

        /* 页脚 */
        footer {
            background: var(--dark-color);
            color: white;
            padding: 40px 0;
            margin-top: 50px;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
        }

        .footer-section h3 {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 20px;
            color: var(--primary-color);
        }

        .footer-section ul {
            list-style: none;
        }

        .footer-section ul li {
            margin-bottom: 10px;
        }

        .footer-section ul li a {
            color: #ddd;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-section ul li a:hover {
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            margin-top: 30px;
            border-top: 1px solid #555;
            font-size: 14px;
            color: #999;
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
            .nav-container {
                flex-direction: row;
                gap: 10px;
                padding: 8px 15px;
            }

            .logo {
                font-size: 16px;
            }

            .logo i {
                font-size: 20px;
            }

            .search-box {
                flex: 1;
                max-width: none;
                margin: 0 10px;
            }

            .search-box input {
                padding: 6px 10px;
                font-size: 12px;
            }

            .search-box button {
                width: 24px;
                height: 24px;
                font-size: 12px;
            }

            .user-menu {
                display: none;
            }

            .mobile-menu-btn {
                display: block;
            }

            .carousel-item {
                height: 200px;
            }

            .app-grid {
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            }

            .category-grid {
                grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
            }
        }

        /* 动画效果 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }

        /* 加载动画 */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <header>
        <div class="container nav-container">
            <div class="logo">
                <i class="fas fa-gamepad"></i>
                <span><?php echo getSetting('site_name', SITE_NAME); ?></span>
            </div>
            <div class="search-box">
                <form action="search/index.php" method="get">
                    <input type="text" name="keyword" placeholder="搜索应用...">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>
            <div class="user-menu">
                <?php if (isLoggedIn()): ?>
                    <a href="user/index.php"><i class="fas fa-user"></i> <?php echo $_SESSION['username']; ?></a>
                    <a href="user/logout.php"><i class="fas fa-sign-out-alt"></i> 退出</a>
                <?php else: ?>
                    <a href="user/login.php"><i class="fas fa-sign-in-alt"></i> 登录</a>
                    <a href="user/register.php"><i class="fas fa-user-plus"></i> 注册</a>
                <?php endif; ?>
                <?php if (isAdmin()): ?>
                    <a href="admin/index.php"><i class="fas fa-cog"></i> 管理</a>
                <?php endif; ?>
            </div>
            <!-- 移动端菜单按钮 -->
            <button class="mobile-menu-btn" onclick="toggleMobileMenu()">
                <i class="fas fa-bars"></i>
            </button>
            <!-- 移动端下拉菜单 -->
            <div class="mobile-menu-dropdown">
                <?php if (isLoggedIn()): ?>
                    <a href="user/index.php"><i class="fas fa-user"></i> <?php echo $_SESSION['username']; ?></a>
                    <a href="user/logout.php"><i class="fas fa-sign-out-alt"></i> 退出</a>
                <?php else: ?>
                    <a href="user/login.php"><i class="fas fa-sign-in-alt"></i> 登录</a>
                    <a href="user/register.php"><i class="fas fa-user-plus"></i> 注册</a>
                <?php endif; ?>
                <?php if (isAdmin()): ?>
                    <a href="admin/index.php"><i class="fas fa-cog"></i> 管理</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <div class="container">
        <!-- 轮播图 -->
        <div class="carousel" id="carousel">
            <div class="carousel-inner" id="carouselInner">
                <?php foreach ($carousels as $carousel): ?>
                    <div class="carousel-item">
                        <img src="<?php echo $carousel['image']; ?>" alt="<?php echo $carousel['title']; ?>">
                        <div class="carousel-caption">
                            <h3><?php echo $carousel['title']; ?></h3>
                            <p><?php echo $carousel['description']; ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
                <!-- 默认轮播图（当数据库中没有轮播图时显示） -->
                <?php if (empty($carousels)): ?>
                    <div class="carousel-item">
                        <img src="https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=anime%20style%20app%20store%20banner%20colorful%20cute%20characters&image_size=landscape_16_9" alt="推荐应用">
                        <div class="carousel-caption">
                            <h3>热门动漫游戏推荐</h3>
                            <p>探索最新最热门的动漫主题游戏</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=anime%20style%20tools%20app%20banner%20colorful%20cute&image_size=landscape_16_9" alt="实用工具">
                        <div class="carousel-caption">
                            <h3>实用工具合集</h3>
                            <p>提升生活品质的必备工具</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=anime%20style%20social%20app%20banner%20colorful%20cute&image_size=landscape_16_9" alt="社交应用">
                        <div class="carousel-caption">
                            <h3>社交娱乐平台</h3>
                            <p>连接同好，分享精彩</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- 分类导航 -->
        <div class="category-section">
            <h2 class="section-title"><i class="fas fa-th-large"></i> 应用分类</h2>
            <div class="category-grid">
                <?php foreach ($categories as $category): ?>
                    <a href="category/index.php?id=<?php echo $category['id']; ?>" class="category-item">
                        <div class="icon">
                            <?php 
                                switch ($category['name']) {
                                    case '游戏': echo '<i class="fas fa-gamepad"></i>'; break;
                                    case '工具': echo '<i class="fas fa-tools"></i>'; break;
                                    case '社交': echo '<i class="fas fa-users"></i>'; break;
                                    case '娱乐': echo '<i class="fas fa-film"></i>'; break;
                                    case '教育': echo '<i class="fas fa-graduation-cap"></i>'; break;
                                    case '生活': echo '<i class="fas fa-home"></i>'; break;
                                    case '健康': echo '<i class="fas fa-heartbeat"></i>'; break;
                                    case '新闻': echo '<i class="fas fa-newspaper"></i>'; break;
                                    default: echo '<i class="fas fa-apps"></i>';
                                }
                            ?>
                        </div>
                        <h3><?php echo $category['name']; ?></h3>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- 推荐应用 -->
        <div class="app-section">
            <h2 class="section-title"><i class="fas fa-star"></i> 推荐应用</h2>
            <div class="app-grid">
                <?php foreach ($recommendedApps as $app): ?>
                    <div class="app-card fade-in">
                        <div class="app-icon">
                            <?php if (!empty($app['icon'])): ?>
                                <img src="<?php echo $app['icon']; ?>" alt="<?php echo $app['name']; ?>">
                            <?php else: ?>
                                <img src="assets/images/default-app-icon.png" alt="<?php echo $app['name']; ?>">
                            <?php endif; ?>
                        </div>
                        <div class="app-info">
                            <h3 class="app-name"><?php echo $app['name']; ?></h3>
                            <p class="app-category"><?php echo $app['category_name']; ?></p>
                            <div class="app-rating">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star<?php echo $i <= $app['rating'] ? '' : '-empty'; ?>"></i>
                                <?php endfor; ?>
                                <span><?php echo number_format($app['rating'], 1); ?></span>
                            </div>
                            <p class="app-downloads">下载: <?php echo number_format($app['download_count']); ?>次</p>
                            <div class="app-buttons">
                                <a href="app/index.php?id=<?php echo $app['id']; ?>" class="btn btn-primary">详情</a>
                                <button onclick="downloadApp(<?php echo $app['id']; ?>, this)" class="btn btn-secondary">下载</button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- 热门应用 -->
        <div class="app-section">
            <h2 class="section-title"><i class="fas fa-fire"></i> 热门应用</h2>
            <div class="app-grid">
                <?php foreach ($hotApps as $app): ?>
                    <div class="app-card fade-in">
                        <div class="app-icon">
                            <?php if (!empty($app['icon'])): ?>
                                <img src="<?php echo $app['icon']; ?>" alt="<?php echo $app['name']; ?>">
                            <?php else: ?>
                                <img src="assets/images/default-app-icon.png" alt="<?php echo $app['name']; ?>">
                            <?php endif; ?>
                        </div>
                        <div class="app-info">
                            <h3 class="app-name"><?php echo $app['name']; ?></h3>
                            <p class="app-category"><?php echo $app['category_name']; ?></p>
                            <div class="app-rating">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star<?php echo $i <= $app['rating'] ? '' : '-empty'; ?>"></i>
                                <?php endfor; ?>
                                <span><?php echo number_format($app['rating'], 1); ?></span>
                            </div>
                            <p class="app-downloads">下载: <?php echo number_format($app['download_count']); ?>次</p>
                            <div class="app-buttons">
                                <a href="app/index.php?id=<?php echo $app['id']; ?>" class="btn btn-primary">详情</a>
                                <button onclick="downloadApp(<?php echo $app['id']; ?>, this)" class="btn btn-secondary">下载</button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- 最新应用 -->
        <div class="app-section">
            <h2 class="section-title"><i class="fas fa-clock"></i> 最新应用</h2>
            <div class="app-grid">
                <?php foreach ($latestApps as $app): ?>
                    <div class="app-card fade-in">
                        <div class="app-icon">
                            <?php if (!empty($app['icon'])): ?>
                                <img src="<?php echo $app['icon']; ?>" alt="<?php echo $app['name']; ?>">
                            <?php else: ?>
                                <img src="assets/images/default-app-icon.png" alt="<?php echo $app['name']; ?>">
                            <?php endif; ?>
                        </div>
                        <div class="app-info">
                            <h3 class="app-name"><?php echo $app['name']; ?></h3>
                            <p class="app-category"><?php echo $app['category_name']; ?></p>
                            <div class="app-rating">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star<?php echo $i <= $app['rating'] ? '' : '-empty'; ?>"></i>
                                <?php endfor; ?>
                                <span><?php echo number_format($app['rating'], 1); ?></span>
                            </div>
                            <p class="app-downloads">下载: <?php echo number_format($app['download_count']); ?>次</p>
                            <div class="app-buttons">
                                <a href="app/index.php?id=<?php echo $app['id']; ?>" class="btn btn-primary">详情</a>
                                <button onclick="downloadApp(<?php echo $app['id']; ?>, this)" class="btn btn-secondary">下载</button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- 页脚 -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>关于我们</h3>
                    <ul>
                        <li><a href="#">公司简介</a></li>
                        <li><a href="#">联系我们</a></li>
                        <li><a href="#">加入我们</a></li>
                        <li><a href="#">隐私政策</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>帮助中心</h3>
                    <ul>
                        <li><a href="#">常见问题</a></li>
                        <li><a href="#">下载指南</a></li>
                        <li><a href="#">应用提交</a></li>
                        <li><a href="#">开发者中心</a></li>
                        <li><a href="feedback/index.php"><i class="fas fa-comment-dots"></i> 意见反馈</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>关注我们</h3>
                    <ul>
                        <li><a href="#"><i class="fab fa-weibo"></i> 微博</a></li>
                        <li><a href="#"><i class="fab fa-wechat"></i> 微信</a></li>
                        <li><a href="#"><i class="fab fa-qq"></i> QQ</a></li>
                        <li><a href="#"><i class="fab fa-github"></i> GitHub</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>下载客户端</h3>
                    <p>扫描二维码下载客户端</p>
                    <?php
                        $clientDownloadUrl = getSetting('client_download_url', '');
                        if (!empty($clientDownloadUrl)) {
                            // 使用Google Charts API生成二维码
                            $encodedUrl = urlencode($clientDownloadUrl);
                            $qrcodeUrl = "https://api.qrserver.com/v1/create-qr-code/?size=120x120&data={$encodedUrl}";
                            echo '<img src="' . $qrcodeUrl . '" alt="客户端下载二维码" style="width: 120px; height: 120px; margin-top: 10px;">';
                        } else {
                            echo '<div style="width: 120px; height: 120px; background: white; margin-top: 10px; display: flex; align-items: center; justify-content: center; color: #999; font-size: 12px;">请在后台设置下载URL</div>';
                        }
                    ?>
                </div>
            </div>
            <div class="footer-bottom">
                <p><?php echo getSetting('copyright', '&copy; 2026 ' . SITE_NAME . ' 版权所有'); ?></p>
            </div>
        </div>
    </footer>

    <script>
        // 轮播图功能 - 左右滑动循环轮播
        let currentSlide = 0;
        const carousel = document.getElementById('carousel');
        const carouselInner = document.getElementById('carouselInner');
        const slides = document.querySelectorAll('.carousel-item');
        const totalSlides = slides.length;
        let autoPlayInterval;
        let touchStartX = 0;
        let touchEndX = 0;

        function showSlide(index) {
            if (index < 0) {
                currentSlide = totalSlides - 1;
            } else if (index >= totalSlides) {
                currentSlide = 0;
            } else {
                currentSlide = index;
            }
            carouselInner.style.transform = `translateX(-${currentSlide * 100}%)`;
        }

        function nextSlide() {
            showSlide(currentSlide + 1);
        }

        function prevSlide() {
            showSlide(currentSlide - 1);
        }

        // 自动轮播
        function startAutoPlay() {
            autoPlayInterval = setInterval(nextSlide, 5000);
        }

        function stopAutoPlay() {
            clearInterval(autoPlayInterval);
        }

        startAutoPlay();

        // 触摸滑动支持
        carousel.addEventListener('touchstart', function(e) {
            touchStartX = e.changedTouches[0].screenX;
            stopAutoPlay();
        }, {passive: true});

        carousel.addEventListener('touchend', function(e) {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
            startAutoPlay();
        }, {passive: true});

        function handleSwipe() {
            const swipeThreshold = 50;
            const diff = touchStartX - touchEndX;
            
            if (Math.abs(diff) > swipeThreshold) {
                if (diff > 0) {
                    // 向左滑动，显示下一张
                    nextSlide();
                } else {
                    // 向右滑动，显示上一张
                    prevSlide();
                }
            }
        }

        // 鼠标拖拽支持
        let isDragging = false;
        let startX = 0;
        let currentX = 0;

        carousel.addEventListener('mousedown', function(e) {
            isDragging = true;
            startX = e.pageX;
            stopAutoPlay();
            carousel.style.cursor = 'grabbing';
        });

        carousel.addEventListener('mousemove', function(e) {
            if (!isDragging) return;
            e.preventDefault();
            currentX = e.pageX;
        });

        carousel.addEventListener('mouseup', function(e) {
            if (!isDragging) return;
            isDragging = false;
            carousel.style.cursor = 'grab';
            
            const diff = startX - currentX;
            const swipeThreshold = 50;
            
            if (Math.abs(diff) > swipeThreshold) {
                if (diff > 0) {
                    nextSlide();
                } else {
                    prevSlide();
                }
            }
            startAutoPlay();
        });

        carousel.addEventListener('mouseleave', function() {
            if (isDragging) {
                isDragging = false;
                carousel.style.cursor = 'grab';
                startAutoPlay();
            }
        });

        // 设置鼠标样式
        carousel.style.cursor = 'grab';

        // JS下载应用
        function downloadApp(appId, btn) {
            // 显示下载中提示
            const originalText = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            btn.disabled = true;

            // 调用API获取下载链接
            fetch('api/get_download_url.php?id=' + appId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // 创建下载链接
                        const downloadUrl = data.download_url;
                        const link = document.createElement('a');
                        link.href = downloadUrl;
                        link.download = data.file_name;
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);

                        // 恢复按钮状态
                        btn.innerHTML = '<i class="fas fa-check"></i>';
                        setTimeout(() => {
                            btn.innerHTML = originalText;
                            btn.disabled = false;
                        }, 2000);
                    } else {
                        alert(data.message || '下载失败');
                        btn.innerHTML = originalText;
                        btn.disabled = false;
                    }
                })
                .catch(error => {
                    console.error('下载错误:', error);
                    alert('下载失败，请稍后重试');
                    btn.innerHTML = originalText;
                    btn.disabled = false;
                });
        }

        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const fadeElements = document.querySelectorAll('.fade-in');
            fadeElements.forEach((element, index) => {
                element.style.animationDelay = `${index * 0.1}s`;
            });
        });

        // 移动端菜单切换
        function toggleMobileMenu() {
            const dropdown = document.querySelector('.mobile-menu-dropdown');
            dropdown.classList.toggle('show');
        }

        // 点击页面其他地方关闭菜单
        document.addEventListener('click', function(event) {
            const menuBtn = document.querySelector('.mobile-menu-btn');
            const dropdown = document.querySelector('.mobile-menu-dropdown');
            if (!menuBtn.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });
    </script>
</body>
</html>