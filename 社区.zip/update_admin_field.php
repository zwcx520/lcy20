<?php
// 加载配置和数据库连接
require_once 'config.php';
require_once 'database.php';

// 检查 users 表是否存在 is_admin 字段
try {
    $stmt = db()->query("SHOW COLUMNS FROM users LIKE 'is_admin'");
    $column_exists = $stmt->rowCount() > 0;
    
    if (!$column_exists) {
        // 添加 is_admin 字段
        db()->query("ALTER TABLE users ADD COLUMN is_admin TINYINT(1) DEFAULT 0");
        echo "添加 is_admin 字段成功<br>";
    }
    
    // 将 admin 用户设置为管理员
    db()->query("UPDATE users SET is_admin = 1 WHERE username = 'admin'");
    echo "设置 admin 用户为管理员成功<br>";
    
    echo "<div style='padding: 20px; margin: 20px; background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; border-radius: 4px;'>";
    echo "管理员字段更新成功！<br>";
    echo "现在管理员可以管理所有用户的帖子了。<br>";
    echo "<a href='index.php' style='color: #155724; text-decoration: underline;'>返回首页</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='padding: 20px; margin: 20px; background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: 4px;'>";
    echo "错误: " . $e->getMessage() . "<br>";
    echo "<a href='index.php' style='color: #721c24; text-decoration: underline;'>返回首页</a>";
    echo "</div>";
}
?>