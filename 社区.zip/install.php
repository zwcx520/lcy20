<?php
session_start();

// 检查是否已经安装
if (file_exists('config.php')) {
    // 尝试连接数据库并检查表是否存在
    try {
        require_once 'config.php';
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        
        // 检查 users 表是否存在
        $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
        if ($stmt->rowCount() > 0) {
            die('网站已经安装，请删除 install.php 文件后访问首页');
        }
        // 如果表不存在，继续安装流程
    } catch (PDOException $e) {
        // 数据库连接失败，继续安装流程
    }
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 数据库配置
    $db_host = 'localhost';
    $db_name = '社区';
    $db_user = 'root';
    $db_pass = 'lcy';
    
    // 检查PHP版本
    if (version_compare(PHP_VERSION, '8.0.0', '<')) {
        $errors[] = 'PHP版本必须大于等于8.0.0';
    }
    
    // 检查扩展
    if (!extension_loaded('pdo')) {
        $errors[] = '需要PDO扩展';
    }
    
    if (!extension_loaded('pdo_mysql')) {
        $errors[] = '需要PDO MySQL扩展';
    }
    
    if (empty($errors)) {
        try {
            // 连接数据库服务器
            $dsn = "mysql:host=$db_host;charset=utf8mb4";
            $pdo = new PDO($dsn, $db_user, $db_pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]);
            
            // 创建数据库
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            
            // 选择数据库
            $pdo->exec("USE `$db_name`");
            
            // 创建用户表
            $pdo->exec("CREATE TABLE IF NOT EXISTS `users` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `username` VARCHAR(50) NOT NULL UNIQUE,
                `email` VARCHAR(100) NOT NULL UNIQUE,
                `password` VARCHAR(255) NOT NULL,
                `avatar` VARCHAR(255) DEFAULT 'default.jpg',
                `bio` TEXT NULL,
                `is_admin` TINYINT(1) DEFAULT 0,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // 创建帖子表
            $pdo->exec("CREATE TABLE IF NOT EXISTS `posts` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT UNSIGNED NOT NULL,
                `content` TEXT NOT NULL,
                `image` VARCHAR(255) NULL,
                `likes` INT UNSIGNED DEFAULT 0,
                `comments` INT UNSIGNED DEFAULT 0,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // 创建评论表
            $pdo->exec("CREATE TABLE IF NOT EXISTS `comments` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `post_id` INT UNSIGNED NOT NULL,
                `user_id` INT UNSIGNED NOT NULL,
                `content` TEXT NOT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
                FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // 创建消息表
            $pdo->exec("CREATE TABLE IF NOT EXISTS `messages` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `sender_id` INT UNSIGNED NOT NULL,
                `receiver_id` INT UNSIGNED NOT NULL,
                `content` TEXT NOT NULL,
                `is_read` TINYINT(1) DEFAULT 0,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
                FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // 创建关注表
            $pdo->exec("CREATE TABLE IF NOT EXISTS `follows` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `follower_id` INT UNSIGNED NOT NULL,
                `following_id` INT UNSIGNED NOT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY `unique_follow` (`follower_id`, `following_id`),
                FOREIGN KEY (`follower_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
                FOREIGN KEY (`following_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // 创建管理员账号
            $admin_username = 'admin';
            $admin_email = 'admin@example.com';
            $admin_password = password_hash('admin123', PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("INSERT IGNORE INTO `users` (`username`, `email`, `password`, `is_admin`) VALUES (?, ?, ?, ?)");
            $stmt->execute([$admin_username, $admin_email, $admin_password, 1]);
            
            // 生成配置文件
            $site_url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/';
            $secret_key = bin2hex(random_bytes(32));
            $config_content = <<<EOL
<?php
// 数据库配置
define('DB_HOST', '$db_host');
define('DB_NAME', '$db_name');
define('DB_USER', '$db_user');
define('DB_PASS', '$db_pass');

// 网站配置
define('SITE_NAME', '心事社区');
define('SITE_URL', '$site_url');

// 上传配置
define('UPLOAD_DIR', 'assets/images/uploads/');
define('MAX_UPLOAD_SIZE', 10000 * 1024 * 1024); // 10000MB

// 安全配置
define('SECRET_KEY', '$secret_key');
EOL;
            
            file_put_contents('config.php', $config_content);
            
            // 创建上传目录
            if (!file_exists('assets/images/uploads')) {
                mkdir('assets/images/uploads', 0755, true);
            }
            
            // 创建默认头像
            $default_avatar = 'assets/images/default.jpg';
            if (!file_exists($default_avatar)) {
                file_put_contents($default_avatar, file_get_contents('https://via.placeholder.com/150'));
            }
            
            $success = true;
            
        } catch (PDOException $e) {
            $errors[] = '数据库连接失败: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>心事社区安装</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .install-container {
            max-width: 600px;
            width: 100%;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            padding: 30px;
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo h1 {
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="install-container">
        <div class="logo">
            <h1>心事社区安装</h1>
            <p>欢迎使用心事社区系统</p>
        </div>
        
        <?php if ($success): ?>
            <div class="alert alert-success" role="alert">
                <h4 class="alert-heading">安装成功！</h4>
                <p>数据库已创建，配置文件已生成。</p>
                <hr>
                <p class="mb-0">
                    <strong>管理员账号：</strong> admin<br>
                    <strong>管理员密码：</strong> admin123
                </p>
                <hr>
                <a href="index.php" class="btn btn-primary">进入网站</a>
            </div>
        <?php else: ?>
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger" role="alert">
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="post" action="install.php">
                <div class="mb-3">
                    <h4>安装信息</h4>
                    <p>数据库名：社区</p>
                    <p>用户名：root</p>
                    <p>密码：lcy</p>
                </div>
                <button type="submit" class="btn btn-primary w-100">开始安装</button>
            </form>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>