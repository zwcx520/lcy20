<?php
session_start();

if (file_exists('config.php')) {
    require_once 'config.php';
    require_once 'database.php';
} else {
    header('Location: install.php');
    exit;
}

$user = null;
if (isset($_SESSION['user_id'])) {
    $user = db()->fetch("SELECT * FROM users WHERE id = ?", [$_SESSION['user_id']]);
}

$keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : '';
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$date_from = isset($_GET['date_from']) ? trim($_GET['date_from']) : '';
$date_to = isset($_GET['date_to']) ? trim($_GET['date_to']) : '';
$year = isset($_GET['year']) ? intval($_GET['year']) : 0;
$month = isset($_GET['month']) ? intval($_GET['month']) : 0;
$time_filter = isset($_GET['time_filter']) ? trim($_GET['time_filter']) : '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 10;

$where_conditions = [];
$params = [];

if (!empty($keyword)) {
    $where_conditions[] = "(p.content LIKE ? OR u.username LIKE ?)";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
}

if (!empty($category)) {
    $where_conditions[] = "p.content LIKE ?";
    $params[] = "%#$category%";
}

if ($user_id > 0) {
    $where_conditions[] = "p.user_id = ?";
    $params[] = $user_id;
}

if (!empty($date_from)) {
    $where_conditions[] = "p.created_at >= ?";
    $params[] = $date_from . ' 00:00:00';
}

if (!empty($date_to)) {
    $where_conditions[] = "p.created_at <= ?";
    $params[] = $date_to . ' 23:59:59';
}

if ($year > 0) {
    $where_conditions[] = "YEAR(p.created_at) = ?";
    $params[] = $year;
}

if ($month > 0) {
    $where_conditions[] = "MONTH(p.created_at) = ?";
    $params[] = $month;
}

if (!empty($time_filter)) {
    switch ($time_filter) {
        case 'today':
            $where_conditions[] = "DATE(p.created_at) = CURDATE()";
            break;
        case 'yesterday':
            $where_conditions[] = "DATE(p.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
            break;
        case 'week':
            $where_conditions[] = "p.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
            break;
        case 'month':
            $where_conditions[] = "p.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            break;
        case 'quarter':
            $where_conditions[] = "p.created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)";
            break;
        case 'year':
            $where_conditions[] = "p.created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)";
            break;
        case 'this_year':
            $where_conditions[] = "YEAR(p.created_at) = YEAR(CURDATE())";
            break;
        case 'last_year':
            $where_conditions[] = "YEAR(p.created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 YEAR))";
            break;
    }
}

$where_sql = '';
if (!empty($where_conditions)) {
    $where_sql = 'WHERE ' . implode(' AND ', $where_conditions);
}

$count_sql = "SELECT COUNT(*) as total FROM posts p JOIN users u ON p.user_id = u.id $where_sql";
$total_result = db()->fetch($count_sql, $params);
$total_count = $total_result['total'];
$total_pages = ceil($total_count / $per_page);
$offset = ($page - 1) * $per_page;

$search_sql = "SELECT p.*, u.username, u.avatar FROM posts p JOIN users u ON p.user_id = u.id $where_sql ORDER BY p.created_at DESC LIMIT $per_page OFFSET $offset";
$posts = db()->fetchAll($search_sql, $params);

$years_sql = "SELECT DISTINCT YEAR(created_at) as year FROM posts ORDER BY year DESC";
$available_years = db()->fetchAll($years_sql);

$categories = ['技术分享', '生活感悟', '学习交流', '兴趣爱好', '职场经验'];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>心事社区 - 搜索</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-image: url(bj.jpg);
            background-size: cover;
            background-attachment: fixed;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .nav-link {
            color: #333;
        }
        .nav-link.active {
            color: #007bff;
            font-weight: bold;
        }
        .navbar-toggler {
            padding: 0.15rem 0.35rem;
            font-size: 0.75rem;
            line-height: 1;
            align-self: center;
        }
        .navbar-toggler-icon {
            width: 1em;
            height: 1em;
        }
        @media (max-width: 576px) {
            .navbar {
                height: 60px;
            }
            .navbar .container {
                height: 100%;
                display: flex;
                align-items: center;
            }
            .navbar .d-flex {
                margin-top: 10px;
                width: 100%;
            }
            .navbar .d-flex .btn {
                flex: 1;
                margin: 0 5px;
            }
            .navbar .d-flex .btn:first-child {
                margin-left: 0;
            }
            .navbar .d-flex .btn:last-child {
                margin-right: 0;
            }
            .dropdown-menu {
                position: static !important;
                float: none !important;
                width: 100% !important;
                margin-top: 0 !important;
            }
            .navbar-collapse .navbar-nav {
                display: none !important;
            }
        }
        .search-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        .filter-section {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        .filter-title {
            font-weight: bold;
            margin-bottom: 15px;
            color: #333;
        }
        .post-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            padding: 20px;
        }
        .post-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        .avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 15px;
        }
        .post-content {
            margin-bottom: 15px;
        }
        .post-image {
            max-width: 100%;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .post-actions {
            display: flex;
            justify-content: space-around;
            padding-top: 15px;
            border-top: 1px solid #e9ecef;
        }
        .action-btn {
            background: none;
            border: none;
            color: #6c757d;
            cursor: pointer;
            display: flex;
            align-items: center;
        }
        .action-btn:hover {
            color: #007bff;
        }
        .action-btn i {
            margin-right: 5px;
        }
        .category-btn {
            margin: 5px;
            border-radius: 20px;
        }
        .category-btn.active {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }
        .form-control, .form-select {
            border-radius: 8px;
        }
        .footer {
            background-color: white;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
            padding: 20px 0;
            margin-top: 40px;
        }
        .mobile-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: white;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
            z-index: 1000;
            height: 60px;
        }
        .mobile-nav .navbar-nav {
            display: flex;
            flex-direction: row;
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
        }
        .mobile-nav .nav-item {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .mobile-nav .nav-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 0;
            color: #6c757d;
            height: 100%;
            width: 100%;
        }
        .mobile-nav .nav-link.active {
            color: #007bff;
        }
        .mobile-nav .nav-link i {
            font-size: 18px;
            margin-bottom: 2px;
        }
        .mobile-nav .nav-link span {
            font-size: 12px;
        }
        @media (max-width: 767px) {
            .container {
                margin-bottom: 70px;
            }
        }
        .result-count {
            color: #6c757d;
            font-size: 14px;
        }
        .pagination {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-comments text-primary mr-2"></i>
                心事社区
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-home"></i> 首页
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="message.php">
                            <i class="fas fa-envelope"></i> 消息
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="discover.php">
                            <i class="fas fa-compass"></i> 发现
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="search.php">
                            <i class="fas fa-search"></i> 搜索
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i> 我的
                        </a>
                    </li>
                    <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">
                            <i class="fas fa-cog"></i> 管理
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                <div class="d-flex align-items-center">
                    <?php if ($user): ?>
                        <div class="dropdown">
                            <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown">
                                <img src="assets/images/<?php echo $user['avatar']; ?>" alt="头像" class="avatar" style="width: 36px; height: 36px;">
                                <span class="ms-2"><?php echo $user['username']; ?></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="profile.php">个人资料</a></li>
                                <li><a class="dropdown-item" href="edit_profile.php">编辑资料</a></li>
                                <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                                <li><a class="dropdown-item" href="admin.php?tab=about"><i class="fas fa-info-circle"></i> 编辑关于</a></li>
                                <?php else: ?>
                                <li><a class="dropdown-item" href="#">设置</a></li>
                                <?php endif; ?>
                                <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                                <li><a class="dropdown-item" href="admin.php">管理后台</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="index.php?action=logout">退出登录</a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <div class="d-flex w-100" style="gap: 10px;">
                            <a href="login.php" class="btn btn-outline-primary flex-grow-1">登录</a>
                            <a href="register.php" class="btn btn-primary flex-grow-1">注册</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <nav class="mobile-nav d-md-none navbar navbar-expand-lg">
        <ul class="navbar-nav w-100 d-flex justify-content-around">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-home"></i>
                    <span>首页</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="message.php">
                    <i class="fas fa-envelope"></i>
                    <span>消息</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="search.php">
                    <i class="fas fa-search"></i>
                    <span>搜索</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>我的</span>
                </a>
            </li>
        </ul>
    </nav>

    <div class="container py-4">
        <div class="row">
            <div class="col-lg-8">
                <div class="search-container">
                    <h4 class="mb-3"><i class="fas fa-search"></i> 搜索帖子</h4>
                    <form method="get" action="search.php">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="搜索帖子内容或用户名..." name="keyword" value="<?php echo htmlspecialchars($keyword); ?>">
                            <button class="btn btn-primary" type="submit">
                                <i class="fas fa-search"></i> 搜索
                            </button>
                        </div>

                        <div class="filter-section">
                            <h5 class="filter-title"><i class="fas fa-user"></i> 用户筛选</h5>
                            <div class="row g-3">
                                <div class="col-md-12">
                                    <div class="input-group">
                                        <span class="input-group-text">用户ID</span>
                                        <input type="number" class="form-control" placeholder="输入用户ID" name="user_id" value="<?php echo $user_id; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>

                        


                        <?php if (!empty($keyword) || !empty($category) || $user_id > 0 || !empty($date_from) || !empty($date_to) || !empty($time_filter) || $year > 0 || $month > 0): ?>
                            <div class="mt-3">
                                <a href="search.php" class="btn btn-outline-danger">
                                    <i class="fas fa-redo"></i> 重置所有筛选条件
                                </a>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>

                <div class="result-count mb-3">
                    <?php if ($total_count > 0): ?>
                        找到 <strong><?php echo $total_count; ?></strong> 条结果，当前显示 <?php echo ($offset + 1); ?>-<?php echo min($offset + $per_page, $total_count); ?> 条
                    <?php else: ?>
                        未找到任何结果
                    <?php endif; ?>
                </div>

                <?php foreach ($posts as $post): ?>
                    <div class="post-card">
                        <div class="post-header">
                            <img src="assets/images/<?php echo $post['avatar']; ?>" alt="头像" class="avatar">
                            <div>
                                <h5 class="mb-0">
                                    <?php echo $post['username']; ?>
                                    <span class="text-muted small">（ID: <?php echo $post['user_id']; ?>）</span>
                                </h5>
                                <p class="text-muted mb-0"><?php echo date('Y-m-d H:i', strtotime($post['created_at'])); ?></p>
                            </div>
                        </div>
                        <div class="post-content">
                            <?php echo $post['content']; ?>
                        </div>
                        <?php if ($post['image']): ?>
                            <?php $images = explode(',', $post['image']); ?>
                            <div class="row">
                                <?php foreach ($images as $img): ?>
                                    <div class="col-md-6 mb-3">
                                        <img src="assets/images/uploads/<?php echo $img; ?>" alt="帖子图片" class="post-image w-100">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <div class="post-actions">
                            <button class="action-btn">
                                <i class="far fa-heart"></i> 点赞 (<?php echo $post['likes']; ?>)
                            </button>
                            <button class="action-btn">
                                <i class="far fa-comment"></i> 评论 (<?php echo $post['comments']; ?>)
                            </button>
                            <button class="action-btn">
                                <i class="far fa-share-square"></i> 分享
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>

                <?php if ($total_count > $per_page): ?>
                    <nav aria-label="分页导航">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">上一页</a>
                                </li>
                            <?php endif; ?>

                            <?php
                            $start_page = max(1, $page - 2);
                            $end_page = min($total_pages, $page + 2);
                            if ($end_page - $start_page < 4) {
                                if ($start_page === 1) {
                                    $end_page = min($total_pages, $start_page + 4);
                                } else {
                                    $start_page = max(1, $end_page - 4);
                                }
                            }
                            ?>

                            <?php if ($start_page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>">1</a>
                                </li>
                                <?php if ($start_page > 2): ?>
                                    <li class="page-item disabled"><span class="page-link">...</span></li>
                                <?php endif; ?>
                            <?php endif; ?>

                            <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>

                            <?php if ($end_page < $total_pages): ?>
                                <?php if ($end_page < $total_pages - 1): ?>
                                    <li class="page-item disabled"><span class="page-link">...</span></li>
                                <?php endif; ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>"><?php echo $total_pages; ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if ($page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">下一页</a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>

                <?php if (empty($posts)): ?>
                    <div class="post-card text-center">
                        <i class="fas fa-search text-muted" style="font-size: 48px;"></i>
                        <p class="mt-3 text-muted">
                            <?php if (!empty($keyword) || !empty($category) || $user_id > 0 || !empty($date_from) || !empty($date_to) || !empty($time_filter) || $year > 0 || $month > 0): ?>
                                没有找到匹配的帖子，请尝试其他筛选条件
                            <?php else: ?>
                                输入关键词开始搜索帖子
                            <?php endif; ?>
                        </p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="col-lg-4">

                <div class="filter-section">
                    <h5 class="filter-title"><i class="fas fa-clock"></i> 时间分布</h5>
                    <div class="list-group list-group-flush">
                        <a href="?time_filter=today" class="list-group-item list-group-item-action <?php echo $time_filter === 'today' ? 'active' : ''; ?>">
                            <i class="fas fa-sun me-2"></i> 今天
                        </a>
                        <a href="?time_filter=yesterday" class="list-group-item list-group-item-action <?php echo $time_filter === 'yesterday' ? 'active' : ''; ?>">
                            <i class="fas fa-cloud-sun me-2"></i> 昨天
                        </a>
                        <a href="?time_filter=week" class="list-group-item list-group-item-action <?php echo $time_filter === 'week' ? 'active' : ''; ?>">
                            <i class="fas fa-calendar-week me-2"></i> 近7天
                        </a>
                        <a href="?time_filter=month" class="list-group-item list-group-item-action <?php echo $time_filter === 'month' ? 'active' : ''; ?>">
                            <i class="fas fa-calendar-alt me-2"></i> 近30天
                        </a>
                        <a href="?time_filter=year" class="list-group-item list-group-item-action <?php echo $time_filter === 'year' ? 'active' : ''; ?>">
                            <i class="fas fa-calendar me-2"></i> 近1年
                        </a>
                    </div>
                </div>

                <div class="filter-section">
                    <h5 class="filter-title"><i class="fas fa-users"></i> 按用户ID搜索</h5>
                    <form method="get" action="search.php">
                        <div class="input-group">
                            <span class="input-group-text">ID</span>
                            <input type="number" class="form-control" placeholder="输入用户ID" name="user_id">
                            <button class="btn btn-primary" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container text-center">
            <p class="mb-0">© 2026 &#19981;&#35265;&#26691;&#33457;&#19981;&#35265;&#31179; 版权所有</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>