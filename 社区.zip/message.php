<?php
session_start();

// 加载配置和数据库连接
if (file_exists('config.php')) {
    require_once 'config.php';
    require_once 'database.php';
} else {
    header('Location: install.php');
    exit;
}

// 简单的用户登录状态管理
$user = null;
if (isset($_SESSION['user_id'])) {
    $user = db()->fetch("SELECT * FROM users WHERE id = ?", [$_SESSION['user_id']]);
} else {
    header('Location: index.php');
    exit;
}

// 处理发送消息
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['receiver_id']) && isset($_POST['content'])) {
    $receiver_id = intval($_POST['receiver_id']);
    $content = trim($_POST['content']);
    
    if ($receiver_id > 0 && !empty($content) && $receiver_id != $user['id']) {
        // 插入消息
        db()->query("INSERT INTO messages (sender_id, receiver_id, content) VALUES (?, ?, ?)", [
            $user['id'],
            $receiver_id,
            $content
        ]);
        
        // 标记为已读
        db()->query("UPDATE messages SET is_read = 1 WHERE receiver_id = ? AND sender_id = ?", [
            $user['id'],
            $receiver_id
        ]);
        
        header('Location: message.php');
        exit;
    }
}

// 获取消息列表
$conversations = db()->fetchAll("SELECT 
    CASE 
        WHEN sender_id = ? THEN receiver_id 
        ELSE sender_id 
    END as user_id,
    MAX(created_at) as last_message_time
FROM messages 
WHERE sender_id = ? OR receiver_id = ? 
GROUP BY user_id 
ORDER BY last_message_time DESC", [$user['id'], $user['id'], $user['id']]);

// 获取每个对话的最新消息
$message_list = [];
foreach ($conversations as $conv) {
    $other_user = db()->fetch("SELECT * FROM users WHERE id = ?", [$conv['user_id']]);
    $last_message = db()->fetch("SELECT * FROM messages 
        WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) 
        ORDER BY created_at DESC LIMIT 1", [$user['id'], $conv['user_id'], $conv['user_id'], $user['id']]);
    $unread_count = db()->fetch("SELECT COUNT(*) as count FROM messages 
        WHERE receiver_id = ? AND sender_id = ? AND is_read = 0", [$user['id'], $conv['user_id']]);
    
    $message_list[] = [
        'user' => $other_user,
        'last_message' => $last_message,
        'unread_count' => $unread_count['count']
    ];
}

// 获取指定用户的消息
$selected_user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$selected_user = null;
$messages = [];

if ($selected_user_id > 0) {
    $selected_user = db()->fetch("SELECT * FROM users WHERE id = ?", [$selected_user_id]);
    if ($selected_user) {
        // 标记为已读
        db()->query("UPDATE messages SET is_read = 1 WHERE receiver_id = ? AND sender_id = ?", [
            $user['id'],
            $selected_user_id
        ]);
        
        // 获取消息
        $messages = db()->fetchAll("SELECT * FROM messages 
            WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) 
            ORDER BY created_at ASC", [$user['id'], $selected_user_id, $selected_user_id, $user['id']]);
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>心事社区 - 消息</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .nav-link {
            color: #333;
        }
        .nav-link.active {
            color: #007bff;
            font-weight: bold;
        }
        .navbar-toggler {
            padding: 0.15rem 0.35rem;
            font-size: 0.75rem;
            line-height: 1;
            align-self: center;
        }
        .navbar-toggler-icon {
            width: 1em;
            height: 1em;
        }
        .avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 15px;
        }
        @media (max-width: 576px) {
            .navbar {
                height: 60px;
            }
            .navbar .container {
                height: 100%;
                display: flex;
                align-items: center;
            }
            .navbar .d-flex {
                margin-top: 10px;
                width: 100%;
            }
            .navbar .d-flex .btn {
                flex: 1;
                margin: 0 5px;
            }
            .navbar .d-flex .btn:first-child {
                margin-left: 0;
            }
            .navbar .d-flex .btn:last-child {
                margin-right: 0;
            }
            .dropdown-menu {
                position: static !important;
                float: none !important;
                width: 100% !important;
                margin-top: 0 !important;
            }
            .navbar-collapse .navbar-nav {
                display: none !important;
            }
        }
        .message-container {
            height: calc(100vh - 120px);
        }
        .message-sidebar {
            background-color: white;
            border-right: 1px solid #e9ecef;
            overflow-y: auto;
        }
        .message-list {
            background-color: #f8f9fa;
            overflow-y: auto;
        }
        .message-item {
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
            cursor: pointer;
        }
        .message-item:hover {
            background-color: #f8f9fa;
        }
        .message-item.active {
            background-color: #e3f2fd;
        }
        .message-item .avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }
        .message-item .badge {
            font-size: 12px;
        }
        .message-content {
            padding: 20px;
        }
        .message-bubble {
            max-width: 70%;
            padding: 10px 15px;
            border-radius: 18px;
            margin-bottom: 10px;
        }
        .message-bubble.sent {
            background-color: #007bff;
            color: white;
            align-self: flex-end;
            border-bottom-right-radius: 4px;
        }
        .message-bubble.received {
            background-color: white;
            color: #333;
            align-self: flex-start;
            border-bottom-left-radius: 4px;
        }
        .message-input {
            border-top: 1px solid #e9ecef;
            padding: 15px;
            background-color: white;
        }
        .form-control {
            border-radius: 20px;
        }
        .btn-primary {
            border-radius: 20px;
        }
        .footer {
            background-color: white;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
            padding: 20px 0;
            margin-top: 40px;
        }
        /* 移动端底部导航 */
        .mobile-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: white;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
            z-index: 1000;
            height: 60px;
        }
        .mobile-nav .navbar-nav {
            display: flex;
            flex-direction: row;
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
        }
        .mobile-nav .nav-item {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .mobile-nav .nav-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 0;
            color: #6c757d;
            height: 100%;
            width: 100%;
        }
        .mobile-nav .nav-link.active {
            color: #007bff;
        }
        .mobile-nav .nav-link i {
            font-size: 18px;
            margin-bottom: 2px;
        }
        .mobile-nav .nav-link span {
            font-size: 12px;
        }
        /* 为移动端内容添加底部边距，避免被导航栏遮挡 */
        @media (max-width: 767px) {
            .container {
                margin-bottom: 70px;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-comments text-primary mr-2"></i>
                心事社区
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-home"></i> 首页
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="message.php">
                            <i class="fas fa-envelope"></i> 消息
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="discover.php">
                            <i class="fas fa-compass"></i> 发现
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i> 我的
                        </a>
                    </li>
                    <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">
                            <i class="fas fa-cog"></i> 管理
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                <div class="d-flex align-items-center">
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown">
                            <img src="assets/images/<?php echo $user['avatar']; ?>" alt="头像" class="avatar" style="width: 36px; height: 36px;">
                            <span class="ms-2"><?php echo $user['username']; ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php">个人资料</a></li>
                            <li><a class="dropdown-item" href="edit_profile.php">编辑资料</a></li>
                            <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                            <li><a class="dropdown-item" href="admin.php?tab=about"><i class="fas fa-info-circle"></i> 编辑关于</a></li>
                            <?php else: ?>
                            <li><a class="dropdown-item" href="#">设置</a></li>
                            <?php endif; ?>
                            <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                            <li><a class="dropdown-item" href="admin.php">管理后台</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="index.php?action=logout">退出登录</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- 移动端底部导航 -->
    <nav class="mobile-nav d-md-none navbar navbar-expand-lg">
        <ul class="navbar-nav w-100 d-flex justify-content-around">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-home"></i>
                    <span>首页</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="message.php">
                    <i class="fas fa-envelope"></i>
                    <span>消息</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="discover.php">
                    <i class="fas fa-compass"></i>
                    <span>发现</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>我的</span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- 主要内容 -->
    <div class="container-fluid message-container">
        <div class="row h-100">
            <!-- 消息列表 -->
            <div class="col-md-4 message-sidebar">
                <div class="p-3 border-bottom">
                    <h5 class="mb-0">消息</h5>
                </div>
                
                <?php if (!empty($message_list)): ?>
                    <?php foreach ($message_list as $item): ?>
                        <a href="message.php?user_id=<?php echo $item['user']['id']; ?>" class="d-flex message-item <?php echo $selected_user_id == $item['user']['id'] ? 'active' : ''; ?>">
                            <img src="assets/images/<?php echo $item['user']['avatar']; ?>" alt="头像" class="avatar">
                            <div class="ml-3 flex-grow-1">
                                <div class="d-flex justify-content-between">
                                    <h6 class="mb-1"><?php echo $item['user']['username']; ?></h6>
                                    <span class="text-muted small"><?php echo date('H:i', strtotime($item['last_message']['created_at'])); ?></span>
                                </div>
                                <p class="mb-0 text-muted small truncate"><?php echo $item['last_message']['content']; ?></p>
                            </div>
                            <?php if ($item['unread_count'] > 0): ?>
                                <span class="badge bg-primary align-self-center"><?php echo $item['unread_count']; ?></span>
                            <?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center p-5">
                        <i class="fas fa-envelope-open text-muted" style="font-size: 48px;"></i>
                        <p class="mt-3 text-muted">还没有消息，开始和朋友聊天吧！</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- 消息内容 -->
            <div class="col-md-8 message-list">
                <?php if ($selected_user): ?>
                    <!-- 聊天头部 -->
                    <div class="p-3 border-bottom bg-white">
                        <div class="d-flex align-items-center">
                            <img src="assets/images/<?php echo $selected_user['avatar']; ?>" alt="头像" class="avatar" style="width: 40px; height: 40px;">
                            <h6 class="ml-3 mb-0"><?php echo $selected_user['username']; ?></h6>
                        </div>
                    </div>

                    <!-- 聊天内容 -->
                    <div class="p-4" style="height: calc(100% - 140px); overflow-y: auto;">
                        <?php foreach ($messages as $msg): ?>
                            <div class="d-flex mb-3 <?php echo $msg['sender_id'] == $user['id'] ? 'justify-content-end' : ''; ?>">
                                <div class="message-bubble <?php echo $msg['sender_id'] == $user['id'] ? 'sent' : 'received'; ?>">
                                    <?php echo $msg['content']; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- 消息输入 -->
                    <div class="message-input">
                        <form method="post">
                            <input type="hidden" name="receiver_id" value="<?php echo $selected_user_id; ?>">
                            <div class="d-flex">
                                <input type="text" class="form-control flex-grow-1" placeholder="输入消息..." name="content" required>
                                <button type="submit" class="btn btn-primary ml-2">发送</button>
                            </div>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="h-100 d-flex flex-column justify-content-center align-items-center">
                        <i class="fas fa-comments text-muted" style="font-size: 64px;"></i>
                        <p class="mt-3 text-muted">选择一个联系人开始聊天</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 页脚 -->
    <footer class="footer">
        <div class="container text-center">
            <p class="mb-0">© 2026 心事社区 版权所有</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        // 自动滚动到底部
        function scrollToBottom() {
            var chatContainer = $('.message-list .p-4');
            chatContainer.scrollTop(chatContainer[0].scrollHeight);
        }
        
        // 页面加载完成后滚动到底部
        $(document).ready(function() {
            scrollToBottom();
        });
    </script>
</body>
</html>