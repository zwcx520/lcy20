<?php
session_start();

// 加载配置和数据库连接
if (file_exists('config.php')) {
    require_once 'config.php';
    require_once 'database.php';
} else {
    header('Location: install.php');
    exit;
}

// 创建好友关系表（如果不存在）
try {
    db()->query("CREATE TABLE IF NOT EXISTS `friends` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT UNSIGNED NOT NULL,
        `friend_id` INT UNSIGNED NOT NULL,
        `status` TINYINT(1) DEFAULT 0,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY `unique_friendship` (`user_id`, `friend_id`),
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
        FOREIGN KEY (`friend_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {
    // 表已存在或创建失败，忽略错误
}

// 简单的用户登录状态管理
$user = null;
if (isset($_SESSION['user_id'])) {
    $user = db()->fetch("SELECT * FROM users WHERE id = ?", [$_SESSION['user_id']]);
} else {
    header('Location: index.php');
    exit;
}

// 处理发送消息
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['receiver_id']) && isset($_POST['content'])) {
    $receiver_id = intval($_POST['receiver_id']);
    $content = trim($_POST['content']);
    $is_ajax = isset($_POST['ajax']) && $_POST['ajax'] == '1';
    
    if ($receiver_id > 0 && !empty($content) && $receiver_id != $user['id']) {
        // 插入消息
        db()->query("INSERT INTO messages (sender_id, receiver_id, content) VALUES (?, ?, ?)", [
            $user['id'],
            $receiver_id,
            $content
        ]);
        
        $message_id = db()->lastInsertId();
        
        // 标记为已读
        db()->query("UPDATE messages SET is_read = 1 WHERE receiver_id = ? AND sender_id = ?", [
            $user['id'],
            $receiver_id
        ]);
        
        if ($is_ajax) {
            // AJAX请求返回JSON
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'message_id' => $message_id,
                'content' => $content,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            exit;
        } else {
            header('Location: message.php?user_id=' . $receiver_id);
            exit;
        }
    }
}

// AJAX获取新消息
if (isset($_GET['action']) && $_GET['action'] == 'get_messages') {
    $chat_user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
    $last_id = isset($_GET['last_id']) ? intval($_GET['last_id']) : 0;
    
    if ($chat_user_id > 0 && $last_id >= 0) {
        $new_messages = db()->fetchAll("SELECT * FROM messages 
            WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
            AND id > ?
            ORDER BY created_at ASC", [$user['id'], $chat_user_id, $chat_user_id, $user['id'], $last_id]);
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'messages' => $new_messages
        ]);
        exit;
    }
}

// AJAX标记消息为已读
if (isset($_GET['action']) && $_GET['action'] == 'mark_read') {
    $chat_user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
    
    if ($chat_user_id > 0) {
        db()->query("UPDATE messages SET is_read = 1 WHERE receiver_id = ? AND sender_id = ?", [
            $user['id'],
            $chat_user_id
        ]);
        
        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
        exit;
    }
}

// 处理添加好友
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add_friend') {
    $friend_id = intval($_POST['friend_id']);
    if ($friend_id > 0 && $friend_id != $user['id']) {
        // 检查是否已经是好友或有未处理的请求
        $existing = db()->fetch("SELECT * FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)", [
            $user['id'], $friend_id, $friend_id, $user['id']
        ]);
        if (!$existing) {
            // 发送好友请求
            db()->query("INSERT INTO friends (user_id, friend_id, status) VALUES (?, ?, ?)", [
                $user['id'],
                $friend_id,
                0 // 0=待确认
            ]);
        }
        header('Location: message.php');
        exit;
    }
}

// 处理接受好友请求
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'accept_friend') {
    $friend_id = intval($_POST['friend_id']);
    if ($friend_id > 0) {
        // 更新好友状态为已确认
        db()->query("UPDATE friends SET status = 1 WHERE user_id = ? AND friend_id = ?", [
            $friend_id,
            $user['id']
        ]);
        // 同时创建反向好友关系
        db()->query("INSERT IGNORE INTO friends (user_id, friend_id, status) VALUES (?, ?, ?)", [
            $user['id'],
            $friend_id,
            1
        ]);
        header('Location: message.php');
        exit;
    }
}

// 处理拒绝好友请求
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'reject_friend') {
    $friend_id = intval($_POST['friend_id']);
    if ($friend_id > 0) {
        // 删除好友请求
        db()->query("DELETE FROM friends WHERE user_id = ? AND friend_id = ?", [
            $friend_id,
            $user['id']
        ]);
        header('Location: message.php');
        exit;
    }
}

// 处理删除好友
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'remove_friend') {
    $friend_id = intval($_POST['friend_id']);
    if ($friend_id > 0) {
        // 删除双向好友关系
        db()->query("DELETE FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)", [
            $user['id'], $friend_id, $friend_id, $user['id']
        ]);
        header('Location: message.php');
        exit;
    }
}

// 获取消息列表
$conversations = db()->fetchAll("SELECT 
    CASE 
        WHEN sender_id = ? THEN receiver_id 
        ELSE sender_id 
    END as user_id,
    MAX(created_at) as last_message_time
FROM messages 
WHERE sender_id = ? OR receiver_id = ? 
GROUP BY user_id 
ORDER BY last_message_time DESC", [$user['id'], $user['id'], $user['id']]);

// 获取每个对话的最新消息
$message_list = [];
foreach ($conversations as $conv) {
    $other_user = db()->fetch("SELECT * FROM users WHERE id = ?", [$conv['user_id']]);
    $last_message = db()->fetch("SELECT * FROM messages 
        WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) 
        ORDER BY created_at DESC LIMIT 1", [$user['id'], $conv['user_id'], $conv['user_id'], $user['id']]);
    $unread_count = db()->fetch("SELECT COUNT(*) as count FROM messages 
        WHERE receiver_id = ? AND sender_id = ? AND is_read = 0", [$user['id'], $conv['user_id']]);
    
    $message_list[] = [
        'user' => $other_user,
        'last_message' => $last_message,
        'unread_count' => $unread_count['count']
    ];
}

// 获取好友列表
$friends = db()->fetchAll("SELECT u.* FROM users u JOIN friends f ON u.id = f.friend_id WHERE f.user_id = ? AND f.status = 1 ORDER BY u.username", [$user['id']]);

// 获取好友请求
$friend_requests = db()->fetchAll("SELECT u.* FROM users u JOIN friends f ON u.id = f.user_id WHERE f.friend_id = ? AND f.status = 0 ORDER BY f.created_at DESC", [$user['id']]);

// 获取指定用户的消息
$selected_user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$selected_user = null;
$messages = [];

if ($selected_user_id > 0) {
    $selected_user = db()->fetch("SELECT * FROM users WHERE id = ?", [$selected_user_id]);
    if ($selected_user) {
        // 标记为已读
        db()->query("UPDATE messages SET is_read = 1 WHERE receiver_id = ? AND sender_id = ?", [
            $user['id'],
            $selected_user_id
        ]);
        
        // 获取消息
        $messages = db()->fetchAll("SELECT * FROM messages 
            WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) 
            ORDER BY created_at ASC", [$user['id'], $selected_user_id, $selected_user_id, $user['id']]);
    }
}

// 处理用户搜索
$search_keyword = isset($_GET['search']) ? trim($_GET['search']) : '';
$search_results = [];
if (!empty($search_keyword)) {
    $search_results = db()->fetchAll("SELECT * FROM users WHERE (username LIKE ? OR email LIKE ?) AND id != ? LIMIT 20", ["%$search_keyword%", "%$search_keyword%", $user['id']]);
} else {
    // 当没有搜索关键词时，显示管理员列表
    $search_results = db()->fetchAll("SELECT * FROM users WHERE is_admin = 1 AND id != ?", [$user['id']]);
}

// 检查好友状态
function is_friend($user_id, $friend_id) {
    $result = db()->fetch("SELECT * FROM friends WHERE user_id = ? AND friend_id = ? AND status = 1", [$user_id, $friend_id]);
    return $result !== false;
}

// 检查是否有未处理的好友请求
function has_pending_request($user_id, $friend_id) {
    $result = db()->fetch("SELECT * FROM friends WHERE user_id = ? AND friend_id = ? AND status = 0", [$user_id, $friend_id]);
    return $result !== false;
}

// 获取用户类型显示
function get_user_type($user) {
    if (isset($user['is_admin']) && $user['is_admin']) {
        return '<span class="badge bg-danger ml-1">管理员</span>';
    }
    return '';
}

function format_message_time($datetime) {
    $timestamp = strtotime($datetime);
    $today = strtotime('today');
    $yesterday = strtotime('yesterday');
    
    if ($timestamp >= $today) {
        return date('Y-m-d H:i', $timestamp);
    } elseif ($timestamp >= $yesterday) {
        return date('Y-m-d H:i', $timestamp);
    } else {
        return date('Y-m-d H:i', $timestamp);
    }
}

function format_message_date($datetime) {
    $timestamp = strtotime($datetime);
    $today = strtotime('today');
    $yesterday = strtotime('yesterday');
    $week_ago = strtotime('-7 days');
    
    if ($timestamp >= $today) {
        return '今天';
    } elseif ($timestamp >= $yesterday) {
        return '昨天';
    } elseif ($timestamp >= $week_ago) {
        $weekdays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
        return $weekdays[date('w', $timestamp)];
    } else {
        return date('Y年m月d日', $timestamp);
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>心事社区 - 消息</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        html, body {
            height: 100%;
            overflow: hidden;
        }
        body {
           background-image: url(bj.jpg);
                 background-size: cover; /* 修改为cover，使图片铺满满屏 */
                 background-attachment: fixed; /* 可选，使背景图片固定不随页面滚动 */
                 margin: 0; /* 去除默认边距 */
                 padding: 0; /* 去除默认内边距 */
            
        }
        .navbar {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .nav-link {
            color: #333;
        }
        .nav-link.active {
            color: #007bff;
            font-weight: bold;
        }
        .navbar-toggler {
            padding: 0.15rem 0.35rem;
            font-size: 0.75rem;
            line-height: 1;
            align-self: center;
        }
        .navbar-toggler-icon {
            width: 1em;
            height: 1em;
        }
        .avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 15px;
        }
        @media (max-width: 576px) {
            .navbar {
                height: 60px;
            }
            .navbar .container {
                height: 100%;
                display: flex;
                align-items: center;
            }
            .navbar .d-flex {
                margin-top: 10px;
                width: 100%;
            }
            .navbar .d-flex .btn {
                flex: 1;
                margin: 0 5px;
            }
            .navbar .d-flex .btn:first-child {
                margin-left: 0;
            }
            .navbar .d-flex .btn:last-child {
                margin-right: 0;
            }
            .dropdown-menu {
                position: static !important;
                float: none !important;
                width: 100% !important;
                margin-top: 0 !important;
            }
            .navbar-collapse .navbar-nav {
                display: none !important;
            }
        }
        /* PC端消息容器 - 固定高度不滚动 */
        @media (min-width: 768px) {
            .message-container {
                height: calc(100vh - 120px);
                overflow: hidden;
                display: flex;
            }
            
            .message-sidebar {
                width: 350px;
                min-width: 350px;
                height: 100%;
                background-color: white;
                border-right: 1px solid #e9ecef;
                display: flex;
                flex-direction: column;
                overflow: hidden;
            }
            
            .message-sidebar .sidebar-header {
                padding: 15px;
                border-bottom: 1px solid #e9ecef;
                flex-shrink: 0;
            }
            
            .message-sidebar .search-container {
                padding: 10px 15px;
                border-bottom: 1px solid #e9ecef;
                flex-shrink: 0;
            }
            
            .message-sidebar .message-tabs {
                flex-shrink: 0;
                margin: 10px 15px;
            }
            
            .message-sidebar .tab-content {
                flex: 1;
                overflow-y: auto;
                overflow-x: hidden;
            }
            
            .message-list {
                flex: 1;
                height: 100%;
                background-color: #f8f9fa;
                display: flex;
                flex-direction: column;
                overflow: hidden;
                position: relative;
            }
            
            .message-list .chat-header {
                flex-shrink: 0;
                padding: 15px;
                border-bottom: 1px solid #e9ecef;
                background-color: white;
            }
            
            .message-list .chat-messages {
                flex: 1;
                overflow-y: auto;
                padding: 15px;
            }
            
            .message-list .message-input {
                flex-shrink: 0;
                padding: 12px 15px;
                background-color: white;
                border-top: 1px solid #e9ecef;
            }
            
            .message-list .message-input .d-flex {
                max-width: 800px;
                margin: 0 auto;
            }
            
            .message-list .message-input .send-btn {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                padding: 0;
                display: flex;
                align-items: center;
                justify-content: center;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border: none;
                flex-shrink: 0;
            }
            
            .message-list .message-input input {
                border-radius: 20px;
                padding-right: 50px;
            }
        }
        
        /* 移动端保持原样式 */
        @media (max-width: 767px) {
            .message-container {
                height: calc(100vh - 120px);
            }
        }
        
        /* 聊天消息样式 */
        .message-item {
            display: flex;
            align-items: flex-end;
            margin-bottom: 12px;
            gap: 8px;
        }
        
        .message-item.sent {
            justify-content: flex-end;
        }
        
        .message-item .message-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            flex-shrink: 0;
        }
        
        .message-item .message-content-wrapper {
            max-width: 70%;
            display: flex;
            flex-direction: column;
        }
        
        .message-item.sent .message-content-wrapper {
            align-items: flex-end;
        }
        
        .message-item .message-bubble {
            padding: 8px 12px;
            border-radius: 16px;
            font-size: 14px;
            line-height: 1.4;
            word-wrap: break-word;
        }
        
        .message-item .message-bubble.sent {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-bottom-right-radius: 4px;
        }
        
        .message-item .message-bubble.received {
            background: white;
            color: #333;
            border-bottom-left-radius: 4px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        }
        
        .message-item .message-time {
            font-size: 10px;
            color: #bbb;
            margin-top: 4px;
            padding: 0 4px;
        }
        
        .message-sidebar {
            background-color: white;
            border-right: 1px solid #e9ecef;
            overflow-y: auto;
        }
        .message-list {
            background-image: url(gysq.png);
                  background-size: cover; /* 修改为cover，使图片铺满满屏 */
                  background-attachment: fixed; /* 可选，使背景图片固定不随页面滚动 */
                  margin: 0; /* 去除默认边距 */
                  padding: 0; /* 去除默认内边距 */
             
            overflow-y: auto;
            position: relative;
        }
       
        
        }
        .message-item.active {
            background-color: #e3f2fd;
        }
        .message-item .avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }
        .message-item .badge {
            font-size: 12px;
        }
        .message-content {
            padding: 20px;
        }
        .message-input {
            border-top: 1px solid #e9ecef;
            padding: 15px;
            background-color: white;
            position: relative;
        }
        
        .form-control {
            border-radius: 20px;
        }
        .btn-primary {
            border-radius: 20px;
        }
        .footer {
            background-color: white;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
            padding: 20px 0;
            margin-top: 40px;
        }
        /* 移动端底部导航 */
        .mobile-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: white;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
            z-index: 1000;
            height: 60px;
        }
        .mobile-nav .navbar-nav {
            display: flex;
            flex-direction: row;
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
        }
        .mobile-nav .nav-item {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .mobile-nav .nav-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 0;
            color: #6c757d;
            height: 100%;
            width: 100%;
        }
        .mobile-nav .nav-link.active {
            color: #007bff;
        }
        .mobile-nav .nav-link i {
            font-size: 18px;
            margin-bottom: 2px;
        }
        .mobile-nav .nav-link span {
            font-size: 12px;
        }
        /* 为移动端内容添加底部边距，避免被导航栏遮挡 */
        @media (max-width: 767px) {
            .container {
                margin-bottom: 70px;
            }
        }
        .tab-content {
            height: calc(100% - 60px);
            overflow-y: auto;
        }
        .search-container {
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
            background-color: #f8f9fa;
        }
        .friend-request-badge {
            position: absolute;
            top: 5px;
            right: 5px;
            font-size: 10px;
        }
        .user-card {
            padding: 10px;
            border-bottom: 1px solid #e9ecef;
        }
        .user-card:hover {
            background-color: #f8f9fa;
        }
        .user-actions {
            display: flex;
            gap: 5px;
        }
        .btn-sm {
            border-radius: 15px;
        }
        /* 自定义标签页样式 */
        .message-tabs {
            display: flex;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            padding: 4px;
            margin: 10px 15px;
            gap: 4px;
        }
        .message-tabs .tab-btn {
            flex: 1;
            padding: 10px 16px;
            border: none;
            background: transparent;
            color: rgba(255, 255, 255, 0.8);
            font-size: 14px;
            font-weight: 500;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            position: relative;
        }
        .message-tabs .tab-btn:hover {
            color: white;
            background: rgba(255, 255, 255, 0.1);
        }
        .message-tabs .tab-btn.active {
            background: white;
            color: #667eea;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
        }
        .message-tabs .tab-btn .badge {
            font-size: 11px;
            padding: 2px 6px;
            border-radius: 10px;
            background: #ff4757;
            color: white;
            margin-left: 4px;
        }
        .message-tabs .tab-btn.active .badge {
            background: #667eea;
        }
        /* 旧标签页样式隐藏 */
        .nav-tabs {
            display: none;
        }
        /* 标签页内容区域优化 */
        .message-tabs-content {
            height: calc(100% - 60px);
            overflow-y: auto;
        }
        .message-list-item {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-bottom: 1px solid #f0f0f0;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
            color: inherit;
        }
        .message-list-item:hover {
            background-color: #f8f9fa;
            padding-left: 20px;
        }
        .message-list-item.active {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
            border-left: 3px solid #667eea;
            padding-left: 12px;
        }
        .message-list-item .avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 12px;
            border: 2px solid #f0f0f0;
            transition: border-color 0.3s ease;
        }
        .message-list-item:hover .avatar,
        .message-list-item.active .avatar {
            border-color: #667eea;
        }
        .message-list-item .info {
            flex: 1;
            min-width: 0;
        }
        .message-list-item .name {
            font-weight: 600;
            color: #333;
            margin-bottom: 4px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .message-list-item .name .admin-badge {
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
            color: white;
            font-weight: normal;
        }
        .message-list-item .preview {
            font-size: 13px;
            color: #999;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .message-list-item .meta {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            margin-left: 10px;
        }
        .message-list-item .time {
            font-size: 11px;
            color: #bbb;
            margin-bottom: 4px;
        }
        .message-list-item .unread-badge {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-size: 11px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        /* 好友请求区域 */
        .friend-request-section {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.08) 0%, rgba(118, 75, 162, 0.08) 100%);
            border-radius: 10px;
            margin: 10px 15px;
            padding: 12px;
        }
        .friend-request-section h6 {
            color: #667eea;
            font-weight: 600;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .friend-request-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px;
            background: white;
            border-radius: 8px;
            margin-bottom: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .friend-request-item:last-child {
            margin-bottom: 0;
        }
        .friend-request-item .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .friend-request-item .user-info img {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
        }
        .friend-request-item .user-info .name {
            font-weight: 500;
            color: #333;
            font-size: 14px;
        }
        .friend-request-item .actions {
            display: flex;
            gap: 6px;
        }
        .friend-request-item .actions button {
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 12px;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .friend-request-item .actions .accept {
            background: linear-gradient(135deg, #2ed573 0%, #26a65b 100%);
            color: white;
        }
        .friend-request-item .actions .accept:hover {
            transform: scale(1.05);
            box-shadow: 0 2px 8px rgba(46, 213, 115, 0.4);
        }
        .friend-request-item .actions .reject {
            background: #f1f2f6;
            color: #999;
        }
        .friend-request-item .actions .reject:hover {
            background: #ff4757;
            color: white;
        }
        /* 空状态样式 */
        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: #999;
        }
        .empty-state i {
            font-size: 60px;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        .empty-state p {
            margin: 0;
            font-size: 14px;
        }
        .empty-state .hint {
            font-size: 12px;
            margin-top: 8px;
            color: #bbb;
        }
        /* 移动端适配 */
        @media (max-width: 768px) {
            /* 隐藏PC端布局 */
            .message-container .row {
                display: block;
            }
            
            /* 移动端全屏容器 */
            .mobile-chat-container {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: #fff;
                z-index: 1050;
                flex-direction: column;
            }
            
            .mobile-chat-container.active {
                display: flex;
            }
            
            /* 隐藏PC端侧边栏 */
            .message-sidebar {
                display: none;
            }
            
            .message-list {
                display: none;
            }
            
            /* 移动端聊天列表 */
            .mobile-list-view {
                display: flex;
                flex-direction: column;
                height: 100%;
                background: #fff;
            }
            
            .mobile-list-view .mobile-header {
                display: flex;
                align-items: center;
                padding: 12px 15px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                gap: 10px;
            }
            
            .mobile-list-view .mobile-header .back-btn {
                background: none;
                border: none;
                color: white;
                font-size: 20px;
                padding: 5px;
                cursor: pointer;
            }
            
            .mobile-list-view .mobile-header h5 {
                margin: 0;
                font-size: 16px;
                font-weight: 500;
            }
            
            /* 移动端标签页 */
            .mobile-tabs {
                display: flex;
                background: #f8f9fa;
                padding: 8px 10px;
                gap: 8px;
                border-bottom: 1px solid #eee;
            }
            
            .mobile-tabs .mobile-tab-btn {
                flex: 1;
                padding: 8px 12px;
                border: none;
                background: white;
                color: #666;
                font-size: 13px;
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.2s ease;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 4px;
                position: relative;
            }
            
            .mobile-tabs .mobile-tab-btn.active {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
            }
            
            .mobile-tabs .mobile-tab-btn .badge {
                font-size: 10px;
                padding: 1px 5px;
                border-radius: 8px;
                background: #ff4757;
                color: white;
                margin-left: 3px;
            }
            
            .mobile-tabs .mobile-tab-btn.active .badge {
                background: white;
                color: #667eea;
            }
            
            /* 移动端搜索框 */
            .mobile-search {
                padding: 10px 12px;
                background: #f8f9fa;
            }
            
            .mobile-search form {
                display: flex;
                gap: 8px;
            }
            
            .mobile-search input {
                flex: 1;
                padding: 8px 12px;
                border: 1px solid #ddd;
                border-radius: 20px;
                font-size: 14px;
            }
            
            .mobile-search button {
                padding: 8px 16px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border: none;
                border-radius: 20px;
                font-size: 14px;
            }
            
            /* 移动端列表内容 */
            .mobile-list-content {
                flex: 1;
                overflow-y: auto;
            }
            
            .mobile-list-content .message-list-item {
                display: flex;
                align-items: center;
                padding: 12px 15px;
                border-bottom: 1px solid #f0f0f0;
                cursor: pointer;
                text-decoration: none;
                color: inherit;
                transition: background 0.2s;
            }
            
            .mobile-list-content .message-list-item:active {
                background: #f0f0f0;
            }
            
            .mobile-list-content .message-list-item .avatar {
                width: 45px;
                height: 45px;
                border-radius: 50%;
                object-fit: cover;
                margin-right: 12px;
                border: 2px solid #f0f0f0;
            }
            
            .mobile-list-content .message-list-item .info {
                flex: 1;
                min-width: 0;
            }
            
            .mobile-list-content .message-list-item .name {
                font-weight: 600;
                color: #333;
                font-size: 14px;
                margin-bottom: 3px;
                display: flex;
                align-items: center;
                gap: 5px;
            }
            
            .mobile-list-content .message-list-item .admin-badge {
                font-size: 9px;
                padding: 1px 5px;
                border-radius: 3px;
                background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
                color: white;
                font-weight: normal;
            }
            
            .mobile-list-content .message-list-item .preview {
                font-size: 12px;
                color: #999;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            
            .mobile-list-content .message-list-item .meta {
                display: flex;
                flex-direction: column;
                align-items: flex-end;
                margin-left: 8px;
            }
            
            .mobile-list-content .message-list-item .time {
                font-size: 10px;
                color: #bbb;
                margin-bottom: 3px;
            }
            
            .mobile-list-content .message-list-item .unread-badge {
                width: 18px;
                height: 18px;
                border-radius: 50%;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                font-size: 10px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: 600;
            }
            
            /* 移动端好友请求 */
            .mobile-friend-requests {
                padding: 10px 12px;
                background: rgba(102, 126, 234, 0.08);
                margin: 10px 12px;
                border-radius: 10px;
            }
            
            .mobile-friend-requests h6 {
                color: #667eea;
                font-size: 13px;
                font-weight: 600;
                margin-bottom: 8px;
                display: flex;
                align-items: center;
                gap: 5px;
            }
            
            .mobile-friend-request-item {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 8px;
                background: white;
                border-radius: 8px;
                margin-bottom: 6px;
            }
            
            .mobile-friend-request-item:last-child {
                margin-bottom: 0;
            }
            
            .mobile-friend-request-item .user-info {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            .mobile-friend-request-item .user-info img {
                width: 32px;
                height: 32px;
                border-radius: 50%;
                object-fit: cover;
            }
            
            .mobile-friend-request-item .user-info .name {
                font-weight: 500;
                color: #333;
                font-size: 13px;
            }
            
            .mobile-friend-request-item .actions {
                display: flex;
                gap: 4px;
            }
            
            .mobile-friend-request-item .actions button {
                padding: 3px 10px;
                border-radius: 12px;
                font-size: 11px;
                border: none;
                cursor: pointer;
            }
            
            .mobile-friend-request-item .actions .accept {
                background: linear-gradient(135deg, #2ed573 0%, #26a65b 100%);
                color: white;
            }
            
            .mobile-friend-request-item .actions .reject {
                background: #f1f2f6;
                color: #999;
            }
            
            /* 移动端聊天视图 */
            .mobile-chat-view {
                display: none;
                flex-direction: column;
                height: 100%;
                background: #fff;
            }
            
            .mobile-chat-view.active {
                display: flex;
            }
            
            .mobile-chat-view .chat-header {
                display: flex;
                align-items: center;
                padding: 12px 15px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                gap: 10px;
            }
            
            .mobile-chat-view .chat-header .back-btn {
                background: none;
                border: none;
                color: white;
                font-size: 20px;
                padding: 5px;
                cursor: pointer;
            }
            
            .mobile-chat-view .chat-header .user-info {
                display: flex;
                align-items: center;
                gap: 10px;
                flex: 1;
            }
            
            .mobile-chat-view .chat-header img {
                width: 36px;
                height: 36px;
                border-radius: 50%;
                object-fit: cover;
                border: 2px solid rgba(255,255,255,0.3);
            }
            
            .mobile-chat-view .chat-header .name {
                font-size: 15px;
                font-weight: 500;
            }
            
            .mobile-chat-view .chat-header .admin-badge {
                font-size: 9px;
                padding: 1px 5px;
                border-radius: 3px;
                background: rgba(255,255,255,0.2);
                font-weight: normal;
            }
            
            .mobile-chat-view .chat-header .action-btn {
                background: rgba(255,255,255,0.2);
                border: none;
                color: white;
                padding: 6px 10px;
                border-radius: 15px;
                font-size: 12px;
                cursor: pointer;
            }
            
            /* 移动端消息气泡 */
            .mobile-chat-view .chat-messages {
                flex: 1;
                overflow-y: auto;
                padding: 15px;
             background-image: url(gysq.png);
                   background-size: cover; /* 修改为cover，使图片铺满满屏 */
                   background-attachment: fixed; /* 可选，使背景图片固定不随页面滚动 */
                   margin: 0; /* 去除默认边距 */
                   padding: 0; /* 去除默认内边距 */
              
            }
            
            .mobile-chat-view .message-bubble-wrapper {
                display: flex;
                margin-bottom: 12px;
            }
            
            .mobile-chat-view .message-bubble-wrapper.sent {
                justify-content: flex-end;
            }
            
            .mobile-chat-view .message-bubble-wrapper .avatar {
                width: 32px;
                height: 32px;
                border-radius: 50%;
                object-fit: cover;
                margin-right: 8px;
            }
            
            .mobile-chat-view .message-bubble-wrapper.sent .avatar {
                display: none;
            }
            
            .mobile-chat-view .message-bubble {
                max-width: 75%;
                padding: 8px 12px;
                border-radius: 16px;
                font-size: 14px;
                line-height: 1.4;
                position: relative;
            }
            
            .mobile-chat-view .message-bubble.sent {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border-bottom-right-radius: 4px;
            }
            
            .mobile-chat-view .message-bubble.received {
                background: white;
                color: #333;
                border-bottom-left-radius: 4px;
                box-shadow: 0 1px 2px rgba(0,0,0,0.05);
            }
            
            .mobile-chat-view .message-bubble .message-time {
                font-size: 10px;
                color: rgba(255,255,255,0.7);
                margin-top: 4px;
                text-align: right;
            }
            
            .mobile-chat-view .message-bubble.received .message-time {
                color: #999;
            }
            
            /* 移动端输入框 */
            .mobile-chat-view .chat-input {
                padding: 10px 12px;
                background: white;
                border-top: 1px solid #eee;
                display: flex;
                gap: 8px;
                align-items: center;
            }
            
            .mobile-chat-view .chat-input input {
                flex: 1;
                padding: 10px 15px;
                border: 1px solid #ddd;
                border-radius: 25px;
                font-size: 14px;
            }
            
            .mobile-chat-view .chat-input button {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border: none;
                font-size: 16px;
                cursor: pointer;
            }
            
            /* 移动端空状态 */
            .mobile-empty-state {
                text-align: center;
                padding: 60px 20px;
                color: #999;
            }
            
            .mobile-empty-state i {
                font-size: 50px;
                margin-bottom: 12px;
                opacity: 0.5;
            }
            
            .mobile-empty-state p {
                margin: 0;
                font-size: 13px;
            }
            
            .mobile-empty-state .hint {
                font-size: 11px;
                margin-top: 6px;
                color: #bbb;
            }
            
            /* 移动端安全区域适配 */
            .mobile-chat-view,
            .mobile-list-view {
                padding-bottom: env(safe-area-inset-bottom);
            }
            
            /* PC端隐藏footer */
            @media (min-width: 768px) {
                .footer {
                    display: none;
                }
            }
            
            /* 移动端隐藏footer */
            @media (max-width: 767px) {
                .footer {
                    display: none;
                }
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-comments text-primary mr-2"></i>
                心事社区
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-home"></i> 首页
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="message.php">
                            <i class="fas fa-envelope"></i> 消息
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="discover.php">
                            <i class="fas fa-compass"></i> 发现
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search.php">
                            <i class="fas fa-search"></i> 搜索
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i> 我的
                        </a>
                    </li>
                    <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">
                            <i class="fas fa-cog"></i> 管理
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                <div class="d-flex align-items-center">
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown">
                            <img src="assets/images/<?php echo $user['avatar']; ?>" alt="头像" class="avatar" style="width: 36px; height: 36px;">
                            <span class="ms-2"><?php echo $user['username']; ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php">个人资料</a></li>
                            <li><a class="dropdown-item" href="edit_profile.php">编辑资料</a></li>
                            <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                            <li><a class="dropdown-item" href="admin.php?tab=about"><i class="fas fa-info-circle"></i> 编辑关于</a></li>
                            <?php else: ?>
                            <li><a class="dropdown-item" href="#">设置</a></li>
                            <?php endif; ?>
                            <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                            <li><a class="dropdown-item" href="admin.php">管理后台</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="index.php?action=logout">退出登录</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- 移动端底部导航 -->
    <nav class="mobile-nav d-md-none navbar navbar-expand-lg">
        <ul class="navbar-nav w-100 d-flex justify-content-around">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-home"></i>
                    <span>首页</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="message.php">
                    <i class="fas fa-envelope"></i>
                    <span>消息</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="discover.php">
                    <i class="fas fa-compass"></i>
                    <span>发现</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="search.php">
                    <i class="fas fa-search"></i>
                    <span>搜索</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>我的</span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- 主要内容 -->
    <div class="container-fluid message-container">
        <div class="row h-100">
            <!-- 消息列表 -->
            <div class="col-md-4 message-sidebar">
                <div class="sidebar-header">
                    <h5 class="mb-0">消息</h5>
                </div>
                
                <!-- 搜索用户 -->
                <div class="search-container">
                    <form method="get" action="message.php">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="搜索用户..." name="search" value="<?php echo htmlspecialchars($search_keyword); ?>">
                            <button class="btn btn-primary" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
                
                <!-- 自定义标签页 -->
                <div class="message-tabs">
                    <button class="tab-btn active" id="chats-tab-btn" onclick="switchTab('chats')">
                        <i class="fas fa-comment-dots"></i>
                        聊天
                    </button>
                    <button class="tab-btn" id="friends-tab-btn" onclick="switchTab('friends')">
                        <i class="fas fa-user-friends"></i>
                        好友
                        <?php if (count($friend_requests) > 0): ?>
                        <span class="badge"><?php echo count($friend_requests); ?></span>
                        <?php endif; ?>
                    </button>
                    <?php if (!empty($search_keyword)): ?>
                    <button class="tab-btn active" id="search-tab-btn" onclick="switchTab('search-results')">
                        <i class="fas fa-search"></i>
                        搜索结果
                    </button>
                    <?php endif; ?>
                </div>
                
                <div class="tab-content message-tabs-content" id="messageTabsContent">
                    <!-- 聊天列表 -->
                    <div class="tab-pane fade show active" id="chats" role="tabpanel" aria-labelledby="chats-tab">
                        <?php if (!empty($message_list)): ?>
                            <?php foreach ($message_list as $item): ?>
                                <a href="message.php?user_id=<?php echo $item['user']['id']; ?>" class="message-list-item <?php echo $selected_user_id == $item['user']['id'] ? 'active' : ''; ?>">
                                    <img src="assets/images/<?php echo $item['user']['avatar']; ?>" alt="头像" class="avatar">
                                    <div class="info">
                                        <div class="name">
                                            <?php echo $item['user']['username']; ?>
                                            <?php if (isset($item['user']['is_admin']) && $item['user']['is_admin']): ?>
                                            <span class="admin-badge">管理员</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="preview"><?php echo $item['last_message']['content']; ?></div>
                                    </div>
                                    <div class="meta">
                                        <span class="time"><?php echo date('H:i', strtotime($item['last_message']['created_at'])); ?></span>
                                        <?php if ($item['unread_count'] > 0): ?>
                                        <span class="unread-badge"><?php echo $item['unread_count']; ?></span>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-envelope-open"></i>
                                <p>还没有消息</p>
                                <p class="hint">开始和朋友聊天吧！</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- 好友列表 -->
                    <div class="tab-pane fade" id="friends" role="tabpanel" aria-labelledby="friends-tab">
                        <!-- 好友请求 -->
                        <?php if (!empty($friend_requests)): ?>
                            <div class="friend-request-section">
                                <h6><i class="fas fa-user-plus"></i> 好友请求 (<?php echo count($friend_requests); ?>)</h6>
                                <?php foreach ($friend_requests as $request): ?>
                                    <div class="friend-request-item">
                                        <div class="user-info">
                                            <img src="assets/images/<?php echo $request['avatar']; ?>" alt="头像">
                                            <span class="name"><?php echo $request['username']; ?></span>
                                        </div>
                                        <div class="actions">
                                            <form method="post" action="message.php" style="display: inline;">
                                                <input type="hidden" name="action" value="accept_friend">
                                                <input type="hidden" name="friend_id" value="<?php echo $request['id']; ?>">
                                                <button type="submit" class="accept">接受</button>
                                            </form>
                                            <form method="post" action="message.php" style="display: inline;">
                                                <input type="hidden" name="action" value="reject_friend">
                                                <input type="hidden" name="friend_id" value="<?php echo $request['id']; ?>">
                                                <button type="submit" class="reject">拒绝</button>
                                            </form>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <!-- 好友列表 -->
                        <?php if (!empty($friends)): ?>
                            <?php foreach ($friends as $friend): ?>
                                <a href="message.php?user_id=<?php echo $friend['id']; ?>" class="message-list-item <?php echo $selected_user_id == $friend['id'] ? 'active' : ''; ?>">
                                    <img src="assets/images/<?php echo $friend['avatar']; ?>" alt="头像" class="avatar">
                                    <div class="info">
                                        <div class="name">
                                            <?php echo $friend['username']; ?>
                                            <?php if (isset($friend['is_admin']) && $friend['is_admin']): ?>
                                            <span class="admin-badge">管理员</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <form method="post" action="message.php" style="display: inline;" onclick="event.stopPropagation();">
                                        <input type="hidden" name="action" value="remove_friend">
                                        <input type="hidden" name="friend_id" value="<?php echo $friend['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('确定要删除这个好友吗？');">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-user-friends"></i>
                                <p>还没有好友</p>
                                <p class="hint">使用顶部搜索框添加好友</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- 搜索结果 -->
                    <?php if (!empty($search_keyword)): ?>
                    <div class="tab-pane fade show active" id="search-results" role="tabpanel" aria-labelledby="search-tab">
                        <?php if (!empty($search_results)): ?>
                            <?php foreach ($search_results as $result): ?>
                                <div class="message-list-item">
                                    <img src="assets/images/<?php echo $result['avatar']; ?>" alt="头像" class="avatar">
                                    <div class="info">
                                        <div class="name">
                                            <?php echo $result['username']; ?>
                                            <?php if (isset($result['is_admin']) && $result['is_admin']): ?>
                                            <span class="admin-badge">管理员</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="preview"><?php echo $result['email']; ?></div>
                                    </div>
                                    <div class="user-actions">
                                        <?php if (is_friend($user['id'], $result['id'])): ?>
                                            <a href="message.php?user_id=<?php echo $result['id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-comment"></i>
                                            </a>
                                        <?php elseif (has_pending_request($user['id'], $result['id'])): ?>
                                            <span class="btn btn-sm btn-secondary">已发送</span>
                                        <?php elseif (has_pending_request($result['id'], $user['id'])): ?>
                                            <span class="btn btn-sm btn-secondary">待确认</span>
                                        <?php else: ?>
                                            <form method="post" action="message.php" style="display: inline;">
                                                <input type="hidden" name="action" value="add_friend">
                                                <input type="hidden" name="friend_id" value="<?php echo $result['id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-success">
                                                    <i class="fas fa-user-plus"></i>
                                                </button>
                                            </form>
                                            <a href="message.php?user_id=<?php echo $result['id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-comment"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-search"></i>
                                <p>未找到匹配的用户</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- 消息内容 -->
            <div class="col-md-8 message-list">
                <?php if ($selected_user): ?>
                    <!-- 聊天头部 -->
                    <div class="chat-header">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/<?php echo $selected_user['avatar']; ?>" alt="头像" class="avatar" style="width: 40px; height: 40px;">
                                <div>
                                    <h6 class="mb-0"><?php echo $selected_user['username']; ?></h6>
                                    <?php if (isset($selected_user['is_admin']) && $selected_user['is_admin']): ?>
                                    <span class="admin-badge">管理员</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="user-actions">
                                <?php if (is_friend($user['id'], $selected_user['id'])): ?>
                                    <form method="post" action="message.php" style="display: inline;">
                                        <input type="hidden" name="action" value="remove_friend">
                                        <input type="hidden" name="friend_id" value="<?php echo $selected_user['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('确定要删除这个好友吗？');">
                                            <i class="fas fa-trash"></i> 移除好友
                                        </button>
                                    </form>
                                <?php elseif (!has_pending_request($user['id'], $selected_user['id']) && !has_pending_request($selected_user['id'], $user['id'])): ?>
                                    <form method="post" action="message.php" style="display: inline;">
                                        <input type="hidden" name="action" value="add_friend">
                                        <input type="hidden" name="friend_id" value="<?php echo $selected_user['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-success">
                                            <i class="fas fa-user-plus"></i> 添加好友
                                        </button>
                                    </form>
                                <?php elseif (has_pending_request($user['id'], $selected_user['id'])): ?>
                                    <span class="btn btn-sm btn-secondary">请求已发送</span>
                                <?php elseif (has_pending_request($selected_user['id'], $user['id'])): ?>
                                    <span class="btn btn-sm btn-secondary">等待确认</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- 聊天内容 -->
                    <div class="chat-messages" id="pcChatMessages" data-last-id="<?php echo !empty($messages) ? end($messages)['id'] : 0; ?>">
                        <?php 
                        foreach ($messages as $msg): 
                            $is_sent = $msg['sender_id'] == $user['id'];
                        ?>
                            <div class="message-item <?php echo $is_sent ? 'sent' : 'received'; ?>" data-id="<?php echo $msg['id']; ?>">
                                <?php if (!$is_sent): ?>
                                <img src="assets/images/<?php echo $selected_user['avatar']; ?>" alt="头像" class="message-avatar">
                                <?php endif; ?>
                                <div class="message-content-wrapper">
                                    <div class="message-bubble <?php echo $is_sent ? 'sent' : 'received'; ?>">
                                        <?php echo htmlspecialchars($msg['content']); ?>
                                    </div>
                                    <div class="message-time"><?php echo date('Y-m-d H:i', strtotime($msg['created_at'])); ?></div>
                                </div>
                                <?php if ($is_sent): ?>
                                <img src="assets/images/<?php echo $user['avatar']; ?>" alt="头像" class="message-avatar">
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- 消息输入 -->
                    <div class="message-input">
                        <form method="post" id="pcMessageForm">
                            <input type="hidden" name="receiver_id" value="<?php echo $selected_user_id; ?>">
                            <input type="hidden" name="ajax" value="1">
                            <div class="d-flex">
                                <input type="text" class="form-control flex-grow-1" placeholder="输入消息..." name="content" id="pcMessageInput" required>
                                <button type="submit" class="btn btn-primary send-btn">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="h-100 d-flex flex-column justify-content-center align-items-center">
                        <i class="fas fa-comments text-muted" style="font-size: 64px;"></i>
                        <p class="mt-3 text-muted">选择一个联系人开始聊天</p>
                        <p class="text-muted">或使用顶部搜索框查找用户</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 移动端布局 -->
    <div class="mobile-chat-container d-md-none" id="mobileChatContainer">
        <!-- 移动端列表视图 -->
        <div class="mobile-list-view" id="mobileListView">
            <div class="mobile-header">
                <h5>消息</h5>
            </div>
            
            <!-- 移动端搜索框 -->
            <div class="mobile-search">
                <form method="get" action="message.php">
                    <input type="text" placeholder="搜索用户..." name="search" value="<?php echo htmlspecialchars($search_keyword); ?>">
                    <button type="submit">搜索</button>
                </form>
            </div>
            
            <!-- 移动端标签页 -->
            <div class="mobile-tabs">
                <button class="mobile-tab-btn active" id="mobile-chats-tab" onclick="mobileSwitchTab('chats')">
                    <i class="fas fa-comment-dots"></i> 聊天
                </button>
                <button class="mobile-tab-btn" id="mobile-friends-tab" onclick="mobileSwitchTab('friends')">
                    <i class="fas fa-user-friends"></i> 好友
                    <?php if (count($friend_requests) > 0): ?>
                    <span class="badge"><?php echo count($friend_requests); ?></span>
                    <?php endif; ?>
                </button>
                <?php if (!empty($search_keyword)): ?>
                <button class="mobile-tab-btn active" id="mobile-search-tab" onclick="mobileSwitchTab('search')">
                    <i class="fas fa-search"></i> 搜索
                </button>
                <?php endif; ?>
            </div>
            
            <div class="mobile-list-content" id="mobileListContent">
                <!-- 聊天列表 -->
                <div id="mobile-chats-content">
                    <?php if (!empty($message_list)): ?>
                        <?php foreach ($message_list as $item): ?>
                            <a href="message.php?user_id=<?php echo $item['user']['id']; ?>&mobile=1" class="message-list-item" onclick="openMobileChat(<?php echo $item['user']['id']; ?>)">
                                <img src="assets/images/<?php echo $item['user']['avatar']; ?>" alt="头像" class="avatar">
                                <div class="info">
                                    <div class="name">
                                        <?php echo $item['user']['username']; ?>
                                        <?php if (isset($item['user']['is_admin']) && $item['user']['is_admin']): ?>
                                        <span class="admin-badge">管理员</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="preview"><?php echo $item['last_message']['content']; ?></div>
                                </div>
                                <div class="meta">
                                    <span class="time"><?php echo date('H:i', strtotime($item['last_message']['created_at'])); ?></span>
                                    <?php if ($item['unread_count'] > 0): ?>
                                    <span class="unread-badge"><?php echo $item['unread_count']; ?></span>
                                    <?php endif; ?>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="mobile-empty-state">
                            <i class="fas fa-envelope-open"></i>
                            <p>还没有消息</p>
                            <p class="hint">开始和朋友聊天吧</p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- 好友列表 -->
                <div id="mobile-friends-content" style="display: none;">
                    <?php if (!empty($friend_requests)): ?>
                        <div class="mobile-friend-requests">
                            <h6><i class="fas fa-user-plus"></i> 好友请求 (<?php echo count($friend_requests); ?>)</h6>
                            <?php foreach ($friend_requests as $request): ?>
                                <div class="mobile-friend-request-item">
                                    <div class="user-info">
                                        <img src="assets/images/<?php echo $request['avatar']; ?>" alt="头像">
                                        <span class="name"><?php echo $request['username']; ?></span>
                                    </div>
                                    <div class="actions">
                                        <form method="post" action="message.php" style="display: inline;">
                                            <input type="hidden" name="action" value="accept_friend">
                                            <input type="hidden" name="friend_id" value="<?php echo $request['id']; ?>">
                                            <button type="submit" class="accept">接受</button>
                                        </form>
                                        <form method="post" action="message.php" style="display: inline;">
                                            <input type="hidden" name="action" value="reject_friend">
                                            <input type="hidden" name="friend_id" value="<?php echo $request['id']; ?>">
                                            <button type="submit" class="reject">拒绝</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($friends)): ?>
                        <?php foreach ($friends as $friend): ?>
                            <a href="message.php?user_id=<?php echo $friend['id']; ?>&mobile=1" class="message-list-item" onclick="openMobileChat(<?php echo $friend['id']; ?>)">
                                <img src="assets/images/<?php echo $friend['avatar']; ?>" alt="头像" class="avatar">
                                <div class="info">
                                    <div class="name">
                                        <?php echo $friend['username']; ?>
                                        <?php if (isset($friend['is_admin']) && $friend['is_admin']): ?>
                                        <span class="admin-badge">管理员</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="mobile-empty-state">
                            <i class="fas fa-user-friends"></i>
                            <p>还没有好友</p>
                            <p class="hint">使用搜索框添加好友</p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- 搜索结果 -->
                <?php if (!empty($search_keyword)): ?>
                <div id="mobile-search-content">
                    <?php if (!empty($search_results)): ?>
                        <?php foreach ($search_results as $result): ?>
                            <div class="message-list-item">
                                <img src="assets/images/<?php echo $result['avatar']; ?>" alt="头像" class="avatar">
                                <div class="info">
                                    <div class="name">
                                        <?php echo $result['username']; ?>
                                        <?php if (isset($result['is_admin']) && $result['is_admin']): ?>
                                        <span class="admin-badge">管理员</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="preview"><?php echo $result['email']; ?></div>
                                </div>
                                <div class="actions" style="display: flex; gap: 5px;">
                                    <?php if (is_friend($user['id'], $result['id'])): ?>
                                        <a href="message.php?user_id=<?php echo $result['id']; ?>&mobile=1" class="btn btn-sm btn-primary" onclick="openMobileChat(<?php echo $result['id']; ?>)">
                                            <i class="fas fa-comment"></i>
                                        </a>
                                    <?php elseif (has_pending_request($user['id'], $result['id'])): ?>
                                        <span class="btn btn-sm btn-secondary">已发送</span>
                                    <?php elseif (has_pending_request($result['id'], $user['id'])): ?>
                                        <span class="btn btn-sm btn-secondary">待确认</span>
                                    <?php else: ?>
                                        <form method="post" action="message.php" style="display: inline;">
                                            <input type="hidden" name="action" value="add_friend">
                                            <input type="hidden" name="friend_id" value="<?php echo $result['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-success">
                                                <i class="fas fa-user-plus"></i>
                                            </button>
                                        </form>
                                        <a href="message.php?user_id=<?php echo $result['id']; ?>&mobile=1" class="btn btn-sm btn-primary" onclick="openMobileChat(<?php echo $result['id']; ?>)">
                                            <i class="fas fa-comment"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="mobile-empty-state">
                            <i class="fas fa-search"></i>
                            <p>未找到匹配的用户</p>
                        </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- 移动端聊天视图 -->
        <div class="mobile-chat-view" id="mobileChatView">
            <div class="chat-header">
                <button class="back-btn" onclick="closeMobileChat()">
                    <i class="fas fa-arrow-left"></i>
                </button>
                <div class="user-info">
                    <img src="assets/images/<?php echo $selected_user ? $selected_user['avatar'] : ''; ?>" alt="头像" id="mobileChatAvatar">
                    <div>
                        <div class="name" id="mobileChatUsername"><?php echo $selected_user ? $selected_user['username'] : ''; ?></div>
                        <?php if ($selected_user && isset($selected_user['is_admin']) && $selected_user['is_admin']): ?>
                        <span class="admin-badge">管理员</span>
                        <?php endif; ?>
                    </div>
                </div>
                <button class="action-btn" id="mobileChatActionBtn">
                    <?php if ($selected_user): ?>
                        <?php if (is_friend($user['id'], $selected_user['id'])): ?>
                            <i class="fas fa-user-minus"></i>
                        <?php elseif (!has_pending_request($user['id'], $selected_user['id']) && !has_pending_request($selected_user['id'], $user['id'])): ?>
                            <i class="fas fa-user-plus"></i>
                        <?php endif; ?>
                    <?php endif; ?>
                </button>
            </div>
            
            <div class="chat-messages" id="mobileChatMessages">
                <?php if ($selected_user): ?>
                    <?php 
                    foreach ($messages as $msg): 
                    ?>
                        <div class="message-bubble-wrapper <?php echo $msg['sender_id'] == $user['id'] ? 'sent' : ''; ?>" data-id="<?php echo $msg['id']; ?>">
                            <?php if ($msg['sender_id'] != $user['id']): ?>
                            <img src="assets/images/<?php echo $selected_user['avatar']; ?>" alt="头像" class="avatar">
                            <?php endif; ?>
                            <div class="message-bubble <?php echo $msg['sender_id'] == $user['id'] ? 'sent' : 'received'; ?>">
                                <?php echo htmlspecialchars($msg['content']); ?>
                                <div class="message-time"><?php echo date('Y-m-d H:i', strtotime($msg['created_at'])); ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="mobile-empty-state">
                        <i class="fas fa-comments"></i>
                        <p>选择一个联系人开始聊天</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <form class="chat-input" method="post" id="mobileMessageForm">
                <input type="hidden" name="receiver_id" value="<?php echo $selected_user_id; ?>">
                <input type="hidden" name="ajax" value="1">
                <input type="text" placeholder="输入消息..." name="content" id="mobileMessageInput" required>
                <button type="submit">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </form>
        </div>
    </div>

    <!-- 页脚 -->


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        // 标签页切换功能
        function switchTab(tabId) {
            // 移除所有标签按钮的active状态
            document.querySelectorAll('.message-tabs .tab-btn').forEach(function(btn) {
                btn.classList.remove('active');
            });

            // 隐藏所有标签内容
            document.querySelectorAll('.tab-content > div').forEach(function(content) {
                content.classList.remove('show', 'active');
            });

            // 激活选中的标签按钮
            var targetBtn = document.getElementById(tabId + '-tab-btn') || 
                           document.getElementById('search-tab-btn');
            if (targetBtn) {
                targetBtn.classList.add('active');
            }

            // 显示对应的标签内容
            var targetContent = document.getElementById(tabId);
            if (targetContent) {
                targetContent.classList.add('show', 'active');
            }

            // 存储当前激活的标签到sessionStorage
            sessionStorage.setItem('activeMessageTab', tabId);
        }

        // 页面加载时恢复上次激活的标签
        document.addEventListener('DOMContentLoaded', function() {
            var savedTab = sessionStorage.getItem('activeMessageTab');
            if (savedTab) {
                switchTab(savedTab);
            }

            // 如果有搜索关键词，默认显示搜索结果标签
            <?php if (!empty($search_keyword)): ?>
            switchTab('search-results');
            <?php endif; ?>
            
            // 移动端初始化
            initMobileView();
        });
        
        // 移动端视图初始化
        function initMobileView() {
            var isMobile = window.innerWidth < 768;
            var urlParams = new URLSearchParams(window.location.search);
            var hasMobileParam = urlParams.has('mobile');
            var hasUserId = <?php echo $selected_user_id > 0 ? 'true' : 'false'; ?>;
            
            if (isMobile) {
                document.getElementById('mobileChatContainer').classList.add('active');
                
                if (hasUserId && hasMobileParam) {
                    document.getElementById('mobileListView').style.display = 'none';
                    document.getElementById('mobileChatView').classList.add('active');
                    scrollMobileChatToBottom();
                } else {
                    document.getElementById('mobileListView').style.display = 'flex';
                    document.getElementById('mobileChatView').classList.remove('active');
                }
                
                // 设置移动端标签页
                <?php if (!empty($search_keyword)): ?>
                mobileSwitchTab('search');
                <?php endif; ?>
            }
        }
        
        // 移动端标签页切换
        function mobileSwitchTab(tabId) {
            // 移除所有移动端标签按钮的active状态
            document.querySelectorAll('.mobile-tabs .mobile-tab-btn').forEach(function(btn) {
                btn.classList.remove('active');
            });
            
            // 激活选中的标签按钮
            var targetBtn = document.getElementById('mobile-' + tabId + '-tab');
            if (targetBtn) {
                targetBtn.classList.add('active');
            }
            
            // 隐藏所有移动端列表内容
            document.getElementById('mobile-chats-content').style.display = 'none';
            document.getElementById('mobile-friends-content').style.display = 'none';
            if (document.getElementById('mobile-search-content')) {
                document.getElementById('mobile-search-content').style.display = 'none';
            }
            
            // 显示对应的列表内容
            var targetContent = document.getElementById('mobile-' + tabId + '-content');
            if (targetContent) {
                targetContent.style.display = 'block';
            }
        }
        
        // 打开移动端聊天视图
        function openMobileChat(userId) {
            event.preventDefault();
            var url = new URL(window.location.href);
            url.searchParams.set('user_id', userId);
            url.searchParams.set('mobile', '1');
            window.location.href = url.toString();
        }
        
        // 关闭移动端聊天视图
        function closeMobileChat() {
            var url = new URL(window.location.href);
            url.searchParams.delete('user_id');
            url.searchParams.delete('mobile');
            window.location.href = url.toString();
        }
        
        // 移动端聊天滚动到底部
        function scrollMobileChatToBottom() {
            var chatMessages = document.getElementById('mobileChatMessages');
            if (chatMessages) {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        }

        // 自动滚动到底部
        function scrollToBottom() {
            // PC端聊天滚动
            var pcChatContainer = document.querySelector('.message-list .chat-messages');
            if (pcChatContainer) {
                pcChatContainer.scrollTop = pcChatContainer.scrollHeight;
            }
            
            // 移动端聊天滚动
            var mobileChatMessages = document.getElementById('mobileChatMessages');
            if (mobileChatMessages) {
                mobileChatMessages.scrollTop = mobileChatMessages.scrollHeight;
            }
        }
        
        // 页面加载完成后滚动到底部
        $(document).ready(function() {
            scrollToBottom();
            
            // 启动消息轮询
            startMessagePolling();
        });
        
        // 实时消息轮询
        var messagePollingInterval = null;
        
        function startMessagePolling() {
            var userId = <?php echo $selected_user_id; ?>;
            if (userId <= 0) return;
            
            // 每2秒检查一次新消息
            messagePollingInterval = setInterval(function() {
                fetchNewMessages(userId);
            }, 2000);
        }
        
        function stopMessagePolling() {
            if (messagePollingInterval) {
                clearInterval(messagePollingInterval);
                messagePollingInterval = null;
            }
        }
        
        // 获取新消息
        function fetchNewMessages(chatUserId) {
            var pcChatMessages = document.getElementById('pcChatMessages');
            var mobileChatMessages = document.getElementById('mobileChatMessages');
            var lastId = 0;
            
            if (pcChatMessages) {
                lastId = parseInt(pcChatMessages.getAttribute('data-last-id')) || 0;
            } else if (mobileChatMessages) {
                var lastMsg = mobileChatMessages.querySelector('.message-bubble-wrapper:last-child');
                if (lastMsg) {
                    lastId = parseInt(lastMsg.getAttribute('data-id')) || 0;
                }
            }
            
            fetch('message.php?action=get_messages&user_id=' + chatUserId + '&last_id=' + lastId)
                .then(function(response) { return response.json(); })
                .then(function(data) {
                    if (data.success && data.messages && data.messages.length > 0) {
                        data.messages.forEach(function(msg) {
                            addMessageToChat(msg, chatUserId);
                        });
                    }
                })
                .catch(function(error) {
                    console.log('获取消息失败:', error);
                });
        }
        
        // 添加消息到聊天界面
        function addMessageToChat(msg, chatUserId) {
            var currentUserId = <?php echo $user['id']; ?>;
            var isSent = parseInt(msg.sender_id) === currentUserId;
            var selectedUser = <?php echo json_encode($selected_user); ?>;
            var currentUser = <?php echo json_encode($user); ?>;
            
            var pcChatMessages = document.getElementById('pcChatMessages');
            var mobileChatMessages = document.getElementById('mobileChatMessages');
            
            // 检查消息是否已存在，防止重复添加
            if (pcChatMessages) {
                var existingMsg = pcChatMessages.querySelector('.message-item[data-id="' + msg.id + '"]');
                if (existingMsg) {
                    return; // 消息已存在，跳过
                }
            }
            
            if (mobileChatMessages) {
                var existingMobileMsg = mobileChatMessages.querySelector('.message-bubble-wrapper[data-id="' + msg.id + '"]');
                if (existingMobileMsg) {
                    return; // 消息已存在，跳过
                }
            }
            
            var messageHtml = '';
            var msgDate = new Date(msg.created_at);
            var time = msgDate.getFullYear() + '-' + 
                       String(msgDate.getMonth() + 1).padStart(2, '0') + '-' + 
                       String(msgDate.getDate()).padStart(2, '0') + ' ' + 
                       String(msgDate.getHours()).padStart(2, '0') + ':' + 
                       String(msgDate.getMinutes()).padStart(2, '0');
            
            if (isSent) {
                // 发送的消息
                messageHtml = `
                    <div class="message-item sent" data-id="${msg.id}">
                        <div class="message-content-wrapper">
                            <div class="message-bubble sent">${escapeHtml(msg.content)}</div>
                            <div class="message-time">${time}</div>
                        </div>
                        <img src="assets/images/${currentUser.avatar}" alt="头像" class="message-avatar">
                    </div>
                `;
            } else {
                // 接收的消息
                messageHtml = `
                    <div class="message-item received" data-id="${msg.id}">
                        <img src="assets/images/${selectedUser.avatar}" alt="头像" class="message-avatar">
                        <div class="message-content-wrapper">
                            <div class="message-bubble received">${escapeHtml(msg.content)}</div>
                            <div class="message-time">${time}</div>
                        </div>
                    </div>
                `;
            }
            
            if (pcChatMessages) {
                pcChatMessages.insertAdjacentHTML('beforeend', messageHtml);
                pcChatMessages.setAttribute('data-last-id', msg.id);
                pcChatMessages.scrollTop = pcChatMessages.scrollHeight;
            }
            
            if (mobileChatMessages) {
                var mobileMessageHtml = `
                    <div class="message-bubble-wrapper ${isSent ? 'sent' : ''}" data-id="${msg.id}">
                        ${!isSent ? `<img src="assets/images/${selectedUser.avatar}" alt="头像" class="avatar">` : ''}
                        <div class="message-bubble ${isSent ? 'sent' : 'received'}">
                            ${escapeHtml(msg.content)}
                            <div class="message-time">${time}</div>
                        </div>
                    </div>
                `;
                mobileChatMessages.insertAdjacentHTML('beforeend', mobileMessageHtml);
                mobileChatMessages.scrollTop = mobileChatMessages.scrollHeight;
            }
        }
        
        // HTML转义函数
        function escapeHtml(text) {
            var div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        // PC端表单提交
        document.getElementById('pcMessageForm').addEventListener('submit', function(e) {
            e.preventDefault();
            var form = this;
            var input = document.getElementById('pcMessageInput');
            var content = input.value.trim();
            
            if (!content) return;
            
            var formData = new FormData(form);
            
            fetch('message.php', {
                method: 'POST',
                body: formData
            })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (data.success) {
                    input.value = '';
                    var pcChatMessages = document.getElementById('pcChatMessages');
                    var currentUser = <?php echo json_encode($user); ?>;
                    
                    if (pcChatMessages) {
                        var time = new Date(data.created_at);
                        var timeStr = time.getFullYear() + '-' +
                            String(time.getMonth() + 1).padStart(2, '0') + '-' +
                            String(time.getDate()).padStart(2, '0') + ' ' +
                            String(time.getHours()).padStart(2, '0') + ':' +
                            String(time.getMinutes()).padStart(2, '0');
                        
                        var messageHtml = `
                            <div class="message-item sent" data-id="${data.message_id}">
                                <div class="message-content-wrapper">
                                    <div class="message-bubble sent">${escapeHtml(content)}</div>
                                    <div class="message-time">${timeStr}</div>
                                </div>
                                <img src="assets/images/${currentUser.avatar}" alt="头像" class="message-avatar">
                            </div>
                        `;
                        pcChatMessages.insertAdjacentHTML('beforeend', messageHtml);
                        pcChatMessages.setAttribute('data-last-id', data.message_id);
                        pcChatMessages.scrollTop = pcChatMessages.scrollHeight;
                    }
                }
            })
            .catch(function(error) {
                console.log('发送消息失败:', error);
                // 失败时使用传统表单提交
                form.submit();
            });
        });
        
        // 移动端表单提交
        document.getElementById('mobileMessageForm').addEventListener('submit', function(e) {
            e.preventDefault();
            var form = this;
            var input = document.getElementById('mobileMessageInput');
            var content = input.value.trim();
            
            if (!content) return;
            
            var formData = new FormData(form);
            
            fetch('message.php', {
                method: 'POST',
                body: formData
            })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (data.success) {
                    input.value = '';
                    var mobileChatMessages = document.getElementById('mobileChatMessages');
                    var currentUser = <?php echo json_encode($user); ?>;
                    
                    if (mobileChatMessages) {
                        var time = new Date(data.created_at);
                        var timeStr = time.getFullYear() + '-' +
                            String(time.getMonth() + 1).padStart(2, '0') + '-' +
                            String(time.getDate()).padStart(2, '0') + ' ' +
                            String(time.getHours()).padStart(2, '0') + ':' +
                            String(time.getMinutes()).padStart(2, '0');
                        
                        var mobileMessageHtml = `
                            <div class="message-bubble-wrapper sent" data-id="${data.message_id}">
                                <div class="message-bubble sent">
                                    ${escapeHtml(content)}
                                    <div class="message-time">${timeStr}</div>
                                </div>
                            </div>
                        `;
                        mobileChatMessages.insertAdjacentHTML('beforeend', mobileMessageHtml);
                        mobileChatMessages.scrollTop = mobileChatMessages.scrollHeight;
                    }
                }
            })
            .catch(function(error) {
                console.log('发送消息失败:', error);
                // 失败时使用传统表单提交
                form.submit();
            });
        });
        
        // 页面离开时停止轮询
        window.addEventListener('beforeunload', function() {
            stopMessagePolling();
        });
    </script>
</body>
</html>