<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', '社区');
define('DB_USER', '社区');
define('DB_PASS', 'lcy');

// 网站配置
define('SITE_NAME', '领里社区');
define('SITE_URL', 'http://139.155.96.231//');

// 上传配置
define('UPLOAD_DIR', 'assets/images/uploads/');
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB

// 安全配置
define('SECRET_KEY', 'd8e313f335b1743fcadada37665b2f86043171a805e42d5d62fd6b1a335c79c8');