<?php
session_start();

// 加载配置和数据库连接
if (file_exists('config.php')) {
    require_once 'config.php';
    require_once 'database.php';
    require_once 'includes/functions.php';
} else {
    header('Location: install.php');
    exit;
}

// 检查是否已登录
if (is_logged_in()) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = '请填写所有必填字段';
    } elseif (strlen($username) < 3 || strlen($username) > 20) {
        $error = '用户名长度应在3-20个字符之间';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = '请输入有效的邮箱地址';
    } elseif (strlen($password) < 6) {
        $error = '密码长度至少为6个字符';
    } elseif ($password != $confirm_password) {
        $error = '两次输入的密码不一致';
    } else {
        $result = register($username, $email, $password);
        if ($result === true) {
            header('Location: index.php');
            exit;
        } else {
            $error = $result;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>心事社区 - 注册</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
          background-image: url(bj.jpg);
                background-size: cover; /* 修改为cover，使图片铺满满屏 */
                background-attachment: fixed; /* 可选，使背景图片固定不随页面滚动 */
                margin: 0; /* 去除默认边距 */
                padding: 0; /* 去除默认内边距 */
          
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .register-container {
            max-width: 400px;
            width: 90%;
            
            padding: 20px;
        }
        @media (max-width: 576px) {
            .register-container {
                padding: 15px;
            }
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo h1 {
            color: #007bff;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-control {
            border-radius: 20px;
            padding: 12px 20px;
        }
		
        .btn-primary {
			
            border-radius: 20px;
            padding: 12px;
            font-weight: bold;
        }
        .text-center {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="logo">
            <h1>心事注册</h1>
            
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="post" action="register.php">
            <div class="form-group">
                <label for="username" class="form-label">用户名:</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="请输入用户名" required>
            </div>
            <div class="form-group">
                <label for="email" class="form-label">邮箱:</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="请输入邮箱" required>
            </div>
            <div class="form-group">
                <label for="password" class="form-label">密码:</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="请输入密码" required>
            </div>
            <div class="form-group">
                <label for="confirm_password" class="form-label">确认密码:</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="请确认密码" required>
            </div>
            <button type="submit" class="btn btn-primary w-50">注册</button>
            <div class="text-center">
                <p>已有账号？ <a href="login.php">立即登录</a></p>
            </div>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>