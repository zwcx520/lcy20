<?php
session_start();

// 加载配置和数据库连接
if (file_exists('config.php')) {
    require_once 'config.php';
    require_once 'database.php';
} else {
    header('Location: install.php');
    exit;
}

// 简单的用户登录状态管理
$user = null;
if (isset($_SESSION['user_id'])) {
    $user = db()->fetch("SELECT * FROM users WHERE id = ?", [$_SESSION['user_id']]);
}

// 获取热门帖子
$hot_posts = db()->fetchAll("SELECT p.*, u.username, u.avatar FROM posts p JOIN users u ON p.user_id = u.id ORDER BY p.likes DESC LIMIT 10");

// 获取推荐用户
$recommended_users = db()->fetchAll("SELECT * FROM users WHERE id != ? ORDER BY RAND() LIMIT 10", [$user['id'] ?? 0]);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>心事社区 - 发现</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
background-image: url(bj.jpg);
                 background-size: cover; /* 修改为cover，使图片铺满满屏 */
                 background-attachment: fixed; /* 可选，使背景图片固定不随页面滚动 */
                 margin: 0; /* 去除默认边距 */
                 padding: 0; /* 去除默认内边距 */
            
        }
        .navbar {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .nav-link {
            color: #333;
        }
        .nav-link.active {
            color: #007bff;
            font-weight: bold;
        }
        .navbar-toggler {
            padding: 0.15rem 0.35rem;
            font-size: 0.75rem;
            line-height: 1;
            align-self: center;
        }
        .navbar-toggler-icon {
            width: 1em;
            height: 1em;
        }
        @media (max-width: 576px) {
            .navbar {
                height: 60px;
            }
            .navbar .container {
                height: 100%;
                display: flex;
                align-items: center;
            }
            .navbar .d-flex {
                margin-top: 10px;
                width: 100%;
            }
            .navbar .d-flex .btn {
                flex: 1;
                margin: 0 5px;
            }
            .navbar .d-flex .btn:first-child {
                margin-left: 0;
            }
            .navbar .d-flex .btn:last-child {
                margin-right: 0;
            }
            .dropdown-menu {
                position: static !important;
                float: none !important;
                width: 100% !important;
                margin-top: 0 !important;
            }
            .navbar-collapse .navbar-nav {
                display: none !important;
            }
        }
        .post-card {
            
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            padding: 20px;
        }
        .post-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        .avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 15px;
        }
        .post-content {
            margin-bottom: 15px;
        }
        .post-image {
            max-width: 100%;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .post-actions {
            display: flex;
            justify-content: space-around;
            padding-top: 15px;
            border-top: 1px solid #e9ecef;
        }
        .action-btn {
            background: none;
            border: none;
            color: #6c757d;
            cursor: pointer;
            display: flex;
            align-items: center;
        }
        .action-btn:hover {
            color: #007bff;
        }
        .action-btn i {
            margin-right: 5px;
        }
        .user-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 15px;
            padding: 15px;
        }
        .user-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .user-info {
            display: flex;
            align-items: center;
        }
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 10px;
        }
        .user-details h6 {
            margin: 0;
        }
        .user-details p {
            margin: 0;
            font-size: 12px;
            color: #6c757d;
        }
        .btn-follow {
            border-radius: 20px;
            font-size: 12px;
        }
        .section-title {
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #007bff;
        }
        .footer {
            background-color: white;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
            padding: 20px 0;
            margin-top: 40px;
        }
        /* 移动端底部导航 */
        .mobile-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: white;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
            z-index: 1000;
            height: 60px;
        }
        .mobile-nav .navbar-nav {
            display: flex;
            flex-direction: row;
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
        }
        .mobile-nav .nav-item {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .mobile-nav .nav-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 0;
            color: #6c757d;
            height: 100%;
            width: 100%;
        }
        .mobile-nav .nav-link.active {
            color: #007bff;
        }
        .mobile-nav .nav-link i {
            font-size: 18px;
            margin-bottom: 2px;
        }
        .mobile-nav .nav-link span {
            font-size: 12px;
        }
        /* 为移动端内容添加底部边距，避免被导航栏遮挡 */
        @media (max-width: 767px) {
            .container {
                margin-bottom: 70px;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-comments text-primary mr-2"></i>
                心事社区
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-home"></i> 首页
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="message.php">
                            <i class="fas fa-envelope"></i> 消息
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="discover.php">
                            <i class="fas fa-compass"></i> 发现
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i> 我的
                        </a>
                    </li>
                    <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">
                            <i class="fas fa-cog"></i> 管理
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                <div class="d-flex align-items-center">
                    <?php if ($user): ?>
                        <div class="dropdown">
                            <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown">
                                <img src="assets/images/<?php echo $user['avatar']; ?>" alt="头像" class="avatar" style="width: 36px; height: 36px;">
                                <span class="ms-2"><?php echo $user['username']; ?></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="profile.php">个人资料</a></li>
                                <li><a class="dropdown-item" href="edit_profile.php">编辑资料</a></li>
                                <li><a class="dropdown-item" href="#">设置</a></li>
                                <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                                <li><a class="dropdown-item" href="admin.php">管理后台</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="index.php?action=logout">退出登录</a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <div class="d-flex w-100" style="gap: 10px;">
                            <a href="login.php" class="btn btn-outline-primary flex-grow-1">登录</a>
                            <a href="register.php" class="btn btn-primary flex-grow-1">注册</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- 移动端底部导航 -->
    <nav class="mobile-nav d-md-none navbar navbar-expand-lg">
        <ul class="navbar-nav w-100 d-flex justify-content-around">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-home"></i>
                    <span>首页</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="message.php">
                    <i class="fas fa-envelope"></i>
                    <span>消息</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="discover.php">
                    <i class="fas fa-compass"></i>
                    <span>发现</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>我的</span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- 主要内容 -->
    <div class="container py-4">
        <div class="row">
            <div class="col-md-8">
                <!-- 热门帖子 -->
                <div class="mb-4">
                    <h4 class="section-title">
                        <i class="fas fa-fire text-danger"></i> 热门帖子
                    </h4>
                    
                    <?php foreach ($hot_posts as $post): ?>
                        <div class="post-card">
                            <div class="post-header">
                                <img src="assets/images/<?php echo $post['avatar']; ?>" alt="头像" class="avatar">
                                <div>
                                    <h5 class="mb-0"><?php echo $post['username']; ?></h5>
                                    <p class="text-muted mb-0"><?php echo date('Y-m-d H:i', strtotime($post['created_at'])); ?></p>
                                </div>
                            </div>
                            <div class="post-content">
                                <?php echo $post['content']; ?>
                            </div>
                            <?php if ($post['image']): ?>
                                <?php $images = explode(',', $post['image']); ?>
                                <div class="row">
                                    <?php foreach ($images as $img): ?>
                                        <div class="col-md-6 mb-3">
                                            <img src="assets/images/uploads/<?php echo $img; ?>" alt="帖子图片" class="post-image w-100">
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                            <div class="post-actions">
                                <button class="action-btn">
                                    <i class="far fa-heart"></i> 点赞 (<?php echo $post['likes']; ?>)
                                </button>
                                <button class="action-btn">
                                    <i class="far fa-comment"></i> 评论 (<?php echo $post['comments']; ?>)
                                </button>
                                <button class="action-btn">
                                    <i class="far fa-share-square"></i> 分享
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <?php if (empty($hot_posts)): ?>
                        <div class="post-card text-center">
                            <i class="fas fa-fire text-muted" style="font-size: 48px;"></i>
                            <p class="mt-3 text-muted">还没有热门帖子</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- 侧边栏 -->
            <div class="col-md-4">
                <!-- 推荐用户 -->
                <div class="mb-4">
                    <h4 class="section-title">
                        <i class="fas fa-users text-primary"></i> 推荐用户
                    </h4>
                    
                    <?php foreach ($recommended_users as $recommended_user): ?>
                        <div class="user-card">
                            <div class="user-header">
                                <div class="user-info">
                                    <img src="assets/images/<?php echo $recommended_user['avatar']; ?>" alt="头像" class="user-avatar">
                                    <div class="user-details">
                                        <h6><?php echo $recommended_user['username']; ?></h6>
                                        <p><?php echo $recommended_user['email']; ?></p>
                                    </div>
                                </div>
                                <button class="btn btn-primary btn-follow">
                                    <i class="fas fa-plus"></i> 关注
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <?php if (empty($recommended_users)): ?>
                        <div class="user-card text-center">
                            <i class="fas fa-user-plus text-muted" style="font-size: 48px;"></i>
                            <p class="mt-3 text-muted">还没有推荐用户</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- 热门话题 -->
                <div>
                    <h4 class="section-title">
                        <i class="fas fa-hashtag text-success"></i> 热门话题
                    </h4>
                    <div class="card">
                        <div class="list-group list-group-flush">
                            <a href="#" class="list-group-item list-group-item-action">
                                <span class="badge bg-primary rounded-pill float-end">128</span>
                                #技术分享
                            </a>
                            <a href="#" class="list-group-item list-group-item-action">
                                <span class="badge bg-primary rounded-pill float-end">96</span>
                                #生活感悟
                            </a>
                            <a href="#" class="list-group-item list-group-item-action">
                                <span class="badge bg-primary rounded-pill float-end">85</span>
                                #学习交流
                            </a>
                            <a href="#" class="list-group-item list-group-item-action">
                                <span class="badge bg-primary rounded-pill float-end">72</span>
                                #兴趣爱好
                            </a>
                            <a href="#" class="list-group-item list-group-item-action">
                                <span class="badge bg-primary rounded-pill float-end">64</span>
                                #职场经验
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 页脚 -->
    <footer class="footer">
        <div class="container text-center">
            <p class="mb-0">© 2026 心事社区 版权所有</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        // 关注用户功能
        $('.btn-follow').on('click', function() {
            $(this).toggleClass('btn-primary btn-success');
            if ($(this).hasClass('btn-success')) {
                $(this).html('<i class="fas fa-check"></i> 已关注');
            } else {
                $(this).html('<i class="fas fa-plus"></i> 关注');
            }
        });
    </script>
</body>
</html>