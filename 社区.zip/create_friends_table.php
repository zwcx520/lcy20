<?php
// 创建好友关系表
if (file_exists('config.php')) {
    require_once 'config.php';
    require_once 'database.php';
} else {
    die('配置文件不存在');
}

try {
    // 创建好友关系表
    db()->query("CREATE TABLE IF NOT EXISTS `friends` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT UNSIGNED NOT NULL,
        `friend_id` INT UNSIGNED NOT NULL,
        `status` TINYINT(1) DEFAULT 0,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY `unique_friendship` (`user_id`, `friend_id`),
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
        FOREIGN KEY (`friend_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    echo '好友关系表创建成功！';
} catch (Exception $e) {
    echo '创建表失败: ' . $e->getMessage();
}
?>