<?php
session_start();

// 加载配置和数据库连接
if (file_exists('config.php')) {
    require_once 'config.php';
    require_once 'database.php';
} else {
    header('Location: install.php');
    exit;
}

// 处理删除帖子请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_post') {
    if (isset($_SESSION['user_id'])) {
        $post_id = $_POST['post_id'];
        $user_id = $_SESSION['user_id'];
        
        // 验证帖子是否存在且属于当前用户
        $post = db()->fetch("SELECT * FROM posts WHERE id = ? AND user_id = ?", [$post_id, $user_id]);
        if ($post) {
            // 删除帖子相关的图片
            if (!empty($post['image'])) {
                $images = explode(',', $post['image']);
                foreach ($images as $img) {
                    $image_path = 'assets/images/uploads/' . $img;
                    if (file_exists($image_path)) {
                        unlink($image_path);
                    }
                }
            }
            // 删除帖子相关的评论
            db()->query("DELETE FROM comments WHERE post_id = ?", [$post_id]);
            // 删除帖子
            db()->query("DELETE FROM posts WHERE id = ?", [$post_id]);
            echo 'success';
            exit;
        }
    }
    echo 'error';
    exit;
}

// 简单的用户登录状态管理
$user = null;
if (isset($_SESSION['user_id'])) {
    $user = db()->fetch("SELECT * FROM users WHERE id = ?", [$_SESSION['user_id']]);
} else {
    header('Location: index.php');
    exit;
}

// 获取用户的帖子
$user_posts = db()->fetchAll("SELECT * FROM posts WHERE user_id = ? ORDER BY created_at DESC", [$user['id']]);

// 获取用户的关注数和粉丝数
$following_count = db()->fetch("SELECT COUNT(*) as count FROM follows WHERE follower_id = ?", [$user['id']]);
$followers_count = db()->fetch("SELECT COUNT(*) as count FROM follows WHERE following_id = ?", [$user['id']]);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>心事社区 - 我的</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
background-image: url(bj.jpg);
                 background-size: cover; /* 修改为cover，使图片铺满满屏 */
                 background-attachment: fixed; /* 可选，使背景图片固定不随页面滚动 */
                 margin: 0; /* 去除默认边距 */
                 padding: 0; /* 去除默认内边距 */
            
        }
        .navbar {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .nav-link {
            color: #333;
        }
        .nav-link.active {
            color: #007bff;
            font-weight: bold;
        }
        .navbar-toggler {
            padding: 0.15rem 0.35rem;
            font-size: 0.75rem;
            line-height: 1;
            align-self: center;
        }
        .navbar-toggler-icon {
            width: 1em;
            height: 1em;
        }
        @media (max-width: 576px) {
            .navbar {
                height: 60px;
            }
            .navbar .container {
                height: 100%;
                display: flex;
                align-items: center;
            }
            .navbar .d-flex {
                margin-top: 10px;
                width: 100%;
            }
            .navbar .d-flex .btn {
                flex: 1;
                margin: 0 5px;
            }
            .navbar .d-flex .btn:first-child {
                margin-left: 0;
            }
            .navbar .d-flex .btn:last-child {
                margin-right: 0;
            }
            .dropdown-menu {
                position: static !important;
                float: none !important;
                width: 100% !important;
                margin-top: 0 !important;
            }
            .navbar-collapse .navbar-nav {
                display: none !important;
            }
        }
        .profile-header {
        
            
            
            
            margin-bottom: 20px;
        }
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #007bff;
        }
        .profile-info {
            margin-top: 20px;
        }
        .profile-stats {
            display: flex;
            margin-top: 20px;
        }
        .stat-item {
            margin-right: 30px;
        }
        .stat-number {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        .stat-label {
            font-size: 14px;
            color: #6c757d;
        }
        .nav-tabs {
            margin-bottom: 20px;
        }
        .tab-content {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 20px;
        }
        .post-card {
            border-bottom: 1px solid #e9ecef;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        .post-card:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        .post-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 10px;
        }
        .post-content {
            margin-bottom: 15px;
        }
        .post-image {
            max-width: 100%;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .post-actions {
            display: flex;
            justify-content: space-around;
            padding-top: 15px;
            border-top: 1px solid #e9ecef;
        }
        .action-btn {
            background: none;
            border: none;
            color: #6c757d;
            cursor: pointer;
            display: flex;
            align-items: center;
        }
        .action-btn:hover {
            color: #007bff;
        }
        .action-btn i {
            margin-right: 5px;
        }
        .footer {
            background-color: white;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
            padding: 20px 0;
            margin-top: 40px;
        }
        /* 移动端底部导航 */
        .mobile-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: white;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
            z-index: 1000;
            height: 60px;
        }
        .mobile-nav .navbar-nav {
            display: flex;
            flex-direction: row;
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
        }
        .mobile-nav .nav-item {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .mobile-nav .nav-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 0;
            color: #6c757d;
            height: 100%;
            width: 100%;
        }
        .mobile-nav .nav-link.active {
            color: #007bff;
        }
        .mobile-nav .nav-link i {
            font-size: 18px;
            margin-bottom: 2px;
        }
        .mobile-nav .nav-link span {
            font-size: 12px;
        }
        /* 为移动端内容添加底部边距，避免被导航栏遮挡 */
        @media (max-width: 767px) {
            .container {
                margin-bottom: 70px;
            }
        }
    </style>
</head>
<body>
    	<audio autoplay="true"  loop="loop" src="yy.mp3"></audio>
	
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-comments text-primary mr-2"></i>
                心事社区
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-home"></i> 首页
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="message.php">
                            <i class="fas fa-envelope"></i> 消息
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="discover.php">
                            <i class="fas fa-compass"></i> 发现
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search.php">
                            <i class="fas fa-search"></i> 搜索
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="profile.php">
                            <i class="fas fa-user"></i> 我的
                        </a>
                    </li>
                    <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">
                            <i class="fas fa-cog"></i> 管理
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                <div class="d-flex align-items-center">
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown">
                            <img src="assets/images/<?php echo $user['avatar']; ?>" alt="头像" class="avatar" style="width: 36px; height: 36px;">
                            <span class="ms-2"><?php echo $user['username']; ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php">个人资料</a></li>
                            <li><a class="dropdown-item" href="edit_profile.php">编辑资料</a></li>
                            <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                            <li><a class="dropdown-item" href="admin.php?tab=about"><i class="fas fa-info-circle"></i> 编辑关于</a></li>
                            <?php else: ?>
                            <li><a class="dropdown-item" href="#">设置</a></li>
                            <?php endif; ?>
                            <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                            <li><a class="dropdown-item" href="admin.php">管理后台</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="index.php?action=logout">退出登录</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- 移动端底部导航 -->
    <nav class="mobile-nav d-md-none navbar navbar-expand-lg">
        <ul class="navbar-nav w-100 d-flex justify-content-around">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-home"></i>
                    <span>首页</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="message.php">
                    <i class="fas fa-envelope"></i>
                    <span>消息</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="discover.php">
                    <i class="fas fa-compass"></i>
                    <span>发现</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="search.php">
                    <i class="fas fa-search"></i>
                    <span>搜索</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>我的</span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- 主要内容 -->
    <div class="container py-4">
        <!-- 个人资料头部 -->
        <div class="profile-header">
            <div class="row">
                <div class="col-md-3 text-center">
                    <img src="assets/images/<?php echo $user['avatar']; ?>" alt="头像" class="profile-avatar">
                    <h3 class="mt-3"><?php echo $user['username']; ?></h3>
                    <p class="text-muted"><?php echo $user['email']; ?></p>
                    <a href="edit_profile.php" class="btn btn-primary mt-2">编辑资料</a>
                </div>
                <div class="col-md-9">
                    <div class="profile-info">
                        <h4>个人简介</h4>
                        <p><?php echo $user['bio'] ?? '这是一个默认的个人简介，你可以在编辑资料时修改它。'; ?></p>
                    </div>
                    <div class="profile-stats">
                        <div class="stat-item">
                            <div class="stat-number"><?php echo count($user_posts); ?></div>
                            <div class="stat-label">帖子</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $following_count['count']; ?></div>
                            <div class="stat-label">关注</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $followers_count['count']; ?></div>
                            <div class="stat-label">粉丝</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 标签页 -->
        <ul class="nav nav-tabs" id="profileTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="posts-tab" data-bs-toggle="tab" data-bs-target="#posts" type="button" role="tab" aria-controls="posts" aria-selected="true">
                    <i class="fas fa-edit"></i> 我的帖子
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="favorites-tab" data-bs-toggle="tab" data-bs-target="#favorites" type="button" role="tab" aria-controls="favorites" aria-selected="false">
                    <i class="fas fa-heart"></i> 我的收藏
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="following-tab" data-bs-toggle="tab" data-bs-target="#following" type="button" role="tab" aria-controls="following" aria-selected="false">
                    <i class="fas fa-user-friends"></i> 我的关注
                </button>
            </li>
        </ul>

        <div class="tab-content" id="profileTabsContent">
            <!-- 我的帖子 -->
            <div class="tab-pane fade show active" id="posts" role="tabpanel" aria-labelledby="posts-tab">
                <?php if (!empty($user_posts)): ?>
                    <?php foreach ($user_posts as $post): ?>
                        <div class="post-card">
                            <div class="post-header">
                                <img src="assets/images/<?php echo $user['avatar']; ?>" alt="头像" class="avatar">
                                <div>
                                    <h5 class="mb-0"><?php echo $user['username']; ?></h5>
                                    <p class="text-muted mb-0"><?php echo date('Y-m-d H:i', strtotime($post['created_at'])); ?></p>
                                </div>
                            </div>
                            <div class="post-content">
                                <?php echo $post['content']; ?>
                            </div>
                            <?php if ($post['image']): ?>
                                <?php $images = explode(',', $post['image']); ?>
                                <div class="row">
                                    <?php foreach ($images as $img): ?>
                                        <div class="col-md-6 mb-3">
                                            <img src="assets/images/uploads/<?php echo $img; ?>" alt="帖子图片" class="post-image w-100">
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                            <div class="post-actions">
                                <button class="action-btn">
                                    <i class="far fa-heart"></i> 点赞 (<?php echo $post['likes']; ?>)
                                </button>
                                <button class="action-btn">
                                    <i class="far fa-comment"></i> 评论 (<?php echo $post['comments']; ?>)
                                </button>
                                <button class="action-btn">
                                    <i class="far fa-share-square"></i> 分享
                                </button>
                                <button class="action-btn text-danger delete-post" data-post-id="<?php echo $post['id']; ?>">
                                    <i class="far fa-trash-alt"></i> 删除
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-edit text-muted" style="font-size: 48px;"></i>
                        <p class="mt-3 text-muted">还没有发布帖子</p>
                        <a href="index.php" class="btn btn-primary mt-2">发布第一条帖子</a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- 我的收藏 -->
            <div class="tab-pane fade" id="favorites" role="tabpanel" aria-labelledby="favorites-tab">
                <div class="text-center py-5">
                    <i class="fas fa-heart text-muted" style="font-size: 48px;"></i>
                    <p class="mt-3 text-muted">还没有收藏的帖子</p>
                </div>
            </div>

            <!-- 我的关注 -->
            <div class="tab-pane fade" id="following" role="tabpanel" aria-labelledby="following-tab">
                <div class="text-center py-5">
                    <i class="fas fa-user-friends text-muted" style="font-size: 48px;"></i>
                    <p class="mt-3 text-muted">还没有关注的用户</p>
                    <a href="discover.php" class="btn btn-primary mt-2">去发现用户</a>
                </div>
            </div>
        </div>
    </div>

    <!-- 移动端发布按钮 -->
    <?php if ($user): ?>
        <div class="d-md-none fixed-bottom mb-4">
            <div class="container">
                <button type="button" class="btn btn-primary btn-lg rounded-circle" style="width: 60px; height: 60px; position: absolute; right: 20px; bottom: 80px; box-shadow: 0 2px 10px rgba(0,0,0,0.2);" data-bs-toggle="modal" data-bs-target="#postModal">
                    <i class="fas fa-plus"></i>
                </button>
            </div>
        </div>

        <!-- 发布帖子模态框 - 移动端 -->
        <div class="modal fade" id="postModal" tabindex="-1" aria-labelledby="postModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="postModalLabel">发布一天的好心情！</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="index.php" enctype="multipart/form-data">
                            <div class="mb-3">
                                <textarea class="form-control" rows="5" placeholder="分享你的想法..." name="content"></textarea>
                            </div>
                            <div class="form-group mb-3">
                                <label for="mobile-image" class="btn btn-outline-secondary w-100">
                                    <i class="fas fa-image"></i> 上传图片 (可多选)
                                    <input type="file" id="mobile-image" name="images[]" accept="image/*" multiple class="d-none">
                                </label>
                                <div id="mobile-image-preview" class="mt-3 d-none">
                                    <div class="row" id="mobile-preview-container"></div>
                                    <button type="button" id="mobile-remove-image" class="btn btn-sm btn-danger mt-2">移除所有图片</button>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">发布</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- 页脚 -->
    <footer class="footer">
        <div class="container text-center">
            <p class="mb-0">© 2026 &#19981;&#35265;&#26691;&#33457;&#19981;&#35265;&#31179; 版权所有</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        // 移动端图片上传预览功能 - 支持多张图片
        $('#mobile-image').on('change', function(e) {
            if (e.target.files && e.target.files.length > 0) {
                $('#mobile-preview-container').empty();
                $('#mobile-image-preview').removeClass('d-none');
                
                for (var i = 0; i < e.target.files.length; i++) {
                    var file = e.target.files[i];
                    var reader = new FileReader();
                    
                    reader.onload = (function(fileIndex) {
                        return function(e) {
                            var col = $('<div class="col-4 mb-3"></div>');
                            var img = $('<img>').attr('src', e.target.result).addClass('img-fluid rounded').css('max-height', '100px');
                            col.append(img);
                            $('#mobile-preview-container').append(col);
                        };
                    })(i);
                    
                    reader.readAsDataURL(file);
                }
            }
        });
        
        // 移动端移除图片功能
        $('#mobile-remove-image').on('click', function() {
            $('#mobile-image').val('');
            $('#mobile-preview-container').empty();
            $('#mobile-image-preview').addClass('d-none');
        });
        
        // 删除帖子功能
        $('.delete-post').on('click', function() {
            var postId = $(this).data('post-id');
            if (confirm('确定要删除这篇帖子吗？')) {
                $.ajax({
                    url: 'profile.php',
                    type: 'POST',
                    data: {
                        action: 'delete_post',
                        post_id: postId
                    },
                    success: function(response) {
                        // 刷新页面
                        location.reload();
                    },
                    error: function() {
                        alert('删除失败，请稍后重试');
                    }
                });
            }
        });
    </script>
</body>
</html>