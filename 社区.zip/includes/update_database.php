<?php
// 数据库更新脚本，添加 bio 字段

// 加载配置和数据库连接
if (file_exists('config.php')) {
    require_once 'config.php';
    require_once 'database.php';
} else {
    die('配置文件不存在');
}

try {
    // 添加 bio 字段到 users 表
    db()->query("ALTER TABLE users ADD COLUMN bio TEXT NULL AFTER avatar");
    echo '数据库更新成功，已添加 bio 字段';
} catch (Exception $e) {
    echo '数据库更新失败: ' . $e->getMessage();
}
?>