<?php
// 用户认证相关函数

// 验证用户登录
function login($email, $password) {
    $user = db()->fetch("SELECT * FROM users WHERE email = ?", [$email]);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        return true;
    }
    return false;
}

// 用户注册
function register($username, $email, $password) {
    // 检查用户名是否已存在
    $existing_user = db()->fetch("SELECT * FROM users WHERE username = ? OR email = ?", [$username, $email]);
    if ($existing_user) {
        return '用户名或邮箱已存在';
    }
    
    // 密码哈希
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    
    // 插入用户
    db()->query("INSERT INTO users (username, email, password) VALUES (?, ?, ?)", [
        $username,
        $email,
        $password_hash
    ]);
    
    // 自动登录
    $user = db()->fetch("SELECT * FROM users WHERE email = ?", [$email]);
    $_SESSION['user_id'] = $user['id'];
    
    return true;
}

// 退出登录
function logout() {
    session_destroy();
    header('Location: index.php');
    exit;
}

// 获取当前登录用户
function get_logged_in_user() {
    if (isset($_SESSION['user_id'])) {
        return db()->fetch("SELECT * FROM users WHERE id = ?", [$_SESSION['user_id']]);
    }
    return null;
}

// 检查用户是否登录
function is_logged_in() {
    return isset($_SESSION['user_id']);
}