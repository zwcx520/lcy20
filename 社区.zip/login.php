<?php
session_start();

// 加载配置和数据库连接
if (file_exists('config.php')) {
    require_once 'config.php';
    require_once 'database.php';
    require_once 'includes/functions.php';
} else {
    header('Location: install.php');
    exit;
}

// 检查是否已登录
if (is_logged_in()) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    
    if (empty($email) || empty($password)) {
        $error = '请填写邮箱和密码';
    } else {
        if (login($email, $password)) {
            header('Location: index.php');
            exit;
        } else {
            $error = '邮箱或密码错误';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>心事社区 - 登录</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
           background-image: url(bj.jpg);
                 background-size: cover; /* 修改为cover，使图片铺满满屏 */
                 background-attachment: fixed; /* 可选，使背景图片固定不随页面滚动 */
                 margin: 0; /* 去除默认边距 */
                 padding: 0; /* 去除默认内边距 */
            
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            max-width: 400px;
            width: 90%;
           
            padding: 20px;
        }
        @media (max-width: 576px) {
            .login-container {
                padding: 15px;
            }
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo h1 {
            color: #007bff;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-control {
            border-radius: 20px;
            padding: 12px 20px;
        }
        .btn-primary {
            border-radius: 20px;
            padding: 12px;
            font-weight: bold;
        }
        .text-center {
            margin-top: 20px;
        }
    </style>
</head>
<body>
 
   <div class="login-container">   <br>
   <br>
        <div class="logo">
            <h1>心事存放之地</h1>
            <p>(σ≧︎▽︎≦︎)σ。</p>
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="post" action="login.php">
            <div class="form-group">
                <label for="email" class="form-label">邮箱:</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="请输入邮箱" required>
            </div>
            <div class="form-group">
                <label for="password" class="form-label">密码:</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="请输入密码" required>
            </div>
            <button type="submit" class="btn btn-primary w-50">登录</button>
               <br>  
               <br>
   <br>
   <br>
            <div class="text-center">
                <p>还没有账号？ <a href="register.php">立即注册</a></p>
            </div>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>