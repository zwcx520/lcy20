<?php
session_start();

if (file_exists('config.php')) {
    require_once 'config.php';
    require_once 'database.php';
} else {
    die('配置文件不存在，请先运行 install.php 安装');
}

try {
    $pdo = db()->getPDO();

    $pdo->exec("CREATE TABLE IF NOT EXISTS `site_settings` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `setting_key` VARCHAR(100) NOT NULL UNIQUE,
        `setting_value` TEXT,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $default_about = '欢迎来到心事社区，这里是一个分享想法、交流心得的平台。加入我们，与志同道合的朋友一起成长';

    $stmt = $pdo->prepare("INSERT IGNORE INTO `site_settings` (`setting_key`, `setting_value`) VALUES ('about_community', ?)");
    $stmt->execute([$default_about]);

    echo '<div style="padding: 20px; margin: 20px; background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; border-radius: 4px;">';
    echo '数据库更新成功！已添加 site_settings 表<br>';
    echo '<a href="index.php" style="color: #155724; text-decoration: underline;">返回首页</a>';
    echo '</div>';

} catch (Exception $e) {
    echo '<div style="padding: 20px; margin: 20px; background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: 4px;">';
    echo '错误: ' . $e->getMessage() . '<br>';
    echo '<a href="index.php" style="color: #721c24; text-decoration: underline;">返回首页</a>';
    echo '</div>';
}
?>