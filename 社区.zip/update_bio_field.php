<?php
// 数据库更新脚本，为 users 表添加 bio 字段

session_start();

// 加载配置和数据库连接
if (file_exists('config.php')) {
    require_once 'config.php';
    require_once 'database.php';
} else {
    die('配置文件不存在，请先运行 install.php 安装');
}

try {
    // 检查 bio 字段是否存在
    $stmt = db()->query("SHOW COLUMNS FROM users LIKE 'bio'");
    $column_exists = $stmt->rowCount() > 0;
    
    if (!$column_exists) {
        // 添加 bio 字段到 users 表
        db()->query("ALTER TABLE users ADD COLUMN bio TEXT NULL AFTER avatar");
        echo '数据库更新成功，已添加 bio 字段';
    } else {
        echo 'bio 字段已经存在，无需更新';
    }
} catch (Exception $e) {
    echo '数据库更新失败: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数据库更新</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">数据库更新</h5>
            </div>
            <div class="card-body">
                <p><?php echo $message ?? ''; ?></p>
                <a href="index.php" class="btn btn-primary">返回首页</a>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>