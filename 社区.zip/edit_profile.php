<?php
session_start();

// 加载配置和数据库连接
if (file_exists('config.php')) {
    require_once 'config.php';
    require_once 'database.php';
    require_once 'includes/functions.php';
} else {
    header('Location: install.php');
    exit;
}

// 检查是否已登录
if (!is_logged_in()) {
    header('Location: login.php');
    exit;
}

// 检查 bio 字段是否存在
try {
    $stmt = db()->query("SHOW COLUMNS FROM users LIKE 'bio'");
    $column_exists = $stmt->rowCount() > 0;
    
    if (!$column_exists) {
        die('<div class="container mt-5"><div class="alert alert-danger" role="alert">数据库结构需要更新，请先 <a href="update_bio_field.php">运行更新脚本</a></div></div>');
    }
} catch (Exception $e) {
    die('<div class="container mt-5"><div class="alert alert-danger" role="alert">数据库错误: ' . $e->getMessage() . '</div></div>');
}

// 获取当前用户
$user = get_logged_in_user();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $bio = trim($_POST['bio']);
    
    // 验证输入
    if (empty($username) || empty($email)) {
        $error = '请填写用户名和邮箱';
    } elseif (strlen($username) < 3 || strlen($username) > 20) {
        $error = '用户名长度应在3-20个字符之间';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = '请输入有效的邮箱地址';
    } else {
        // 检查用户名是否被其他用户使用
        $existing_user = db()->fetch("SELECT * FROM users WHERE (username = ? OR email = ?) AND id != ?", [$username, $email, $user['id']]);
        if ($existing_user) {
            $error = '用户名或邮箱已被使用';
        } else {
            // 处理头像上传
            $avatar = $user['avatar'];
            if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
                $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
                $extension = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
                if (in_array($extension, $allowed_extensions) && $_FILES['avatar']['size'] <= MAX_UPLOAD_SIZE) {
                    $filename = uniqid() . '.' . $extension;
                    $upload_path = 'assets/images/' . $filename;
                    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $upload_path)) {
                        $avatar = $filename;
                    }
                }
            }
            
            // 更新用户资料
            db()->query("UPDATE users SET username = ?, email = ?, bio = ?, avatar = ? WHERE id = ?", [
                $username,
                $email,
                $bio,
                $avatar,
                $user['id']
            ]);
            
            $success = '资料更新成功';
            
            // 重新获取用户信息
            $user = get_logged_in_user();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>心事社区 - 编辑资料</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .navbar-toggler {
            padding: 0.15rem 0.35rem;
            font-size: 0.75rem;
            line-height: 1;
            align-self: center;
        }
        .navbar-toggler-icon {
            width: 1em;
            height: 1em;
        }
        .nav-link {
            color: #333;
        }
        .nav-link.active {
            color: #007bff;
            font-weight: bold;
        }
        @media (max-width: 576px) {
            .navbar {
                height: 60px;
            }
            .navbar .container {
                height: 100%;
                display: flex;
                align-items: center;
            }
            .navbar .d-flex {
                margin-top: 10px;
                width: 100%;
            }
            .navbar .d-flex .btn {
                flex: 1;
                margin: 0 5px;
            }
            .navbar .d-flex .btn:first-child {
                margin-left: 0;
            }
            .navbar .d-flex .btn:last-child {
                margin-right: 0;
            }
            .dropdown-menu {
                position: static !important;
                float: none !important;
                width: 100% !important;
                margin-top: 0 !important;
            }
        }
        .edit-container {
            
            
        
            padding: 20px;
            margin-top: 20px;
        }
        @media (max-width: 576px) {
            .edit-container {
                padding: 15px;
                margin-top: 10px;
            }
            .profile-avatar {
                width: 100px;
                height: 100px;
            }
        }
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #007bff;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-control {
            border-radius: 8px;
        }
        .btn-primary {
            border-radius: 20px;
        }
        .btn-secondary {
            border-radius: 20px;
        }
        .avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 15px;
        }
        .footer {
            background-color: white;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
            padding: 20px 0;
            margin-top: 40px;
        }
        /* 移动端底部导航 */
        .mobile-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: white;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
            z-index: 1000;
            height: 60px;
        }
        .mobile-nav .navbar-nav {
            display: flex;
            flex-direction: row;
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
        }
        .mobile-nav .nav-item {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .mobile-nav .nav-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 0;
            color: #6c757d;
            height: 100%;
            width: 100%;
        }
        .mobile-nav .nav-link.active {
            color: #007bff;
        }
        .mobile-nav .nav-link i {
            font-size: 18px;
            margin-bottom: 2px;
        }
        .mobile-nav .nav-link span {
            font-size: 12px;
        }
        /* 为移动端内容添加底部边距，避免被导航栏遮挡 */
        @media (max-width: 576px) {
            .container {
                margin-bottom: 70px;
            }
            .navbar {
                height: 60px;
            }
            .navbar .container {
                height: 100%;
                display: flex;
                align-items: center;
            }
            .navbar-collapse .navbar-nav {
                display: none !important;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-comments text-primary mr-2"></i>
                心事社区
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-home"></i> 首页
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="message.php">
                            <i class="fas fa-envelope"></i> 消息
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="discover.php">
                            <i class="fas fa-compass"></i> 发现
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i> 我的
                        </a>
                    </li>
                    <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">
                            <i class="fas fa-cog"></i> 管理
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                <div class="d-flex align-items-center">
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown">
                            <img src="assets/images/<?php echo $user['avatar']; ?>" alt="头像" class="avatar" style="width: 36px; height: 36px;">
                            <span class="ms-2"><?php echo $user['username']; ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php">个人资料</a></li>
                            <li><a class="dropdown-item" href="edit_profile.php">编辑资料</a></li>
                            <li><a class="dropdown-item" href="#">设置</a></li>
                            <?php if (isset($user) && ($user['is_admin'] ?? 0)): ?>
                            <li><a class="dropdown-item" href="admin.php">管理后台</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="index.php?action=logout">退出登录</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- 移动端底部导航 -->
    <nav class="mobile-nav d-md-none navbar navbar-expand-lg">
        <ul class="navbar-nav w-100 d-flex justify-content-around">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-home"></i>
                    <span>首页</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="message.php">
                    <i class="fas fa-envelope"></i>
                    <span>消息</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="discover.php">
                    <i class="fas fa-compass"></i>
                    <span>发现</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>我的</span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- 主要内容 -->
    <div class="container">
        <div class="edit-container">
            <h2 class="mb-4">编辑资料</h2>
            
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <form method="post" enctype="multipart/form-data">
                <div class="text-center mb-4">
                    <img src="assets/images/<?php echo $user['avatar']; ?>" alt="头像" class="profile-avatar mb-3" id="current-avatar">
                    <div class="form-group">
                        <label for="avatar" class="btn btn-outline-secondary">
                            <i class="fas fa-camera"></i> 更换头像
                            <input type="file" id="avatar" name="avatar" accept="image/*" class="d-none">
                        </label>
                    </div>
                    <div id="avatar-preview" class="mt-3 d-none">
                        <img id="preview-avatar" src="" alt="头像预览" class="profile-avatar mb-3">
                        <button type="button" id="remove-avatar" class="btn btn-sm btn-danger">取消更换</button>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="username" class="form-label">用户名</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo $user['username']; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email" class="form-label">邮箱</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="bio" class="form-label">个人简介</label>
                    <textarea class="form-control" id="bio" name="bio" rows="4" placeholder="介绍一下自己..."><?php echo $user['bio'] ?? ''; ?></textarea>
                </div>
                
                <div class="d-flex justify-content-between mt-4">
                    <a href="profile.php" class="btn btn-secondary">取消</a>
                    <button type="submit" class="btn btn-primary">保存更改</button>
                </div>
            </form>
        </div>
    </div>

    <!-- 页脚 -->
    <footer class="footer">
        <div class="container text-center">
            <p class="mb-0">© 2026 心事社区 版权所有</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        // 头像预览
        $('#avatar').on('change', function(e) {
            if (e.target.files && e.target.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#preview-avatar').attr('src', e.target.result);
                    $('#current-avatar').addClass('d-none');
                    $('#avatar-preview').removeClass('d-none');
                }
                reader.readAsDataURL(e.target.files[0]);
            }
        });
        
        // 取消更换头像
        $('#remove-avatar').on('click', function() {
            $('#avatar').val('');
            $('#current-avatar').removeClass('d-none');
            $('#avatar-preview').addClass('d-none');
        });
    </script>
</body>
</html>