<?php
// 数据库连接文件

// 加载配置文件
if (!file_exists('config.php')) {
    die('配置文件不存在，请先运行 install.php 安装');
}

require_once 'config.php';

class Database {
    private static $instance = null;
    private $pdo;
    
    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
            
            // 检查 users 表是否存在
            $stmt = $this->pdo->query("SHOW TABLES LIKE 'users'");
            if ($stmt->rowCount() == 0) {
                die('数据库表不存在，请 <a href="install.php">重新安装</a>');
            }
        } catch (PDOException $e) {
            die('数据库连接失败: ' . $e->getMessage());
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getPDO() {
        return $this->pdo;
    }
    
    // 执行查询
    public function query($sql, $params = []) {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
    
    // 获取单行数据
    public function fetch($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetch();
    }
    
    // 获取多行数据
    public function fetchAll($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    // 获取插入ID
    public function lastInsertId() {
        return $this->pdo->lastInsertId();
    }
    
    // 开启事务
    public function beginTransaction() {
        return $this->pdo->beginTransaction();
    }
    
    // 提交事务
    public function commit() {
        return $this->pdo->commit();
    }
    
    // 回滚事务
    public function rollback() {
        return $this->pdo->rollback();
    }
}

// 全局数据库实例
function db() {
    return Database::getInstance();
}