<?php
session_start();

// 加载配置和数据库连接
if (file_exists('config.php')) {
    require_once 'config.php';
    require_once 'database.php';
    require_once 'includes/functions.php';
} else {
    header('Location: install.php');
    exit;
}

// 检查是否已登录
if (!is_logged_in()) {
    header('Location: login.php');
    exit;
}

// 检查是否为管理员
$user = get_logged_in_user();
if (!($user['is_admin'] ?? 0)) {
    header('Location: index.php');
    exit;
}

// 处理用户删除
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_user') {
    $user_id = $_POST['user_id'];
    // 不能删除自己
    if ($user_id != $user['id']) {
        // 删除用户相关数据
        db()->query("DELETE FROM follows WHERE follower_id = ? OR following_id = ?", [$user_id, $user_id]);
        db()->query("DELETE FROM messages WHERE sender_id = ? OR receiver_id = ?", [$user_id, $user_id]);
        db()->query("DELETE FROM comments WHERE user_id = ?", [$user_id]);
        db()->query("DELETE FROM posts WHERE user_id = ?", [$user_id]);
        db()->query("DELETE FROM users WHERE id = ?", [$user_id]);
    }
    header('Location: admin.php');
    exit;
}

// 处理重置密码
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reset_password') {
    $user_id = $_POST['user_id'];
    $new_password = $_POST['new_password'];
    
    if (!empty($new_password)) {
        // 加密新密码
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        // 更新密码
        db()->query("UPDATE users SET password = ? WHERE id = ?", [$hashed_password, $user_id]);
    }
    header('Location: admin.php');
    exit;
}

// 处理帖子删除
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_post') {
    $post_id = $_POST['post_id'];
    // 删除帖子相关数据
    $post = db()->fetch("SELECT * FROM posts WHERE id = ?", [$post_id]);
    if ($post) {
        // 删除帖子相关的图片
        if (!empty($post['image'])) {
            $images = explode(',', $post['image']);
            foreach ($images as $img) {
                $image_path = 'assets/images/uploads/' . $img;
                if (file_exists($image_path)) {
                    unlink($image_path);
                }
            }
        }
        db()->query("DELETE FROM comments WHERE post_id = ?", [$post_id]);
        db()->query("DELETE FROM posts WHERE id = ?", [$post_id]);
    }
    header('Location: admin.php');
    exit;
}

// 获取所有用户
$users = db()->fetchAll("SELECT * FROM users ORDER BY created_at DESC");

// 获取所有帖子
$posts = db()->fetchAll("SELECT p.*, u.username, u.avatar FROM posts p JOIN users u ON p.user_id = u.id ORDER BY p.created_at DESC");
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>心事 - 管理后台</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-image: url(bj.jpg);
                 background-size: cover; /* 修改为cover，使图片铺满满屏 */
                 background-attachment: fixed; /* 可选，使背景图片固定不随页面滚动 */
                 margin: 0; /* 去除默认边距 */
                 padding: 0; /* 去除默认内边距 */
            
            
        }
        .navbar {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .navbar-toggler {
            padding: 0.15rem 0.35rem;
            font-size: 0.75rem;
            line-height: 1;
            align-self: center;
        }
        .navbar-toggler-icon {
            width: 1em;
            height: 1em;
        }
        .nav-link {
            color: #333;
        }
        .nav-link.active {
            color: #007bff;
            font-weight: bold;
        }
        @media (max-width: 576px) {
            .navbar {
                height: 60px;
            }
            .navbar .container {
                height: 100%;
                display: flex;
                align-items: center;
            }
            .navbar-collapse .navbar-nav {
                display: none !important;
            }
            .navbar .d-flex {
                margin-top: 10px;
                width: 100%;
            }
            .navbar .d-flex .btn {
                flex: 1;
                margin: 0 5px;
            }
            .navbar .d-flex .btn:first-child {
                margin-left: 0;
            }
            .navbar .d-flex .btn:last-child {
                margin-right: 0;
            }
            .dropdown-menu {
                position: static !important;
                float: none !important;
                width: 100% !important;
                margin-top: 0 !important;
            }
        }
        .admin-container {
            
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 20px;
            margin-top: 20px;
        }
        .admin-header {
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid #007bff;
        }
        .table-container {
            overflow-x: auto;
            max-height: 500px;
            overflow-y: auto;
        }
        .table {
            margin-bottom: 0;
        }
        .table th,
        .table td {
            padding: 8px 12px;
            vertical-align: middle;
        }
        .table td img {
            margin: 0;
        }
        .avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 15px;
        }
        .footer {
            background-color: white;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
            padding: 20px 0;
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-comments text-primary mr-2"></i>
                心事管理
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-home"></i> 首页
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="message.php">
                            <i class="fas fa-envelope"></i> 消息
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="discover.php">
                            <i class="fas fa-compass"></i> 发现
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user"></i> 我的
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="admin.php">
                            <i class="fas fa-cog"></i> 管理
                        </a>
                    </li>
                </ul>
                <div class="d-flex align-items-center">
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown">
                            <img src="assets/images/<?php echo $user['avatar']; ?>" alt="头像" class="avatar" style="width: 36px; height: 36px;">
                            <span class="ms-2"><?php echo $user['username']; ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php">个人资料</a></li>
                            <li><a class="dropdown-item" href="edit_profile.php">编辑资料</a></li>
                            <li><a class="dropdown-item" href="admin.php">管理后台</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="index.php?action=logout">退出登录</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- 主要内容 -->
    <div class="container">
        <div class="admin-container">
            <div class="admin-header">
                <h2><i class="fas fa-cog"></i> 管理后台</h2>
                <p>欢迎回来，<?php echo $user['username']; ?> - 管理员</p>
            </div>

            <!-- 标签页 -->
            <ul class="nav nav-tabs" id="adminTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="users-tab" data-bs-toggle="tab" data-bs-target="#users" type="button" role="tab" aria-controls="users" aria-selected="true">
                        <i class="fas fa-users"></i> 用户管理
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="posts-tab" data-bs-toggle="tab" data-bs-target="#posts" type="button" role="tab" aria-controls="posts" aria-selected="false">
                        <i class="fas fa-edit"></i> 帖子管理
                    </button>
                </li>
            </ul>

            <div class="tab-content" id="adminTabsContent">
                <!-- 用户管理 -->
                <div class="tab-pane fade show active" id="users" role="tabpanel" aria-labelledby="users-tab">
                    <div class="mt-4">
                        <h3>用户列表</h3>
                        <div class="table-container">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>头像</th>
                                        <th>用户名</th>
                                        <th>邮箱</th>
                                        <th>角色</th>
                                        <th>注册时间</th>
                                        <th>操作</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($users as $user_item): ?>
                                        <tr>
                                            <td><?php echo $user_item['id']; ?></td>
                                            <td><img src="assets/images/<?php echo $user_item['avatar']; ?>" alt="头像" class="avatar" style="width: 40px; height: 40px;"></td>
                                            <td><?php echo $user_item['username']; ?></td>
                                            <td><?php echo $user_item['email']; ?></td>
                                            <td><?php echo $user_item['is_admin'] ? '管理员' : '普通用户'; ?></td>
                                            <td><?php echo date('Y-m-d H:i', strtotime($user_item['created_at'])); ?></td>
                                            <td>
                                                <button type="button" class="btn btn-warning btn-sm mb-1" data-bs-toggle="modal" data-bs-target="#resetPasswordModal" data-user-id="<?php echo $user_item['id']; ?>" data-username="<?php echo $user_item['username']; ?>">
                                                    <i class="fas fa-key"></i> 重置密码
                                                </button>
                                                <?php if ($user_item['id'] != $user['id']): ?>
                                                    <form method="post" action="admin.php" style="display: inline;">
                                                        <input type="hidden" name="action" value="delete_user">
                                                        <input type="hidden" name="user_id" value="<?php echo $user_item['id']; ?>">
                                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('确定要删除这个用户吗？');">
                                                            <i class="fas fa-trash"></i> 删除
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <span class="text-muted">无法删除自己</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- 帖子管理 -->
                <div class="tab-pane fade" id="posts" role="tabpanel" aria-labelledby="posts-tab">
                    <div class="mt-4">
                        <h3>帖子列表</h3>
                        <div class="table-container">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>作者</th>
                                        <th>内容</th>
                                        <th>图片</th>
                                        <th>点赞数</th>
                                        <th>评论数</th>
                                        <th>发布时间</th>
                                        <th>操作</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($posts as $post): ?>
                                        <tr>
                                            <td><?php echo $post['id']; ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <img src="assets/images/<?php echo $post['avatar']; ?>" alt="头像" class="avatar" style="width: 30px; height: 30px; margin-right: 10px;">
                                                    <?php echo $post['username']; ?>
                                                </div>
                                            </td>
                                            <td><?php echo mb_strlen($post['content']) > 50 ? mb_substr($post['content'], 0, 50) . '...' : $post['content']; ?></td>
                                            <td>
                                                <?php if ($post['image']): ?>
                                                    <span class="text-success"><i class="fas fa-image"></i> 有图片</span>
                                                <?php else: ?>
                                                    <span class="text-muted"><i class="fas fa-image"></i> 无图片</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo $post['likes']; ?></td>
                                            <td><?php echo $post['comments']; ?></td>
                                            <td><?php echo date('Y-m-d H:i', strtotime($post['created_at'])); ?></td>
                                            <td>
                                                <form method="post" action="admin.php" style="display: inline;">
                                                    <input type="hidden" name="action" value="delete_post">
                                                    <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('确定要删除这个帖子吗？');">
                                                        <i class="fas fa-trash"></i> 删除
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 页脚 -->
    <footer class="footer">
        <div class="container text-center">
            <p class="mb-0">© 2026 心事社区 版权所有</p>
        </div>
    </footer>

    <!-- 重置密码模态框 -->
    <div class="modal fade" id="resetPasswordModal" tabindex="-1" aria-labelledby="resetPasswordModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="resetPasswordModalLabel">重置密码</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="post" action="admin.php">
                        <input type="hidden" name="action" value="reset_password">
                        <input type="hidden" name="user_id" id="reset-user-id">
                        <div class="mb-3">
                            <label for="reset-username" class="form-label">用户名</label>
                            <input type="text" class="form-control" id="reset-username" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="new-password" class="form-label">新密码</label>
                            <input type="password" class="form-control" id="new-password" name="new_password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">确认重置</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // 重置密码模态框
        var resetPasswordModal = document.getElementById('resetPasswordModal');
        resetPasswordModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var userId = button.getAttribute('data-user-id');
            var username = button.getAttribute('data-username');
            
            var modalBodyInput = resetPasswordModal.querySelector('#reset-user-id');
            var modalBodyUsername = resetPasswordModal.querySelector('#reset-username');
            
            modalBodyInput.value = userId;
            modalBodyUsername.value = username;
        });
    </script>
</body>
</html>